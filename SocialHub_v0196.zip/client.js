
(()=>{
const MAX_PLAYERS=8, HEARTBEAT_MS=15000;
const WORLD_W=700, WORLD_H=780;
const MALL_WORLD_W=2150;
const MEDIA_WORLD_W=2150;
const ARTIFACT_WORLD_W=1700;
// The Artifact spans former shops 03 + 04 in the mall. All coordinates are world-space.
const ARTIFACT_STORE={x:1010,w:640,cx:1330,doorX:1258,doorY:217,doorW:144,doorH:142};
const ARTIFACT_EXIT={x:774,y:666,w:152,h:104};
const ARTIFACT_LOUNGE={x:620,y:341,w:460,h:288};
const ARTIFACT_SOFA_CENTERS=[730,850,970];
const ARTIFACT_MACHINE_XS=[128,228,328,428,528,1172,1272,1372,1472,1572];
const LOOKS_STOREFRONT={x:310,y:200,w:290,h:167};
const LOOKS_MIRRORS=[{x:118,y:175,w:126,h:188},{x:287,y:175,w:126,h:188},{x:456,y:175,w:126,h:188}];
const LOOKS_EXIT={x:270,y:662,w:160,h:85};
const LOOKS_RACKS=[{x:13,y:424,w:114,h:135},{x:576,y:424,w:111,h:135}];
const PLAYER_SPEED=165;
const PLAYER_RADIUS=22;
const WARDROBE={x:560,y:70,w:105,h:105};
const THEATRE_DOOR={x:14,y:233,w:134,h:184};
const THEATRE_EXIT={x:15,y:540,w:142,h:167};
const THEATRE_PANEL={x:545,y:540,w:137,h:130};
const ACTIVITY={x:36,y:575,w:150,h:112};
const FRIDGE={x:30,y:31,w:114,h:138};
const BONG={x:417,y:488,w:29,h:38};
const PUBLIC_CODE="VIBE01";
// v0.15: no world objects or their tap targets in The Vibe atrium.
// Keep legacy object renderers, modals, actions, and server data for later reuse.
const VIBE_ATRIUM_ONLY=true;
const isMallAtrium=()=>VIBE_ATRIUM_ONLY&&isPublicRoomCode(roomCode);
const PUBLIC_INSTANCE_LIMIT=25;
const isPublicRoomCode=code=>/^VIBE(?:0[1-9]|[1-9][0-9])$/.test(code);
const publicInstanceCode=n=>`VIBE${String(n).padStart(2,"0")}`;
let publicAttempt=1;
const LOUNGE_SEATS=[{id:"sofa1",scene:"lobby",x:532,y:480},{id:"sofa2",scene:"lobby",x:606,y:480},{id:"cinema1",scene:"theatre",x:260,y:558},{id:"cinema2",scene:"theatre",x:328,y:558},{id:"cinema3",scene:"theatre",x:398,y:558},{id:"cinema4",scene:"theatre",x:262,y:639},{id:"cinema5",scene:"theatre",x:346,y:639},{id:"cinema6",scene:"theatre",x:438,y:639}];

const ATRIUM_BENCHES=[{x:151,y:618},{x:350,y:702},{x:534,y:548}];
const WALKWAY_BENCHES=[{x:575,y:618},{x:1280,y:618},{x:1910,y:618}];
const PUBLIC_BENCH_TAP_RANGE=200;
const ARTIFACT_SEAT_RANGE=200;
const PUBLIC_BENCH_SEATS=[
 ...ATRIUM_BENCHES.flatMap((b,i)=>[-23,23].map((dx,j)=>({id:`atrium-b${i}-${j}`,scene:"lobby",x:b.x+dx,y:b.y,publicOnly:true}))),
 ...WALKWAY_BENCHES.flatMap((b,i)=>[-23,23].map((dx,j)=>({id:`mall-b${i}-${j}`,scene:"mall",x:b.x+dx,y:b.y,publicOnly:true})))
];
// Comfortable two-person couches inside the public Artifact lounge.
const ARTIFACT_SEATS=ARTIFACT_SOFA_CENTERS.flatMap((cx,i)=>[-22,22].map((dx,j)=>({
 id:`artifact-sofa-${i}-${j}`,scene:"artifact",x:cx+dx,y:503,publicOnly:true
})));
const COMMUNITY_BOARD={x:828,y:510,w:200,h:158};
const BOARD_COLORS=["#172333","#ea626e","#edaa45","#6fbf82","#409bce","#9470d9","#ffffff"];
const BOARD_LIMIT=2100;
// Fixed world-space employee at Uncle Al's counter (store x=660, width=290).
const UNCLE_ALS_EMPLOYEE={x:852,y:242,w:43,h:77};
const UNCLE_ALS_GREETINGS=["Hey, welcome in!","How's it going?","Welcome to Uncle Al's!","Good to see you!","Hungry or thirsty?","Hey there!"];
// Uncle Al's uses stable, server-validated item IDs for collection and equipment.
// Inventory is a set of item IDs, so repeated taps cannot duplicate an item.
const UNCLE_ALS_MENU={
 drinks:[
  {id:"fresh-lemonade",name:"Fresh Lemonade",desc:"Cold-squeezed lemon, ice, just sweet enough.",price:"$3.50",icon:"🍋",accent:"#d6bd54"},
  {id:"strawberry-lemonade",name:"Strawberry Lemonade",desc:"Fresh lemonade with a strawberry swirl.",price:"$4.25",icon:"🍓",accent:"#ed8491"},
  {id:"iced-peach-tea",name:"Iced Peach Tea",desc:"Black tea, peach nectar and fresh ice.",price:"$3.75",icon:"🍑",accent:"#e8a26a"},
  {id:"vanilla-milkshake",name:"Vanilla Milkshake",desc:"Thick vanilla ice cream, blended smooth.",price:"$5.00",icon:"🥤",accent:"#dbc59d"},
  {id:"chocolate-milkshake",name:"Chocolate Milkshake",desc:"Creamy chocolate with a whipped top.",price:"$5.25",icon:"🍫",accent:"#967158"},
  {id:"berry-fizz",name:"Berry Fizz",desc:"Mixed berries and sparkling soda.",price:"$4.00",icon:"🫐",accent:"#a49cde"},
  {id:"hot-cocoa",name:"Hot Cocoa",desc:"Rich cocoa topped with mini marshmallows.",price:"$3.25",icon:"☕",accent:"#b98768"},
  {id:"cold-water",name:"Cold Water",desc:"Refreshing bottled water.",price:"$1.75",icon:"💧",accent:"#79b9d3"}
 ],
 snacks:[
  {id:"classic-soft-pretzel",name:"Classic Soft Pretzel",desc:"Warm, buttery, finished with sea salt.",price:"$4.50",icon:"🥨",accent:"#d6a15f"},
  {id:"cinnamon-roll",name:"Cinnamon Roll",desc:"Soft cinnamon spiral with sweet glaze.",price:"$4.75",icon:"🍥",accent:"#cda78e"},
  {id:"pretzel-nuggets",name:"Pretzel Nuggets",desc:"Bite-sized pretzels for sharing.",price:"$4.00",icon:"🥨",accent:"#c6915b"},
  {id:"churro-bites",name:"Churro Bites",desc:"Warm cinnamon-sugar bites.",price:"$4.25",icon:"🍪",accent:"#cf9a62"},
  {id:"ice-cream-cup",name:"Ice Cream Cup",desc:"Your choice of vanilla, chocolate or swirl.",price:"$3.75",icon:"🍨",accent:"#aaabd5"},
  {id:"mini-sundae",name:"Mini Sundae",desc:"Soft ice cream, syrup and sprinkles.",price:"$5.50",icon:"🍦",accent:"#e9a5b8"},
  {id:"cheddar-pretzel",name:"Cheddar Pretzel",desc:"A warm pretzel with creamy cheese dip.",price:"$5.00",icon:"🧀",accent:"#ecb957"},
  {id:"cookie-ice-cream-sandwich",name:"Cookie Ice Cream Sandwich",desc:"Ice cream tucked between two soft cookies.",price:"$5.75",icon:"🍪",accent:"#b59a83"}
 ]
 };
const PERMANENT_PHONE_ID="smartphone";
const INVENTORY_CATALOG=Object.freeze({
 ...Object.fromEntries(Object.entries(UNCLE_ALS_MENU).flatMap(([section,list])=>list.map(item=>[
  item.id,{name:item.name,description:item.desc,icon:item.icon,
           category:section==="drinks"?"Drink":"Snack",accent:item.accent}
 ]))),
 smartphone:{name:"Smartphone",description:"Your own pocket-sized connection to Social Hub. Includes Notes, Players, Dice and Clock. Always yours.",icon:"📱",category:"Device",accent:"#83cddd",permanent:true}
});
LOUNGE_SEATS.push(...PUBLIC_BENCH_SEATS,...ARTIFACT_SEATS);
const EMOTE_DURATIONS={wave:2800,heart:3500,laugh:3200,wow:2800,gg:3000,cheer:3900,point:3300,facepalm:3500,dance:12000,sleep:12000};

const DRINKS=[
 {id:"coke",name:"Coca-Cola",short:"COKE",color:"#bf2630",kind:"can",group:"soft"},
 {id:"pepsi",name:"Pepsi",short:"PEP",color:"#2659af",kind:"can",group:"soft"},
 {id:"sprite",name:"Sprite",short:"SPR",color:"#209e68",kind:"can",group:"soft"},
 {id:"fanta",name:"Fanta",short:"FAN",color:"#f18e22",kind:"can",group:"soft"},
 {id:"redbull",name:"Red Bull",short:"RB",color:"#264f8b",kind:"can",group:"soft"},
 {id:"gatorade",name:"Gatorade",short:"G",color:"#e77731",kind:"bottle",group:"soft"},
 {id:"budweiser",name:"Budweiser",short:"BUD",color:"#c22e36",kind:"can",group:"alcohol"},
 {id:"heineken",name:"Heineken",short:"HEIN",color:"#28794a",kind:"bottle",group:"alcohol"},
 {id:"corona",name:"Corona",short:"COR",color:"#e5ad39",kind:"bottle",group:"alcohol"},
 {id:"guinness",name:"Guinness",short:"GUIN",color:"#28252c",kind:"can",group:"alcohol"},
 {id:"whiteclaw",name:"White Claw",short:"WC",color:"#8ca5b4",kind:"can",group:"alcohol"},
 {id:"jackdaniels",name:"Jack Daniel's",short:"JD",color:"#302c29",kind:"bottle",group:"alcohol"}
];
function nearProp(p,rect,range){
 if(!p)return false;
 const nx=clamp(p.x,rect.x,rect.x+rect.w),ny=clamp(p.y,rect.y,rect.y+rect.h);
 return Math.hypot(p.x-nx,p.y-ny)<=range;
}

let ambientTick=0;
let atriumDoorOpen=0;
let mallReturnDoorOpen=0;
const ATRIUM_ENTRANCE={x:350,y:339,activationRadius:118,fullOpenRadius:68};
// The hallway return doors swing away from the mall viewer, into the atrium.
const MALL_RETURN_ENTRANCE={x:150,y:360,activationRadius:143,fullOpenRadius:72};
// Scene portals: keep original atrium and its hinged doors intact.
const MALL_ENTRY={minX:274,maxX:426,maxY:326};
const MALL_EXIT={minX:98,maxX:202,minY:320,maxY:378};
const MALL_SPAWN={x:215,y:530};
const MEDIA_EXIT={x:270,y:666,w:160,h:104};
const ATRIUM_RETURN={x:350,y:400};
function updateAtriumDoors(dt){
 const visitors=(isMallAtrium()&&currentScene()==="lobby"&&state?.players)
   ?state.players.filter(p=>(p.scene||"lobby")==="lobby"&&!p.disconnectedAt):[];
 let target=0;
 for(const p of visitors){
  // Start parting the panels before a visitor reaches the upper landing.
  const distance=Math.hypot(p.x-ATRIUM_ENTRANCE.x,p.y-ATRIUM_ENTRANCE.y);
  const amount=clamp((ATRIUM_ENTRANCE.activationRadius-distance)/
                     (ATRIUM_ENTRANCE.activationRadius-ATRIUM_ENTRANCE.fullOpenRadius),0,1);
  target=Math.max(target,amount);
 }
 // Smooth automatic open / close at any supported display refresh rate.
 atriumDoorOpen+=(target-atriumDoorOpen)*(1-Math.exp(-Math.max(0,dt)*7));
 if(Math.abs(target-atriumDoorOpen)<.001)atriumDoorOpen=target;
}
function updateMallReturnDoor(dt){
 let target=0;
 if(isMallAtrium()&&state?.players){
  for(const p of state.players){
   if(p.scene!=="mall"||p.disconnectedAt)continue;
   const distance=Math.hypot(p.x-MALL_RETURN_ENTRANCE.x,p.y-MALL_RETURN_ENTRANCE.y);
   const amount=clamp((MALL_RETURN_ENTRANCE.activationRadius-distance)/
                      (MALL_RETURN_ENTRANCE.activationRadius-MALL_RETURN_ENTRANCE.fullOpenRadius),0,1);
   target=Math.max(target,amount);
  }
 }
 // Match the other automatic doors: smooth, refresh-rate-independent easing.
 mallReturnDoorOpen+=(target-mallReturnDoorOpen)*(1-Math.exp(-Math.max(0,dt)*7));
 if(Math.abs(target-mallReturnDoorOpen)<.001)mallReturnDoorOpen=target;
}
let tvOpen=false,tvPanelOpen=false,tvPlayer=null,tvPlayerReady=false,tvLoadedId=null,tvApiRequested=false;
let tvClockOffset=0,tvClockBestRtt=Infinity,tvSyncTimer=null;
let tvAutoplayBlocked=false,tvSyncingUntil=0,tvActivated=false,tvLastPlayRevision=-1;
const $=id=>document.getElementById(id);
const clientId=(crypto.randomUUID?crypto.randomUUID():Math.random().toString(36).slice(2)+Date.now());

let roomCode=null,socket=null,heartbeat=null,state=null,joined=false,currentName="",connectMode=null,reconnectTimer=null,intentionalClose=false,everConnected=false,resumeProfile=null;
let pendingJoinProfile=null;
let homeColorChoice="sky",homeShapeChoice="pill";
let mallCameraX=0;
let mediaCameraX=0;
let looksDoorOpen=0;
let mediaDoorOpen=0;
let artifactDoorOpen=0,artifactCameraX=0;
let uncleMenuOpen=false,uncleMenuCategory="drinks";
let inventoryOpen=false,inventorySelected=null,discardPending=null,phoneOpen=false,phoneApp=null;
let phoneThreadId=null,phoneUnread=new Map(),phoneMessages=new Map(),phoneRoomKey=null;
let uncleGreeting="",uncleGreetingUntil=0,uncleWasOccupied=false;
let input={x:0,y:0},lastFrame=performance.now(),lastPosBroadcast=0;
let joyId=null;
let wardrobeOpen=false,fridgeOpen=false;
const smokeEvents=new Map();
let activityOpen=false;
let joyIdleTimer=null;
let typingStopTimer=null,lastTypingBroadcast=0;
const chatBubbles=new Map();
const typingUntil=new Map();
const emoteBubbles=new Map();
const seatAnimation=new Map();
const playerMotionUntil=new Map();

const bodyColors=[
  {id:"sky",name:"Sky",color:"#7fd4ff"},
  {id:"mint",name:"Mint",color:"#78e6a8"},
  {id:"coral",name:"Coral",color:"#ff8f88"},
  {id:"violet",name:"Violet",color:"#b89cff"},
  {id:"amber",name:"Amber",color:"#ffd16d"},
  {id:"slate",name:"Slate",color:"#9aa8bb"},
  {id:"peach",name:"Peach",color:"#ffb58e"},
  {id:"lime",name:"Lime",color:"#c2ed72"},
  {id:"rose",name:"Rose",color:"#f5a2ce"},
  {id:"indigo",name:"Indigo",color:"#8198ef"},
  {id:"teal",name:"Teal",color:"#64d5c6"},
  {id:"cream",name:"Cream",color:"#f4e4ba"},
  {id:"cocoa",name:"Cocoa",color:"#b88e70"},
  {id:"charcoal",name:"Charcoal",color:"#707f94"}
];

const bodyShapes=[
  {id:"pill",name:"Pill"},
  {id:"round",name:"Round"},
  {id:"tall",name:"Tall"},
  {id:"squat",name:"Squat"},
  {id:"square",name:"Square"},
  {id:"mini",name:"Mini"}
];
homeColorChoice=bodyColors[0]?.id||"sky";
homeShapeChoice=bodyShapes[0]?.id||"pill";

// Cosmetic items are now data-driven drawing instructions rather than emoji.
// Future cosmetics can be added by defining a draw function and metadata here.
const cosmetics={
 hats:[
  {id:"none",name:"None",draw:null},
  {id:"cap",name:"Cap",draw:"cap"},
  {id:"crown",name:"Crown",draw:"crown"},
  {id:"cowboy",name:"Cowboy",draw:"cowboy"},
  {id:"wizard",name:"Wizard Hat",draw:"wizard"},
  {id:"halo",name:"Halo",draw:"halo"},
  {id:"party",name:"Party Hat",draw:"party"},
  {id:"flower",name:"Flower",draw:"flower"},
  {id:"antenna",name:"Antenna",draw:"antenna"},
  {id:"mushroom",name:"Mushroom Cap",draw:"mushroom"},
  {id:"chef",name:"Chef Hat",draw:"chef"},
  {id:"saturn",name:"Tiny Saturn",draw:"saturn"},
  {id:"beanie",name:"Beanie",draw:"beanie"},
  {id:"top",name:"Top Hat",draw:"top"},
  {id:"horns",name:"Horns",draw:"horns"},
  {id:"bunny",name:"Bunny Ears",draw:"bunny"},
  {id:"headphones",name:"Headphones",draw:"headphones"}
 ],
 masks:[
  {id:"none",name:"None",draw:null},
  {id:"bandit",name:"Bandit Mask",draw:"bandit"},
  {id:"robot",name:"Robot Face",draw:"robot"},
  {id:"cool",name:"Shades",draw:"shades"},
  {id:"ghost",name:"Ghost Mask",draw:"ghost"},
  {id:"alien",name:"Alien Visor",draw:"alien"},
  {id:"skull",name:"Skull Mask",draw:"skull"},
  {id:"frog",name:"Frog Mask",draw:"frog"},
  {id:"cat",name:"Cat Mask",draw:"cat"},
  {id:"cyclops",name:"Cyclops Lens",draw:"cyclops"},
  {id:"clown",name:"Clown Nose",draw:"clown"},
  {id:"visor",name:"Neon Visor",draw:"visor"},
  {id:"monocle",name:"Monocle",draw:"monocle"},
  {id:"pirate",name:"Eye Patch",draw:"pirate"},
  {id:"sleepy",name:"Sleepy Eyes",draw:"sleepy"},
  {id:"heart",name:"Heart Glasses",draw:"heart"},
  {id:"goofy",name:"Goofy Grin",draw:"goofy"}
 ],
 outfits:[
  {id:"none",name:"None",draw:null},
  {id:"stripes",name:"Stripes",draw:"stripes"},
  {id:"spots",name:"Polka Dots",draw:"spots"},
  {id:"star",name:"Star",draw:"star"},
  {id:"sash",name:"Sash",draw:"sash"},
  {id:"jacket",name:"Jacket",draw:"jacket"},
  {id:"belt",name:"Utility Belt",draw:"belt"}
 ]
};

const now=()=>Date.now();
const cleanName=s=>(s||"").trim().replace(/\s+/g," ").slice(0,18)||"Player";
const normalizeCode=s=>(s||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6);
const roomKey=code=>`socialhub-room-${code}`;
const msgId=()=>crypto.randomUUID?crypto.randomUUID():String(Math.random())+Date.now();
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);

function randomCode(){const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(let i=0;i<6;i++)s+=chars[Math.floor(Math.random()*chars.length)];return s}
function spawnPoint(index=0,publicHub=false){
 if(publicHub){
  const spots=[[0,0],[-58,0],[58,0],[0,-66],[0,66],[-60,-62],[60,-62],[60,62]];
  const [dx,dy]=spots[index%spots.length];return{x:350+dx,y:514+dy};
 }
 return{x:120+(index%3)*70,y:WORLD_H-140-Math.floor(index/3)*65};
}
function defaultPlayer(id,name,index=0){
 const p=spawnPoint(index);
 return{id,name,joinedAt:now(),seenAt:now(),x:p.x,y:p.y,scene:"lobby",hat:"none",mask:"none",outfit:"none",drink:"none",color:"sky",shape:"pill",seat:null,action:"none",actionAt:0,inventory:[PERMANENT_PHONE_ID],equippedItem:null};
}
function defaultState(code,hostId,hostName){
 return{version:3,code,locked:false,hostId,createdAt:now(),updatedAt:now(),
 players:[defaultPlayer(hostId,hostName,0)],
 activity:{game:null,seats:[null,null],board:null,turn:0,status:"idle",winner:null,revision:0},
 chat:[{id:msgId(),type:"system",text:`${hostName} created the lobby.`,at:now()}]};
}
function migrateState(s){
 if(!s)return s;
 s.version=3;
 if(!s.tv)s.tv={videoId:null,status:"stopped",position:0,updatedAt:now(),revision:0,changedBy:null};
 s.players=s.players||[];
 if(!s.activity)s.activity={game:null,seats:[null,null],board:null,turn:0,status:"idle",winner:null,revision:0};
 s.players.forEach((p,i)=>{
   const sp=spawnPoint(i);
   if(!Number.isFinite(p.x))p.x=sp.x;
   if(!Number.isFinite(p.y))p.y=sp.y;
   if(p.scene!=="theatre"&&!(isPublicRoomCode(s.code)&&["mall","looks","artifact"].includes(p.scene)))p.scene="lobby";
   if(!p.hat)p.hat="none";
   if(!p.mask)p.mask="none";
   if(!p.outfit)p.outfit="none";
   if(!DRINKS.some(d=>d.id===p.drink))p.drink="none";
   if(!p.color)p.color="sky";
   if(!p.shape)p.shape="pill";
   if(!Array.isArray(p.inventory))p.inventory=[];
   p.inventory=[PERMANENT_PHONE_ID,...new Set(p.inventory.filter(id=>id!==PERMANENT_PHONE_ID))].slice(0,80);
   if(!p.inventory.includes(p.equippedItem))p.equippedItem=null;
   if(!LOUNGE_SEATS.some(s=>s.id===p.seat&&s.scene===p.scene))p.seat=null;
   if(!(p.action in EMOTE_DURATIONS))p.action="none";
   if(!Number.isFinite(p.actionAt))p.actionAt=0;
   if(!p.seenAt)p.seenAt=now();
 });
 delete s.started;
 return s;
}

function freshActivity(){
 return{game:null,seats:[null,null],board:null,turn:0,status:"idle",winner:null,revision:0};
}
function playerById(id){return state?.players.find(p=>p.id===id)||null}
function activityName(){
 return ({ttt:"Tic-Tac-Toe",c4:"Connect 4",gomoku:"Gomoku",reversi:"Reversi",dots:"Dots & Boxes"})[state?.activity?.game]||"Activity Corner";
}
function initBoard(game){
 if(game==="ttt")return Array(9).fill(null);
 if(game==="c4")return Array(42).fill(null);
 if(game==="gomoku")return Array(81).fill(null);
 if(game==="dots")return Array(40).fill(null);
 if(game==="reversi"){
  const b=Array(64).fill(null);b[27]=2;b[28]=1;b[35]=1;b[36]=2;return b;
 }
 return null;
}
function activityExtras(a){
 if(a.game==="dots"){a.claims=Array(16).fill(0);a.scores=[0,0];}
 else{delete a.claims;delete a.scores;}
}
function reversiFlips(board,at,mark){
 if(!board||board[at])return [];
 const r=Math.floor(at/8),c=at%8,other=3-mark,flips=[];
 for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){
  let rr=r+dr,cc=c+dc;const line=[];
  while(rr>=0&&rr<8&&cc>=0&&cc<8&&board[rr*8+cc]===other){line.push(rr*8+cc);rr+=dr;cc+=dc;}
  if(line.length&&rr>=0&&rr<8&&cc>=0&&cc<8&&board[rr*8+cc]===mark)flips.push(...line);
 }
 return flips;
}
function seatedIndex(id){
 if(!state?.activity)return -1;
 return state.activity.seats.indexOf(id);
}
function activityCanPlay(id){
 const a=state?.activity;if(!a||a.status!=="playing")return false;
 const seat=seatedIndex(id);
 return seat>=0&&seat===a.turn;
}
function tttWinner(board){
 const lines=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
 for(const [a,b,c] of lines)if(board[a]&&board[a]===board[b]&&board[a]===board[c])return board[a];
 return board.every(Boolean)?"draw":null;
}
function c4Winner(board){
 const rows=6,cols=7;
 const get=(r,c)=>r>=0&&r<rows&&c>=0&&c<cols?board[r*cols+c]:null;
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
   const v=get(r,c);if(!v)continue;
   for(const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]){
     let ok=true;for(let k=1;k<4;k++)if(get(r+dr*k,c+dc*k)!==v){ok=false;break}
     if(ok)return v;
   }
 }
 return board.every(Boolean)?"draw":null;
}
function resetActivityRound(){
 const a=state.activity;
 a.board=initBoard(a.game);activityExtras(a);a.turn=0;a.winner=null;
 a.status=(a.seats[0]&&a.seats[1])?"playing":"waiting";
 a.revision=(a.revision||0)+1;
}
function sanitizeActivitySeats(){
 if(!state?.activity)return;
 const a=state.activity;
 let changed=false;
 for(let i=0;i<2;i++){
   if(a.seats[i]&&!playerById(a.seats[i])){a.seats[i]=null;changed=true}
 }
 if(changed&&a.game){
   a.board=initBoard(a.game);activityExtras(a);a.winner=null;a.turn=0;
   a.status=(a.seats[0]&&a.seats[1])?"playing":"waiting";
   a.revision=(a.revision||0)+1;
 }
}
function applyActivityAction(senderId,action,payload={}){
 if(!state||!playerById(senderId))return false;
 if(!state.activity)state.activity=freshActivity();
 const a=state.activity;

 if(action==="create"){
   if(a.game)return false;
   if(!["ttt","c4","gomoku","reversi","dots"].includes(payload.game))return false;
   a.game=payload.game;a.seats=[senderId,null];a.board=initBoard(payload.game);activityExtras(a);
   a.turn=0;a.status="waiting";a.winner=null;a.revision++;
   addSystem(`${playerById(senderId).name} opened ${activityName()} at the activity table.`);
   return true;
 }

 if(action==="join"){
   if(!a.game)return false;
   if(a.seats.includes(senderId))return false;
   const slot=a.seats.indexOf(null);if(slot<0)return false;
   a.seats[slot]=senderId;
   resetActivityRound();
   addSystem(`${playerById(senderId).name} joined ${activityName()}.`);
   return true;
 }

 if(action==="leave"){
   const seat=a.seats.indexOf(senderId);if(seat<0)return false;
   a.seats[seat]=null;
   if(a.game){
     a.board=initBoard(a.game);activityExtras(a);a.turn=0;a.winner=null;a.status="waiting";a.revision++;
   }
   return true;
 }

 if(action==="end"){
   if(!a.game)return false;
   if(!a.seats.includes(senderId)&&senderId!==state.hostId)return false;
   const old=activityName();
   state.activity=freshActivity();
   addSystem(`${old} closed.`);
   return true;
 }

 if(action==="reset"){
   if(!a.game||!a.seats.includes(senderId))return false;
   resetActivityRound();return true;
 }

 if(action==="move"){
   if(!activityCanPlay(senderId))return false;
   const seat=seatedIndex(senderId),mark=seat+1;

   if(a.game==="ttt"){
     const cell=Number(payload.cell);
     if(!Number.isInteger(cell)||cell<0||cell>8||a.board[cell])return false;
     a.board[cell]=mark;
     const win=tttWinner(a.board);
     if(win==="draw"){a.status="draw";a.winner=null}
     else if(win){a.status="won";a.winner=win-1}
     else a.turn=1-a.turn;
     a.revision++;return true;
   }

   if(a.game==="c4"){
     const col=Number(payload.col);
     if(!Number.isInteger(col)||col<0||col>6)return false;
     let target=-1;
     for(let r=5;r>=0;r--){const idx=r*7+col;if(!a.board[idx]){target=idx;break}}
     if(target<0)return false;
     a.board[target]=mark;
     const win=c4Winner(a.board);
     if(win==="draw"){a.status="draw";a.winner=null}
     else if(win){a.status="won";a.winner=win-1}
     else a.turn=1-a.turn;
     a.revision++;return true;
   }
 }
 return false;
}
function submitActivityAction(action,payload={}){
 if(!state)return;
 broadcast("activity-action",{action,payload});
}

// Room state is authoritative on the Cloudflare Durable Object.
// This no-op remains so customization code can update optimistically without
// having to know anything about persistence.
function saveState(){}

function isHost(){return state&&state.hostId===clientId}
function me(){return state?.players.find(p=>p.id===clientId)}
function currentScene(){const s=me()?.scene;return s==="theatre"||s==="mall"||s==="looks"||s==="media"||s==="artifact"?s:"lobby"}
function worldWidthForScene(scene=currentScene()){
 return !isMallAtrium()?WORLD_W:scene==="mall"?MALL_WORLD_W:scene==="media"?MEDIA_WORLD_W:scene==="artifact"?ARTIFACT_WORLD_W:WORLD_W;
}
function updateMallCamera(dt){
 if(currentScene()!=="mall"||!isMallAtrium()){mallCameraX=0;return}
 const p=me();if(!p)return;
 const target=clamp(p.x-WORLD_W*.48,0,MALL_WORLD_W-WORLD_W);
 mallCameraX+=(target-mallCameraX)*(1-Math.exp(-Math.max(0,dt)*6));
 if(Math.abs(target-mallCameraX)<.1)mallCameraX=target;
}
function updateArtifactCamera(dt){
 if(currentScene()!=="artifact"||!isMallAtrium()){artifactCameraX=0;return}
 const p=me();if(!p)return;
 const target=clamp(p.x-WORLD_W*.48,0,ARTIFACT_WORLD_W-WORLD_W);
 artifactCameraX+=(target-artifactCameraX)*(1-Math.exp(-Math.max(0,dt)*6));
 if(Math.abs(target-artifactCameraX)<.1)artifactCameraX=target;
}
function updateMediaCamera(dt){
 if(currentScene()!=="media"||!isMallAtrium()){mediaCameraX=0;return}
 const p=me();if(!p)return;
 const target=clamp(p.x-WORLD_W*.48,0,MEDIA_WORLD_W-WORLD_W);
 mediaCameraX+=(target-mediaCameraX)*(1-Math.exp(-Math.max(0,dt)*6));
 if(Math.abs(target-mediaCameraX)<.1)mediaCameraX=target;
}
function canEnterMall(p){
 return !!p&&isMallAtrium()&&currentScene()==="lobby"&&
        p.x>=MALL_ENTRY.minX&&p.x<=MALL_ENTRY.maxX&&p.y<=MALL_ENTRY.maxY;
}
function canExitMall(p){
 return !!p&&isMallAtrium()&&currentScene()==="mall"&&
        p.x>=MALL_EXIT.minX&&p.x<=MALL_EXIT.maxX&&p.y>=MALL_EXIT.minY&&p.y<=MALL_EXIT.maxY;
}
function inAtriumTapRange(p){return p.x>=245&&p.x<=455&&p.y>=240&&p.y<=390}
function inMallTapRange(p){return p.x>=92&&p.x<=208&&p.y>=309&&p.y<=390}
function nearMediaStore(p){return MEDIA_MASTER_ENABLED&&!!p&&currentScene()==="mall"&&Math.hypot(p.x-805,p.y-362)<162}
function nearMediaExit(p){return !!p&&currentScene()==="media"&&p.x>=170&&p.x<=530&&p.y>=560&&nearProp(p,MEDIA_EXIT,112)}
function nearArtifactStore(p){
 return !!p&&p.scene==="mall"&&isMallAtrium()&&Math.hypot(p.x-ARTIFACT_STORE.cx,p.y-363)<195;
}
function nearArtifactExit(p){
 return !!p&&p.scene==="artifact"&&isMallAtrium()&&nearProp(p,ARTIFACT_EXIT,108)&&p.y>=610;
}
function changeArtifactScene(dest){
 const p=me();if(!joined||!p||!isMallAtrium())return;
 if(dest==="artifact"&&!nearArtifactStore(p))return;
 if(dest==="mall"&&!nearArtifactExit(p))return;
 if(dest!=="artifact"&&dest!=="mall")return;
 standUp();closeTV();closeTVPanel();
 const spawn=dest==="artifact"?{x:850,y:683}:{x:ARTIFACT_STORE.cx,y:526};
 p.scene=dest;p.x=spawn.x;p.y=spawn.y;p.seenAt=now();
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 if(dest==="mall")mallCameraX=clamp(spawn.x-WORLD_W*.48,0,MALL_WORLD_W-WORLD_W);
 if(dest==="artifact")artifactCameraX=clamp(spawn.x-WORLD_W*.48,0,ARTIFACT_WORLD_W-WORLD_W);
 broadcast("player-update",{patch:{scene:dest,x:p.x,y:p.y,seenAt:p.seenAt}});
 syncSceneUI();renderPanels();
}
function nearLooksStore(p){return !!p&&currentScene()==="mall"&&Math.hypot(p.x-455,p.y-362)<162}
function nearLooksExit(p){return !!p&&currentScene()==="looks"&&p.x>=170&&p.x<=530&&p.y>=565&&nearProp(p,LOOKS_EXIT,100)}
function changeLooksScene(dest){
 const p=me();if(!joined||!p||!isMallAtrium())return;
 if(dest==="looks"&&!nearLooksStore(p))return;
 if(dest==="mall"&&!nearLooksExit(p))return;
 if(dest!=="looks"&&dest!=="mall")return;
 standUp();closeWardrobe();closeTV();closeTVPanel();
 const spawn=dest==="looks"?{x:350,y:540}:{x:455,y:535};
 p.scene=dest;p.x=spawn.x;p.y=spawn.y;p.seenAt=now();
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 if(dest==="mall")mallCameraX=clamp(spawn.x-WORLD_W*.48,0,MALL_WORLD_W-WORLD_W);
 broadcast("player-update",{patch:{scene:dest,x:p.x,y:p.y,seenAt:p.seenAt}});
 syncSceneUI();renderPanels();
}
function changeMediaScene(dest){
 const p=me();if(!joined||!p||!isMallAtrium())return;
 if(dest==="media"&&!nearMediaStore(p))return;
 if(dest==="mall"&&!nearMediaExit(p))return;
 if(dest!=="media"&&dest!=="mall")return;
 standUp();closeWardrobe();closeTV();closeTVPanel();
 const spawn=dest==="media"?{x:350,y:533}:{x:805,y:530};
 p.scene=dest;p.x=spawn.x;p.y=spawn.y;p.seenAt=now();
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 if(dest==="mall")mallCameraX=clamp(spawn.x-WORLD_W*.48,0,MALL_WORLD_W-WORLD_W);
 if(dest==="media")mediaCameraX=0;
 broadcast("player-update",{patch:{scene:dest,x:p.x,y:p.y,seenAt:p.seenAt}});
 syncSceneUI();renderPanels();
}
function nearUncleAl(p){
 return Boolean(p&&p.scene==="mall"&&isMallAtrium()&&
   nearProp(p,UNCLE_ALS_EMPLOYEE,118));
}
function counterOccupied(){
 return Boolean(joined&&isMallAtrium()&&state?.players?.some(p=>
  !p.disconnectedAt&&nearUncleAl(p)));
}
function updateUncleGreeting(){
 const occupied=counterOccupied();
 // One greeting per group visit, regardless of how long anyone stays at the counter.
 if(occupied&&!uncleWasOccupied){
  let line=UNCLE_ALS_GREETINGS[Math.floor(Math.random()*UNCLE_ALS_GREETINGS.length)];
  if(line===uncleGreeting)line=UNCLE_ALS_GREETINGS[(UNCLE_ALS_GREETINGS.indexOf(line)+1)%UNCLE_ALS_GREETINGS.length];
  uncleGreeting=line;uncleGreetingUntil=performance.now()+3650;
 }
 if(!occupied)uncleGreetingUntil=0;
 uncleWasOccupied=occupied;
}
function updateMediaDoor(dt){
 let target=0;
 if(isMallAtrium()&&state?.players){
  for(const p of state.players){
   if(p.scene!=="mall"||p.disconnectedAt)continue;
   const d=Math.hypot(p.x-805,p.y-362);
   target=Math.max(target,clamp((142-d)/82,0,1));
  }
 }
 mediaDoorOpen+=(target-mediaDoorOpen)*(1-Math.exp(-Math.max(0,dt)*8));
}
function updateArtifactDoor(dt){
 let target=0;
 if(isMallAtrium()&&state?.players){
  for(const p of state.players){
   if(p.scene!=="mall"||p.disconnectedAt)continue;
   const distance=Math.hypot(p.x-ARTIFACT_STORE.cx,p.y-361);
   target=Math.max(target,clamp((200-distance)/105,0,1));
  }
 }
 artifactDoorOpen+=(target-artifactDoorOpen)*(1-Math.exp(-Math.max(0,dt)*8));
 if(Math.abs(target-artifactDoorOpen)<.001)artifactDoorOpen=target;
}
function updateLooksDoor(dt){
 let target=0;
 if(isMallAtrium()&&state?.players){
  for(const p of state.players){
   if(p.scene!=="mall"||p.disconnectedAt)continue;
   const d=Math.hypot(p.x-455,p.y-362);
   target=Math.max(target,clamp((136-d)/78,0,1));
  }
 }
 looksDoorOpen+=(target-looksDoorOpen)*(1-Math.exp(-Math.max(0,dt)*8));
}
function changeMallScene(dest,viaTap=false){
 if(!joined||!state||!me()||!isMallAtrium())return;
 const p=me();
 if(dest==="mall"&&!canEnterMall(p)&&!(viaTap&&inAtriumTapRange(p)))return;
 if(dest==="lobby"&&!canExitMall(p)&&!(viaTap&&inMallTapRange(p)))return;
 if(dest!=="mall"&&dest!=="lobby")return;
 standUp();closeTV();closeTVPanel();
 const pos=dest==="mall"?MALL_SPAWN:ATRIUM_RETURN;
 p.scene=dest;p.x=pos.x;p.y=pos.y;p.seenAt=now();
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 mallCameraX=0;
 broadcast("player-update",{patch:{scene:dest,x:p.x,y:p.y,seenAt:p.seenAt}});
 syncSceneUI();renderPanels();
}
function syncSceneUI(){
 if(currentScene()!=="mall"&&uncleMenuOpen)closeUncleMenu();
 const theatre=currentScene()==="theatre"&&!!state;
 $("theatreScreen").classList.toggle("hidden",!theatre);
 $("theatreActions").classList.toggle("hidden",!theatre);
 $("doorHint").textContent=theatre?"TAP EXIT DOOR":"TAP THEATRE DOOR";
 if(isMallAtrium())$("doorHint").classList.remove("show");
 $("fridgeHint").classList.remove("show");
 $("smokeHint").classList.remove("show");
 $("wardrobeHint").classList.remove("show");
 $("activityHint").classList.remove("show");
 $("tvHint").classList.remove("show");
 if(!theatre){closeTV();closeTVPanel();}
 if(theatre)closeFridge();
 renderTheatreScreen();
}
function requestSeat(seatId){
 const p=me();if(!p||!joined)return;
 broadcast("seat-action",{seat:seatId});
}
function standUp(){const p=me();if(!p?.seat)return;p.seat=null;broadcast("seat-action",{seat:null});}
function changeScene(scene){
 if(!state||!me()||!joined)return;
 const p=me(),dest=scene==="theatre"?"theatre":"lobby";
 if(currentScene()===dest)return;
 if(dest==="theatre"&&!nearProp(p,THEATRE_DOOR,95))return;
 if(dest==="lobby")closeTV();
 standUp();
 closeTVPanel();
 p.scene=dest;
 p.x=dest==="theatre"?225:176;
 p.y=dest==="theatre"?672:450;
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 broadcast("player-update",{patch:{scene:dest,x:p.x,y:p.y}});
 syncSceneUI();renderPanels();
}

function setNetworkStatus(label){
 const text=$("networkText"),dot=$("networkDot");
 if(text)text.textContent=label;
 if(dot){
   dot.style.background=label==="CONNECTED"?"#78e6a8":label==="RECONNECTING"?"#ffd16d":"#9daabc";
 }
 if(!state&&$("roomStatus"))$("roomStatus").textContent=label;
}

function socketAddress(code,name,mode){
 const proto=location.protocol==="https:"?"wss":"ws";
 const u=new URL(`${proto}://${location.host}/ws`);
 u.searchParams.set("room",code);
 u.searchParams.set("name",name);
 u.searchParams.set("client",clientId);
 u.searchParams.set("mode",mode);
 return u.toString();
}

function broadcast(type,payload={}){
 if(!socket||socket.readyState!==WebSocket.OPEN)return false;
 socket.send(JSON.stringify({type,payload}));
 return true;
}

function tvState(){return state?.tv || null}
function tvExpectedPosition(tv=tvState()){
 if(!tv||!tv.videoId)return 0;
 return Math.max(0,Math.min(86400,Number(tv.position||0)+(tv.status==="playing"?Math.max(0,Date.now()+tvClockOffset-tv.updatedAt)/1000:0)));
}
function tvFormatTime(seconds){
 const n=Math.max(0,Math.floor(seconds||0)),m=Math.floor(n/60),s=String(n%60).padStart(2,"0");
 return m>=60?`${Math.floor(m/60)}:${String(m%60).padStart(2,"0")}:${s}`:`${m}:${s}`;
}
function tvClockPing(){broadcast("tv-clock",{sentAt:Date.now()})}
function tvClockReply(msg){
 const receivedAt=Date.now(),rtt=receivedAt-msg.sentAt;
 if(!Number.isFinite(rtt)||rtt<0||rtt>15000)return;
 const offset=msg.serverAt-(msg.sentAt+rtt/2);
 if(rtt<=tvClockBestRtt+50){tvClockOffset=offset;tvClockBestRtt=rtt}
}
function tvCommand(action,props={}){return broadcast("tv-action",{action,...props})}
function parseYouTubeLink(text){
 try{
  const raw=String(text||"").trim();
  const u=new URL(raw.startsWith("https://")||raw.startsWith("http://")?raw:"https://"+raw);
  const host=u.hostname.toLowerCase();let id="";
  if(host==="youtu.be"||host==="www.youtu.be")id=u.pathname.split("/")[1]||"";
  else if(["youtube.com","www.youtube.com","m.youtube.com","music.youtube.com","youtube-nocookie.com","www.youtube-nocookie.com"].includes(host)){
   const parts=u.pathname.split("/").filter(Boolean);
   id=parts[0]==="watch"?u.searchParams.get("v")||"":(["embed","shorts","live","v"].includes(parts[0])?parts[1]||"":"");
  }
  if(!/^[a-zA-Z0-9_-]{11}$/.test(id))return null;
  let sec=0;const rawT=u.searchParams.get("t")||u.searchParams.get("start")||"";
  if(/^\d+$/.test(rawT))sec=Number(rawT);
  else if(/^(?:(?:\d+)h)?(?:(?:\d+)m)?(?:(?:\d+)s)?$/.test(rawT)){
   const m=rawT.match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/);if(m)sec=Number(m[1]||0)*3600+Number(m[2]||0)*60+Number(m[3]||0);
  }
  return {videoId:id,position:Math.min(86400,Math.max(0,sec))};
 }catch{return null}
}
function tvTimeUpdate(){
 if(!tvPanelOpen)return;
 const tv=tvState();$("tvTime").textContent=tv?.videoId?`${tvFormatTime(tvExpectedPosition(tv))} · ${tv.status.toUpperCase()}`:"0:00";
}
function renderTheatreScreen(){
 const tv=tvState(),loaded=!!tv?.videoId,here=currentScene()==="theatre"&&!!state;
 $("theatreScreen").classList.toggle("hidden",!here);
 $("theatreActions").classList.toggle("hidden",!here);
 if(!here)return;
 $("theatreWatchBtn").disabled=!loaded||tvOpen;
 $("theatreSyncBtn").disabled=!loaded||!tvOpen;
 $("theatreOffBtn").disabled=!tvOpen;
 $("theatreScreenWake").classList.toggle("hidden",tvOpen);
 $("theatreVideoMount").classList.toggle("hidden",!tvOpen);
 $("theatreScreenLabel").textContent=loaded?`${tv.status==="playing"?"PLAYING":"PAUSED"} · TAP TO WATCH SHARED VIDEO`:"NO VIDEO LOADED · TAP WALL CONTROLS";
 const img=$("theatreThumb");
 const id=loaded?tv.videoId:"";
 if(img.dataset.videoId!==id){
  img.dataset.videoId=id;
  img.classList.toggle("hidden",!id);
  img.src=id?`https://i.ytimg.com/vi/${id}/mqdefault.jpg`:"";
 }
 if(!loaded&&tvOpen)closeTV();
}
function renderTVUI(){
 renderTheatreScreen();
 if(tvPanelOpen){
  const tv=tvState(),loaded=!!tv?.videoId,host=!!isHost();
  $("tvStatus").textContent=loaded?`${tv.status==="playing"?"Playing":"Paused"} · ${tv.videoId}`:"No video loaded";
  $("tvJoinBtn").disabled=!loaded||!tvOpen;
  $("tvPlayBtn").disabled=!loaded||!host;
  $("tvPauseBtn").disabled=!loaded||!host||tv.status!=="playing";
  $("tvSeekBtn").disabled=!loaded||!host;
  $("tvSeekInput").disabled=!loaded||!host;
  $("tvClearBtn").disabled=!loaded||!host;
  const link=$("tvOpenYoutube");link.classList.toggle("hidden",!loaded);
  if(loaded)link.href=`https://www.youtube.com/watch?v=${tv.videoId}`;
  $("tvHelp").textContent=tvAutoplayBlocked?
   "Automatic playback was blocked. Close controls, tap Join / Sync below the screen, then tap YouTube's play button if needed.":
   "Any player can load a link; only the host can play, pause, seek or clear. Open the cinema screen separately. iPhone viewers may need to tap YouTube play to start with sound.";
  tvTimeUpdate();
 }
 tvRefreshPlayer();
}
function loadYouTubeApi(){
 if(window.YT?.Player){tvBuildPlayer();return}
 if(tvApiRequested)return;
 tvApiRequested=true;
 window.onYouTubeIframeAPIReady=()=>{if(tvOpen)tvBuildPlayer()};
 const script=document.createElement("script");script.src="https://www.youtube.com/iframe_api";
 script.onerror=()=>{$("tvHelp").textContent="YouTube could not load. Check your connection or content blocker.";tvApiRequested=false};
 document.head.appendChild(script);
}
function tvBuildPlayer(){
 if(!tvOpen||tvPlayer||!tvState()?.videoId||!window.YT?.Player)return;
 $("tvVideo").className="";$("tvVideo").textContent="";
 tvPlayerReady=false;tvLoadedId=tvState().videoId;
 tvPlayer=new YT.Player("tvVideo",{
  width:"100%",height:"100%",videoId:tvLoadedId,
  playerVars:{playsinline:1,controls:1,rel:0,origin:location.origin,autoplay:0},
  events:{onReady:()=>{if(!tvOpen||!tvPlayer)return;tvPlayerReady=true;tvRefreshPlayer(true)},onStateChange:tvNativeStateChange,
   onAutoplayBlocked:()=>{tvAutoplayBlocked=true;renderTVUI()},
   onError:e=>{$("tvHelp").textContent=`YouTube can't play this video here (error ${e.data}). Some videos forbid embedding.`;}}
 });
}
function tvDestroyPlayer(){
 if(tvPlayer){try{tvPlayer.destroy()}catch{}tvPlayer=null}
 tvPlayerReady=false;tvLoadedId=null;tvAutoplayBlocked=false;
 tvActivated=false;tvLastPlayRevision=-1;
 // YouTube's destroy() may remove the iframe entirely. Always restore a mount node.
 const parent=$("theatreVideoMount");
 if(parent){
  const div=document.createElement("div");div.id="tvVideo";
  parent.replaceChildren(div);
 }
}
function tvRefreshPlayer(force=false){
 if(!tvOpen)return;
 const tv=tvState();
 if(!tv?.videoId){if(tvPlayer)tvDestroyPlayer();return}
 if(!tvPlayer){loadYouTubeApi();return}
 if(!tvPlayerReady)return;
 const target=tvExpectedPosition(tv);
 if(tvLoadedId!==tv.videoId){
  tvLoadedId=tv.videoId;tvAutoplayBlocked=false;tvLastPlayRevision=-1;
  tvSyncingUntil=performance.now()+1600;
  tvPlayer.cueVideoById({videoId:tv.videoId,startSeconds:target});
  return; // User starts the newly queued video explicitly (mobile-safe).
 }
 try{
  const pos=tvPlayer.getCurrentTime();
  if((force||Math.abs(pos-target)>2.3)&&Number.isFinite(pos)){
    tvSyncingUntil=performance.now()+1300;
    tvPlayer.seekTo(target,true);
  }
  const ps=tvPlayer.getPlayerState();
  if(tv.status!=="playing"&&(ps===YT.PlayerState.PLAYING||ps===YT.PlayerState.BUFFERING)){
   tvSyncingUntil=performance.now()+1300;
   tvPlayer.pauseVideo();
  }
  // Only retry automatic play once per revision after an explicit viewer interaction.
  // If iOS blocks it, the user can use Join / Sync or YouTube's native play button.
  if(tv.status==="playing"&&tvActivated&&!tvAutoplayBlocked&&
     ps!==YT.PlayerState.PLAYING&&ps!==YT.PlayerState.BUFFERING&&
     tvLastPlayRevision!==tv.revision){
    tvLastPlayRevision=tv.revision;
    tvSyncingUntil=performance.now()+1300;
    tvPlayer.playVideo();
  }
 }catch{}
}
function tvNativeStateChange(e){
 if(!tvOpen||!tvPlayerReady||!tvState()?.videoId)return;
 if(performance.now()<tvSyncingUntil)return;
 // Native host play/pause works too. Seek only through the explicit shared
 // Seek control: a player buffering must never reset the room clock.
 if(isHost()){
  if(e.data===YT.PlayerState.PLAYING&&tvState().status!=="playing"){
   tvActivated=true;
   tvSyncingUntil=performance.now()+1600;
   // Preserve the server position. Avoid a separate seek packet racing
   // ahead of play and briefly pausing the host's native playback.
   tvCommand("play");
  }else if((e.data===YT.PlayerState.PAUSED||e.data===YT.PlayerState.ENDED)&&tvState().status==="playing"){
   tvSyncingUntil=performance.now()+1300;
   tvCommand("pause");
  }
 }
}
function tvJoinPlayback(){
 const tv=tvState();if(!tv?.videoId)return;
 if(!tvPlayerReady){tvRefreshPlayer();$("tvHelp").textContent="Loading the YouTube player. Tap Join / Sync again when it appears.";return}
 try{
  tvSyncingUntil=performance.now()+1400;
  tvActivated=true;tvLastPlayRevision=tv.revision;
  tvPlayer.seekTo(tvExpectedPosition(tv),true);
  if(tv.status==="playing")tvPlayer.playVideo();
  else tvPlayer.pauseVideo();
  tvAutoplayBlocked=false;renderTVUI();
 }catch{}
}
function openTV(){
 if(currentScene()!=="theatre")return;
 if(!tvState()?.videoId){openTVPanel();return}
 if(tvOpen)return;
 $("emoteTray").classList.add("hidden");
 tvOpen=true;
 renderTVUI();
 if(!tvSyncTimer)tvSyncTimer=setInterval(()=>{
  if(tvOpen&&tvPlayerReady)tvRefreshPlayer();
  tvTimeUpdate();
 },1500);
 tvClockPing();
}
function closeTV(){
 tvOpen=false;
 clearInterval(tvSyncTimer);tvSyncTimer=null;
 tvDestroyPlayer(); // Never stream an invisible video.
 renderTheatreScreen();
}
function openTVPanel(){
 if(currentScene()!=="theatre"||!state)return;
 $("emoteTray").classList.add("hidden");
 tvPanelOpen=true;input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 $("tvModal").classList.remove("hidden");renderTVUI();
}
function closeTVPanel(){
 tvPanelOpen=false;$("tvModal").classList.add("hidden");
}
function handleServerMessage(msg){
 if(!msg)return;

 if(msg.type==="snapshot"){
   const incoming=migrateState(msg.state);
   if(!incoming||incoming.code!==roomCode)return;
   state=incoming;
   acceptBoardSnapshot(incoming.communityBoard);
   joined=true;
   setNetworkStatus("CONNECTED");
   renderPanels();
   if(activityOpen)renderActivityUI();
   if(inventoryOpen)renderInventory();
   updatePhoneHud();
   if(phoneOpen&&phoneApp==="messages")renderPhoneMessages();
   syncSceneUI();
   renderTVUI();
   tvClockPing();

   let patch=null;
   if(resumeProfile){
     patch={...resumeProfile};
     resumeProfile=null;
   }else if(pendingJoinProfile){
     patch={...pendingJoinProfile};
     pendingJoinProfile=null;
   }
   if(patch){
     const p=me();
     if(p)Object.assign(p,patch);
     broadcast("player-update",{patch});
   }
   return;
 }

 if(msg.type==="community-draw"){
   if(state&&Array.isArray(msg.segment))appendBoardStroke(msg.segment);
   return;
 }
 if(msg.type==="community-reset"){
   acceptBoardSnapshot(msg.board);
   if(state)state.communityBoard=msg.board;
   return;
 }
 if(msg.type==="tv-state"){
   if(!state||!msg.tv)return;
   state.tv=msg.tv;
   renderTVUI();
   return;
 }
 if(msg.type==="tv-clock"){
   tvClockReply(msg);
   return;
 }

 if(msg.type==="private-message"){
   receivePrivateMessage(msg.message);
   return;
 }
 if(msg.type==="private-feedback"){
   if(phoneOpen&&phoneApp==="messages")$("phoneMessageStatus").textContent=String(msg.message||"Unable to send message.").slice(0,145);
   return;
 }
 if(msg.type==="inventory-feedback"){
   if(msg.message&&uncleMenuOpen)$("uncleMenuNotice").textContent=String(msg.message).slice(0,120);
   if(msg.message&&inventoryOpen)$("inventoryNotice").textContent=String(msg.message).slice(0,120);
   return;
 }
 if(msg.type==="inventory-state"){
   if(!state)return;
   const p=state.players.find(x=>x.id===msg.id);
   if(p){
    p.inventory=Array.isArray(msg.inventory)?msg.inventory:[];
    p.equippedItem=msg.equippedItem||null;
    if(msg.id===clientId){
     updatePhoneHud();
     if(p.equippedItem!==PERMANENT_PHONE_ID)closePhone();
     if(inventoryOpen)renderInventory();
     if(uncleMenuOpen){
      const notice=$("uncleMenuNotice");
      if(msg.addedItem&&INVENTORY_CATALOG[msg.addedItem]){
       notice.textContent=INVENTORY_CATALOG[msg.addedItem].name+" added to your inventory!";
      }
      renderUncleMenu();
     }
    }
   }
   return;
 }

 if(msg.type==="player-update"){
   if(!state)return;
   const p=state.players.find(x=>x.id===msg.id);
   if(p){
     Object.assign(p,msg.patch||{});
     if(msg.patch&&("x" in msg.patch||"y" in msg.patch))playerMotionUntil.set(msg.id,performance.now()+180);
     const cosmetic=msg.patch&&("hat" in msg.patch||"mask" in msg.patch||"color" in msg.patch||"shape" in msg.patch||"outfit" in msg.patch||"drink" in msg.patch);
     if(cosmetic||"scene" in (msg.patch||{}))renderPanels();
     if(msg.id===clientId&&"scene" in (msg.patch||{}))syncSceneUI();
   }
   return;
 }

 if(msg.type==="chat"){
   if(!state||!msg.message)return;
   state.chat.push(msg.message);
   state.chat=state.chat.slice(-80);
   if(msg.message.senderId){
     chatBubbles.set(msg.message.senderId,{text:msg.message.text,until:performance.now()+5200});
     typingUntil.delete(msg.message.senderId);
   }
   renderChat();
   renderPanels();
   return;
 }

 if(msg.type==="typing"){
   if(!msg.id)return;
   if(msg.active){
     typingUntil.set(msg.id,performance.now()+1800);
     setTimeout(()=>{
       const until=typingUntil.get(msg.id)||0;
       if(until&&until<=performance.now()){typingUntil.delete(msg.id);renderPanels()}
     },1900);
   }else typingUntil.delete(msg.id);
   renderPanels();
   return;
 }

 if(msg.type==="seat-state"){
   const p=playerById(msg.id);if(p){p.seat=msg.seat||null;if(p.seat){const seat=LOUNGE_SEATS.find(s=>s.id===p.seat);if(seat){p.x=seat.x;p.y=seat.y}}}return;
 }

 if(msg.type==="smoke-effect"){
   if(msg.id)smokeEvents.set(msg.id,performance.now());
   return;
 }

 if(msg.type==="emote"){
   if(!msg.id||!msg.emote)return;
   emoteBubbles.set(msg.id,{emote:msg.emote,until:performance.now()+Math.min(3500,EMOTE_DURATIONS[msg.emote]||3500)});
   const p=playerById(msg.id);if(p){p.action=msg.emote;p.actionAt=msg.at||Date.now()}
   return;
 }

 if(msg.type==="presence-state"){
   if(!state||!msg.id)return;
   const p=state.players.find(x=>x.id===msg.id);
   if(p){p.disconnectedAt=msg.connected?null:(msg.at||Date.now());renderPanels()}
   return;
 }

 if(msg.type==="activity-state"){
   if(!state)return;
   state.activity=msg.activity;
   if(activityOpen)renderActivityUI();
   return;
 }

 if(msg.type==="error"){
   if(msg.message==="That lobby is full."&&isPublicRoomCode(roomCode)&&connectMode==="join"&&publicAttempt<PUBLIC_INSTANCE_LIMIT){
     publicAttempt++;
     const code=publicInstanceCode(publicAttempt);
     enterLobby(code);
     openSocket(code,currentName,"join");
     return;
   }
   intentionalClose=true;
   alert(msg.message==="That lobby is full."&&isPublicRoomCode(roomCode)
     ?"The Vibe is busy right now. Please try again shortly."
     :(msg.message||"Could not join The Vibe."));
   leaveRoom(false);
   return;
 }

 if(msg.type==="kicked"){
   intentionalClose=true;
   alert("You were removed from the lobby.");
   leaveRoom(false);
 }
}

function openSocket(code,name,mode){
 clearTimeout(reconnectTimer);
 currentName=name;
 connectMode=mode;
 intentionalClose=false;

 if(socket){
   try{socket.close(1000,"replace")}catch{}
   socket=null;
 }

 setNetworkStatus(mode==="reconnect"?"RECONNECTING":"CONNECTING");

 let ws;
 try{
   ws=new WebSocket(socketAddress(code,name,mode));
 }catch{
   alert("This build needs to be deployed through the included Cloudflare Worker before network lobbies can connect.");
   leaveRoom(false);
   return;
 }
 socket=ws;

 ws.addEventListener("open",()=>{
   if(socket!==ws)return;
   everConnected=true;
   setNetworkStatus("CONNECTED");
 });

 ws.addEventListener("message",e=>{
   if(socket!==ws)return;
   if(e.data==="pong")return;
   try{handleServerMessage(JSON.parse(e.data))}catch{}
 });

 ws.addEventListener("close",()=>{
   if(socket!==ws)return;
   socket=null;

   if(intentionalClose||!roomCode)return;

   const local=me();
   if(local){
     resumeProfile={
       x:local.x,y:local.y,hat:local.hat,mask:local.mask,outfit:local.outfit,drink:local.drink,
       color:local.color,shape:local.shape,scene:local.scene||"lobby"
     };
   }

   if(everConnected){
     setNetworkStatus("RECONNECTING");
     reconnectTimer=setTimeout(()=>{
       if(roomCode&&!intentionalClose)openSocket(roomCode,currentName,"reconnect");
     },1200);
   }else{
     alert("Could not connect to the multiplayer server.");
     leaveRoom(false);
   }
 });
}

function enterLobby(code){
 roomCode=code;
 $("worldWrap").classList.toggle("atrium",isMallAtrium());
 $("roomCodeLabel").textContent=isPublicRoomCode(code)?"THE VIBE":code;
 document.body.classList.remove("landing");
 $("homeView").classList.add("hidden");
 $("lobbyView").classList.remove("hidden");
 clearInterval(heartbeat);
 heartbeat=setInterval(tickHeartbeat,HEARTBEAT_MS);
}

function joinTheVibe(){
 const name=$("nameInput").value.trim().replace(/\s+/g," ").slice(0,18);
 if(!name){
   $("homeError").textContent="Enter a display name to join.";
   $("nameInput").focus();
   return;
 }
 $("nameInput").value=name;
 $("homeError").textContent="";
 pendingJoinProfile={color:homeColorChoice,shape:homeShapeChoice};
 publicAttempt=1;
 state=null;joined=false;everConnected=false;
 enterLobby(PUBLIC_CODE);
 openSocket(PUBLIC_CODE,name,"join");
}

function leaveRoom(send=true){
 intentionalClose=true;
 clearTimeout(reconnectTimer);
 reconnectTimer=null;
 clearInterval(heartbeat);
 heartbeat=null;

 if(socket){
   if(send&&socket.readyState===WebSocket.OPEN){
     try{socket.send(JSON.stringify({type:"leave",payload:{}}))}catch{}
   }
   try{socket.close(1000,"leave")}catch{}
   socket=null;
 }

 $("worldWrap").classList.remove("atrium");
 roomCode=null;state=null;joined=false;everConnected=false;resumeProfile=null;closeCommunityBoard();acceptBoardSnapshot(null);
 phoneUnread.clear();phoneMessages.clear();phoneThreadId=null;phoneRoomKey=null;updatePhoneHud();stopPhoneFlappy();
 uncleWasOccupied=false;uncleGreetingUntil=0;closeInventory();
 tvClockBestRtt=Infinity;tvClockOffset=0;closeTV();closeTVPanel();
 chatBubbles.clear();typingUntil.clear();emoteBubbles.clear();playerMotionUntil.clear();smokeEvents.clear();
 clearTimeout(typingStopTimer);$("emoteTray").classList.add("hidden");
 input.x=input.y=0;
 setNetworkStatus("NETWORK");
 $("lobbyView").classList.add("hidden");
 document.body.classList.add("landing");
 $("homeView").classList.remove("hidden");
 publicAttempt=1;
 closeWardrobe();
 closeActivity();
 closeFridge();
 syncSceneUI();
}

function tickHeartbeat(){
 if(socket&&socket.readyState===WebSocket.OPEN){
   broadcast("presence",{});
   tvClockPing();
 }
}

function renderPanels(){
 if(!state)return;
 $("roomStatus").textContent=isPublicRoomCode(roomCode)?"PUBLIC HUB":state.locked?"LOCKED":"OPEN";
 $("playerCount").textContent=`${state.players.length} / ${MAX_PLAYERS}`;
 $("lockBtn").classList.toggle("hidden",!isHost()||isPublicRoomCode(roomCode));
 $("lockBtn").textContent=state.locked?"Unlock":"Lock";

 const players=$("players");players.innerHTML="";
 for(const p of [...state.players].sort((a,b)=>(a.id===state.hostId?-1:0)-(b.id===state.hostId?-1:0)||a.joinedAt-b.joinedAt)){
   const row=document.createElement("div");row.className="player";
   const av=document.createElement("div");av.className="avatar";av.textContent=(p.name[0]||"?").toUpperCase();
   const body=document.createElement("div");
   const nm=document.createElement("div");nm.className="playerName";nm.textContent=p.name+(p.id===clientId?" (You)":"");
   if(p.id===state.hostId){const h=document.createElement("span");h.className="pill host";h.textContent="HOST";nm.appendChild(h)}
   const meta=document.createElement("div");meta.className="meta";
   if(p.disconnectedAt)meta.textContent="Reconnecting…";
   else if((typingUntil.get(p.id)||0)>performance.now())meta.textContent="Typing…";
   else meta.textContent=(p.scene==="theatre"?"Theatre":p.scene==="mall"?"Mall Walk":p.scene==="artifact"?"The Artifact":p.scene==="looks"?"Looks Max Inc.":p.scene==="media"?"Media Master":isPublicRoomCode(roomCode)?"The Vibe":"Lobby");
   body.append(nm,meta);
   const act=document.createElement("div");
   if(isHost()&&!isPublicRoomCode(roomCode)&&p.id!==clientId){
     const kick=document.createElement("button");kick.className="btn bad";kick.textContent="Kick";
     kick.addEventListener("click",()=>{broadcast("kick",{target:p.id})});
     act.appendChild(kick)
   }
   row.append(av,body,act);players.appendChild(row)
 }
 renderChat()
}
function renderChat(){
 if(!state)return;const el=$("chat");el.innerHTML="";
 for(const m of state.chat.slice(-50)){
   const div=document.createElement("div");div.className="msg"+(m.type==="system"?" system":"");
   if(m.type==="system")div.textContent=m.text;
   else{const b=document.createElement("b");b.textContent=m.name+": ";div.append(b,document.createTextNode(m.text))}
   el.appendChild(div)
 }
 el.scrollTop=el.scrollHeight
}
function sendChat(){
 const text=$("chatInput").value.trim().slice(0,120);
 if(!text||!state||!me())return;
 broadcast("chat",{text});
 typingUntil.delete(clientId);
 broadcast("typing",{active:false});
 clearTimeout(typingStopTimer);
 $("chatInput").value="";
}

function noteTyping(){
 if(!state||!me())return;
 const active=$("chatInput").value.trim().length>0;
 const t=performance.now();
 if(active){
   typingUntil.set(clientId,t+1800);
   if(t-lastTypingBroadcast>500){
     lastTypingBroadcast=t;
     broadcast("typing",{active:true});
   }
   clearTimeout(typingStopTimer);
   typingStopTimer=setTimeout(()=>{
     typingUntil.delete(clientId);
     broadcast("typing",{active:false});
   },1400);
 }else{
   typingUntil.delete(clientId);
   broadcast("typing",{active:false});
   clearTimeout(typingStopTimer);
 }
}

const emoteLabels={wave:"WAVE!",heart:"♥",laugh:"HA!",wow:"!",gg:"GG",cheer:"YEAH!",point:"LOOK!",facepalm:"OH NO",dance:"DANCING",sleep:"ZZZ"};
function sendEmote(emote){
 if(!state||!me()||!(emote in emoteLabels))return;
 emoteBubbles.set(clientId,{emote,until:performance.now()+Math.min(3500,EMOTE_DURATIONS[emote])});
 const p=me();p.action=emote;p.actionAt=Date.now();
 broadcast("emote",{emote});
 $("emoteTray").classList.add("hidden");
}
function toggleEmotes(){
 if(!state)return;
 $("emoteTray").classList.toggle("hidden");
}

function playerPhase(id){
 let h=0;for(let i=0;i<id.length;i++)h=(h*31+id.charCodeAt(i))>>>0;
 return (h%628)/100;
}
function wrapBubbleText(text,maxWidth){
 const words=String(text||"").slice(0,86).split(/\s+/).filter(Boolean);
 const lines=[];let line="";
 for(const word of words){
   const test=line?line+" "+word:word;
   if(ctx.measureText(test).width>maxWidth&&line){lines.push(line);line=word}
   else line=test;
   if(lines.length>=3)break;
 }
 if(line&&lines.length<3)lines.push(line);
 if(words.length&&lines.length===3){
   let last=lines[2];
   while(last.length&&ctx.measureText(last+"…").width>maxWidth)last=last.slice(0,-1);
   lines[2]=last+"…";
 }
 return lines.length?lines:["…"];
}
function drawPresenceBubble(x,anchorY,text,kind="chat"){
 ctx.save();
 ctx.font=kind==="typing"?"900 14px -apple-system,sans-serif":"800 12px -apple-system,sans-serif";
 ctx.textAlign="center";ctx.textBaseline="middle";
 const maxText=kind==="emote"?100:172;
 const lines=kind==="emote"?[text]:wrapBubbleText(text,maxText);
 let widest=0;for(const line of lines)widest=Math.max(widest,ctx.measureText(line).width);
 const w=Math.max(kind==="typing"?48:kind==="emote"?58:76,widest+20);
 const h=kind==="chat"?lines.length*16+18:38;
 const bx=clamp(x-w/2,8,WORLD_W-w-8);
 const by=Math.max(8,anchorY-h);
 ctx.fillStyle=kind==="emote"?"#263847ee":"#0b1118ee";
 ctx.strokeStyle=kind==="emote"?"#8ecde7aa":"#ffffff38";
 ctx.lineWidth=2;
 ctx.beginPath();ctx.roundRect(bx,by,w,h,12);ctx.fill();ctx.stroke();
 const tipX=clamp(x,bx+14,bx+w-14);
 ctx.fillStyle=kind==="emote"?"#263847ee":"#0b1118ee";
 ctx.beginPath();ctx.moveTo(tipX-7,by+h-1);ctx.lineTo(tipX+7,by+h-1);ctx.lineTo(x,anchorY+3);ctx.closePath();ctx.fill();
 ctx.fillStyle="#f4f8fd";
 if(kind==="chat"){
   for(let i=0;i<lines.length;i++)ctx.fillText(lines[i],bx+w/2,by+13+i*16);
 }else ctx.fillText(text,bx+w/2,by+h/2);
 ctx.restore();
}
function drawSocialPresence(p,visualY,s){
 const t=performance.now();
 const chat=chatBubbles.get(p.id);
 if(chat&&chat.until<=t)chatBubbles.delete(p.id);
 const emote=emoteBubbles.get(p.id);
 if(emote&&emote.until<=t)emoteBubbles.delete(p.id);
 const typing=(typingUntil.get(p.id)||0)>t;
 const anchor=visualY-s.h/2-14;
 if(chat&&chat.until>t)drawPresenceBubble(p.x,anchor,chat.text,"chat");
 else if(emote&&emote.until>t)drawPresenceBubble(p.x,anchor,emoteLabels[emote.emote]||emote.emote,"emote");
 else if(typing)drawPresenceBubble(p.x,anchor,"•••","typing");
}

const canvas=$("world"),ctx=canvas.getContext("2d");
function drawRoomBackdrop(){
 // Back wall
 const wall=ctx.createLinearGradient(0,0,0,175);
 wall.addColorStop(0,"#1c2a38");
 wall.addColorStop(1,"#243645");
 ctx.fillStyle=wall;
 ctx.fillRect(0,0,WORLD_W,175);

 // subtle wall panels
 ctx.strokeStyle="#ffffff09";
 ctx.lineWidth=1;
 for(let x=0;x<=WORLD_W;x+=70){
   ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,175);ctx.stroke();
 }

 // baseboard
 ctx.fillStyle="#0d151d";
 ctx.fillRect(0,166,WORLD_W,13);
 ctx.fillStyle="#405264";
 ctx.fillRect(0,166,WORLD_W,2);

 // Main floor
 const floor=ctx.createLinearGradient(0,175,0,WORLD_H);
 floor.addColorStop(0,"#263947");
 floor.addColorStop(1,"#17242d");
 ctx.fillStyle=floor;
 ctx.fillRect(0,175,WORLD_W,WORLD_H-175);

 // floorboards
 ctx.strokeStyle="#0d18215c";
 ctx.lineWidth=2;
 for(let y=205;y<WORLD_H;y+=44){
   ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(WORLD_W,y);ctx.stroke();
 }
 for(let row=0,y=205;y<WORLD_H;y+=44,row++){
   const offset=(row%2)*58;
   for(let x=offset;x<WORLD_W;x+=116){
     ctx.beginPath();ctx.moveTo(x,y-44);ctx.lineTo(x,y);ctx.stroke();
   }
 }

 // large lounge rug - keeps the middle feeling intentional while still open
 ctx.save();
 ctx.fillStyle="#24384a";
 ctx.strokeStyle="#6d8ca344";
 ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(205,245,305,225,30);ctx.fill();ctx.stroke();
 ctx.strokeStyle="#8fb5c322";
 ctx.lineWidth=2;
 ctx.beginPath();ctx.roundRect(225,265,265,185,24);ctx.stroke();
 ctx.beginPath();ctx.arc(358,357,58,0,Math.PI*2);ctx.stroke();
 ctx.beginPath();ctx.arc(358,357,32,0,Math.PI*2);ctx.stroke();
 ctx.restore();

 // activity rug
 ctx.fillStyle="#1a2835";
 ctx.strokeStyle="#78d6ff26";
 ctx.lineWidth=3;
 ctx.beginPath();ctx.roundRect(20,554,182,150,22);ctx.fill();ctx.stroke();

}

function drawWindow(){
 const x=248,y=34,w=204,h=98;
 ctx.save();
 ctx.fillStyle="#111a24";
 ctx.strokeStyle="#61788c";
 ctx.lineWidth=5;
 ctx.beginPath();ctx.roundRect(x,y,w,h,10);ctx.fill();ctx.stroke();

 // night sky
 const sky=ctx.createLinearGradient(0,y,0,y+h);
 sky.addColorStop(0,"#08111f");
 sky.addColorStop(1,"#17314a");
 ctx.fillStyle=sky;
 ctx.fillRect(x+7,y+7,w-14,h-14);

 // moon glow
 ctx.shadowBlur=14;ctx.shadowColor="#dcecff88";
 ctx.fillStyle="#dcecff";
 ctx.beginPath();ctx.arc(x+w-42,y+28,11,0,Math.PI*2);ctx.fill();
 ctx.shadowBlur=0;

 // stars
 const stars=[[18,20],[39,37],[61,19],[87,30],[112,16],[132,43],[151,24],[175,48],[24,57],[73,61],[119,67],[162,65]];
 for(let i=0;i<stars.length;i++){
   const [sx,sy]=stars[i];
   const tw=.45+.45*Math.sin((ambientTick+i*13)*.035);
   ctx.globalAlpha=tw;
   ctx.fillStyle="#f4fbff";
   ctx.fillRect(x+8+sx,y+8+sy,2,2);
 }
 ctx.globalAlpha=1;

 // simple distant skyline
 const buildings=[
   [0,24,15],[18,35,9],[41,29,14],[68,41,10],[86,31,13],
   [111,45,8],[128,34,12],[151,39,10],[170,27,13]
 ];
 ctx.fillStyle="#0a1722";
 for(const [bx,bh,bw] of buildings)ctx.fillRect(x+7+bx,y+h-7-bh,bw,bh);

 // panes
 ctx.strokeStyle="#71879a";
 ctx.lineWidth=3;
 ctx.beginPath();ctx.moveTo(x+w/2,y+6);ctx.lineTo(x+w/2,y+h-6);ctx.stroke();
 ctx.beginPath();ctx.moveTo(x+6,y+h/2);ctx.lineTo(x+w-6,y+h/2);ctx.stroke();

 ctx.restore();
}

function drawStringLights(){
 ctx.save();
 ctx.strokeStyle="#40566a";
 ctx.lineWidth=2;
 ctx.beginPath();
 ctx.moveTo(175,18);
 ctx.bezierCurveTo(285,43,415,43,525,18);
 ctx.stroke();

 for(let i=0;i<10;i++){
   const t=i/9;
   const x=175+(525-175)*t;
   const y=18+24*Math.sin(Math.PI*t);
   const pulse=.65+.25*Math.sin(ambientTick*.035+i);
   ctx.fillStyle=`rgba(255,220,146,${pulse})`;
   ctx.shadowBlur=9;ctx.shadowColor="#ffd87a";
   ctx.beginPath();ctx.arc(x,y+6,4,0,Math.PI*2);ctx.fill();
 }
 ctx.shadowBlur=0;
 ctx.restore();
}

function drawPlant(x,y,scale=1){
 ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);
 ctx.fillStyle="#704f3a";
 ctx.beginPath();ctx.roundRect(-17,14,34,27,7);ctx.fill();
 ctx.fillStyle="#2e774f";
 for(const a of[-1.15,-.72,-.35,0,.4,.82,1.18]){
   ctx.save();ctx.rotate(a*.45);
   ctx.beginPath();ctx.ellipse(0,-1,7,28,0,0,Math.PI*2);ctx.fill();
   ctx.restore();
 }
 ctx.fillStyle="#3d9564";
 ctx.beginPath();ctx.ellipse(-7,-7,6,23,-.42,0,Math.PI*2);ctx.fill();
 ctx.restore();
}

function drawLoungeFurniture(){
 // sofa shadow
 ctx.fillStyle="#07101855";
 ctx.beginPath();ctx.ellipse(564,510,92,30,0,0,Math.PI*2);ctx.fill();

 // sofa
 ctx.fillStyle="#34495c";ctx.strokeStyle="#60798e";ctx.lineWidth=3;
 ctx.beginPath();ctx.roundRect(488,446,164,78,24);ctx.fill();ctx.stroke();
 ctx.fillStyle="#293b4b";
 ctx.beginPath();ctx.roundRect(501,459,64,48,17);ctx.fill();
 ctx.beginPath();ctx.roundRect(575,459,64,48,17);ctx.fill();
 ctx.fillStyle="#506d80";
 ctx.beginPath();ctx.roundRect(484,458,18,55,9);ctx.fill();
 ctx.beginPath();ctx.roundRect(638,458,18,55,9);ctx.fill();

 // pillows
 ctx.fillStyle="#b08072";
 ctx.beginPath();ctx.roundRect(512,466,27,21,8);ctx.fill();
 ctx.fillStyle="#7397a5";
 ctx.beginPath();ctx.roundRect(601,468,25,19,8);ctx.fill();

 ctx.fillStyle="#c8e8f7";ctx.font="800 10px sans-serif";ctx.textAlign="center";
 ctx.fillText("SIT",532,501);ctx.fillText("SIT",606,501);
 // coffee table
 ctx.fillStyle="#10182055";
 ctx.beginPath();ctx.ellipse(416,528,59,20,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#70513d";ctx.strokeStyle="#9a7357";ctx.lineWidth=3;
 ctx.beginPath();ctx.roundRect(365,498,100,49,16);ctx.fill();ctx.stroke();
 ctx.fillStyle="#d6c4a9";
 ctx.beginPath();ctx.arc(401,520,7,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#789b7c";
 ctx.beginPath();ctx.arc(433,516,8,0,Math.PI*2);ctx.fill();

 // Table-side glass bong: close interaction triggers a synchronized smoke puff.
 drawBong();

 // standing lamp
 ctx.strokeStyle="#8c7d67";ctx.lineWidth=5;
 ctx.beginPath();ctx.moveTo(671,520);ctx.lineTo(671,422);ctx.stroke();
 ctx.fillStyle="#d6c08b";
 ctx.beginPath();ctx.moveTo(650,420);ctx.lineTo(692,420);ctx.lineTo(684,447);ctx.lineTo(658,447);ctx.closePath();ctx.fill();
 ctx.fillStyle="#8c7d67";
 ctx.beginPath();ctx.ellipse(671,522,20,7,0,0,Math.PI*2);ctx.fill();

 // plants in opposite corners
 drawPlant(200,120,.82);
 drawPlant(646,295,.9);
}

function drawBong(){
 const d=BONG;
 ctx.save();ctx.translate(d.x,d.y);
 ctx.fillStyle="#42cfbd77";ctx.strokeStyle="#b9f9ee";ctx.lineWidth=2;
 ctx.beginPath();ctx.roundRect(-8,16,17,17,6);ctx.fill();ctx.stroke();
 ctx.beginPath();ctx.moveTo(-4,16);ctx.lineTo(-1,-12);ctx.lineTo(7,-12);ctx.lineTo(5,16);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.strokeStyle="#bddcce";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(8,15);ctx.lineTo(16,4);ctx.stroke();
 ctx.fillStyle="#d9b98b";ctx.beginPath();ctx.ellipse(16,3,6,3,0,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle="#d8fff4";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-3,-11);ctx.lineTo(9,-11);ctx.stroke();
 ctx.restore();
}
function drawFridge(){
 const d=FRIDGE;ctx.save();ctx.translate(d.x,d.y);
 ctx.fillStyle="#06101870";ctx.beginPath();ctx.ellipse(d.w/2,d.h+8,65,13,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#d6e3ea";ctx.strokeStyle="#f4fdff";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(0,0,d.w,d.h,12);ctx.fill();ctx.stroke();
 ctx.fillStyle="#a5b6c3";ctx.fillRect(4,52,d.w-8,4);
 ctx.fillStyle="#f8ffffa8";ctx.beginPath();ctx.roundRect(9,9,d.w-18,36,5);ctx.fill();
 ctx.fillStyle="#778a99";ctx.beginPath();ctx.roundRect(d.w-20,18,7,26,4);ctx.fill();ctx.roundRect(d.w-20,69,7,47,4);ctx.fill();
 ctx.fillStyle="#2b516a";ctx.textAlign="center";ctx.font="900 14px sans-serif";ctx.fillText("FRIDGE",d.w/2,32);
 ctx.fillStyle="#7eecff";ctx.fillRect(15,67,8,5);
 ctx.restore();
}
function drawWallDecor(){
 // two small framed prints
 const frames=[
   {x:181,y:52,w:45,h:62,c:"#8f6d70"},
   {x:474,y:58,w:50,h:56,c:"#6b8793"}
 ];
 for(const f of frames){
   ctx.fillStyle="#101820";ctx.strokeStyle="#7d8c98";ctx.lineWidth=3;
   ctx.beginPath();ctx.roundRect(f.x,f.y,f.w,f.h,5);ctx.fill();ctx.stroke();
   ctx.fillStyle=f.c;
   ctx.fillRect(f.x+7,f.y+7,f.w-14,f.h-14);
   ctx.fillStyle="#ffffff27";
   ctx.beginPath();ctx.arc(f.x+f.w*.62,f.y+f.h*.35,7,0,Math.PI*2);ctx.fill();
 }
}

function drawActivityTable(){
 ctx.save();
 ctx.translate(ACTIVITY.x,ACTIVITY.y);

 // shadow
 ctx.fillStyle="#07101855";
 ctx.beginPath();ctx.ellipse(ACTIVITY.w/2,ACTIVITY.h-2,70,22,0,0,Math.PI*2);ctx.fill();

 // legs
 ctx.fillStyle="#3b4653";
 ctx.fillRect(18,86,14,28);ctx.fillRect(ACTIVITY.w-32,86,14,28);

 // table body
 ctx.fillStyle="#33404f";ctx.strokeStyle="#64758a";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(0,0,ACTIVITY.w,ACTIVITY.h-13,18);ctx.fill();ctx.stroke();

 // inset game surface
 ctx.fillStyle="#101820";ctx.strokeStyle="#7fd4ff55";ctx.lineWidth=2;
 ctx.beginPath();ctx.roundRect(15,14,ACTIVITY.w-30,64,12);ctx.fill();ctx.stroke();

 // little game pieces / grid
 ctx.strokeStyle="#b9d7ef7a";ctx.lineWidth=2;
 for(let i=1;i<3;i++){
   ctx.beginPath();ctx.moveTo(38+i*23,25);ctx.lineTo(38+i*23,67);ctx.stroke();
   ctx.beginPath();ctx.moveTo(38,25+i*14);ctx.lineTo(107,25+i*14);ctx.stroke();
 }
 ctx.fillStyle="#ff7676";ctx.beginPath();ctx.arc(28,33,6,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#ffd166";ctx.beginPath();ctx.arc(121,59,6,0,Math.PI*2);ctx.fill();

 ctx.fillStyle="#edf6ff";ctx.font="900 12px -apple-system,sans-serif";ctx.textAlign="center";
 ctx.fillText("ACTIVITY TABLE",ACTIVITY.w/2,95);
 ctx.restore();
}

function drawWardrobe(){
 ctx.save();
 ctx.translate(WARDROBE.x,WARDROBE.y);

 // shadow
 ctx.fillStyle="#07101850";
 ctx.beginPath();ctx.ellipse(WARDROBE.w/2,WARDROBE.h+8,54,14,0,0,Math.PI*2);ctx.fill();

 // top cap
 ctx.fillStyle="#765744";ctx.strokeStyle="#a47a5a";ctx.lineWidth=3;
 ctx.beginPath();ctx.roundRect(-5,-7,WARDROBE.w+10,16,6);ctx.fill();ctx.stroke();

 // body
 ctx.fillStyle="#604838";ctx.strokeStyle="#9b7355";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(0,4,WARDROBE.w,WARDROBE.h-4,10);ctx.fill();ctx.stroke();

 // inset door panels
 ctx.fillStyle="#513b2f";
 ctx.beginPath();ctx.roundRect(8,13,WARDROBE.w/2-13,WARDROBE.h-25,7);ctx.fill();
 ctx.beginPath();ctx.roundRect(WARDROBE.w/2+5,13,WARDROBE.w/2-13,WARDROBE.h-25,7);ctx.fill();

 ctx.strokeStyle="#2f231d";ctx.lineWidth=3;
 ctx.beginPath();ctx.moveTo(WARDROBE.w/2,7);ctx.lineTo(WARDROBE.w/2,WARDROBE.h-4);ctx.stroke();

 ctx.fillStyle="#d9b46f";
 ctx.beginPath();ctx.arc(WARDROBE.w/2-8,WARDROBE.h/2,3.5,0,Math.PI*2);ctx.fill();
 ctx.beginPath();ctx.arc(WARDROBE.w/2+8,WARDROBE.h/2,3.5,0,Math.PI*2);ctx.fill();

 ctx.fillStyle="#f2dfc4";ctx.font="900 12px -apple-system,sans-serif";ctx.textAlign="center";
 ctx.fillText("WARDROBE",WARDROBE.w/2,WARDROBE.h+22);
 ctx.restore();
}


// The Vibe is the public hub. Its background and furniture are deliberately
// separate from the private room while all interactable props keep their
// original coordinates, so the Durable Object/game/TV/seat logic is unchanged.

// v0.15.2: hinged double doors. The outer jamb of each glass leaf stays
// stationary while the inner edge swings OUT toward the approaching viewer.
// This is visual only; the underlying synchronized presence code is unchanged.
function drawAtriumSwingDoors(c){
 const x=249,y=234,w=202,h=72,half=w/2;
 // Roughly 48 degrees at full proximity. The vanishing-point projection makes
 // the free door edges look nearer to the viewer as the panels swing open.
 const angle=atriumDoorOpen*Math.PI*48/180;
 const projectedWidth=half*Math.cos(angle);
 const depth=half*Math.sin(angle);
 const perspective=420/(420-depth);
 const centerX=x+half,centerY=y+h/2;
 c.save();
 // The revealed vestibule is confined to the doorway, unlike the moving leaves.
 c.beginPath();c.rect(x,y,w,h);c.clip();
 const back=c.createLinearGradient(0,y,0,y+h);
 back.addColorStop(0,"#243948");back.addColorStop(1,"#081923");
 c.fillStyle=back;c.fillRect(x,y,w,h);
 c.fillStyle="#9de9e817";c.fillRect(centerX-14,y,28,h);
 c.strokeStyle="#7c9ba5";c.lineWidth=3;c.strokeRect(x+1,y+1,w-2,h-2);
 c.restore();
 // Draw both doors after unclipping: swung-out edges can extend slightly
 // toward the floor. A sliding-door clip would incorrectly crop that depth.
 for(const left of [true,false]){
  const hingeX=left?x:x+w;
  const edgeWorldX=hingeX+(left?projectedWidth:-projectedWidth);
  const nearX=centerX+(edgeWorldX-centerX)*perspective;
  const nearTopY=centerY+(y-centerY)*perspective;
  const nearBottomY=centerY+(y+h-centerY)*perspective;
  function at(t,v){
   const xVal=hingeX+(nearX-hingeX)*t;
   const top=y+(nearTopY-y)*t;
   const bottom=y+h+(nearBottomY-(y+h))*t;
   return [xVal,top+(bottom-top)*v];
  }
  function polygon(points){
   c.beginPath();c.moveTo(...points[0]);
   for(let i=1;i<points.length;i++)c.lineTo(...points[i]);
   c.closePath();
  }
  const corners=[at(0,0),at(1,0),at(1,1),at(0,1)];
  c.save();
  polygon(corners);
  const face=c.createLinearGradient(hingeX,y,nearX,y);
  face.addColorStop(0,"#3d7182");
  face.addColorStop(.52,"#285066");
  face.addColorStop(1,"#122e42");
  c.fillStyle=face;c.fill();
  c.strokeStyle="#a7c5c4";c.lineWidth=2.3;c.stroke();
  // Perspective-aligned highlights and glass reflections.
  polygon([at(.11,.03),at(.24,.03),at(.54,.96),at(.43,.96)]);
  c.fillStyle="#d0f7f51e";c.fill();
  c.beginPath();c.moveTo(...at(.07,.04));c.lineTo(...at(.07,.96));
  c.strokeStyle="#c6f4eb40";c.lineWidth=1.7;c.stroke();
  // Pull bars remain attached to each door, rotating with the glass.
  c.beginPath();c.moveTo(...at(.90,.38));c.lineTo(...at(.90,.74));
  c.strokeStyle="#d9ede7";c.lineWidth=4;c.lineCap="round";c.stroke();
  c.strokeStyle="#688d98";c.lineWidth=1;c.stroke();
  // Accent the approaching free edge: this line visibly leaves the door frame.
  c.beginPath();c.moveTo(...at(1,0));c.lineTo(...at(1,1));
  c.strokeStyle="#d3e8e2b8";c.lineWidth=2;c.stroke();
  c.restore();
 }
 // Fixed doorway threshold and outer jambs stay in place.
 c.fillStyle="#627e84";c.fillRect(x,y+h-3,w,3);
 c.strokeStyle="#74949e";c.lineWidth=3;
 c.beginPath();c.moveTo(x,y);c.lineTo(x,y+h);
 c.moveTo(x+w,y);c.lineTo(x+w,y+h);c.stroke();
}


// v0.16.1: the mall is a different synchronized scene reached through the
// actual center atrium doors. All shops are decorative placeholders.
const MEDIA_MASTER_ENABLED=false; // Reserved for the future cinema-store release.
const MALL_STORES=[
 {x:310,w:290,name:"LOOKS MAX INC.",accent:"#c98cfc",id:"looks"},
 {x:660,w:290,name:"UNCLE AL'S",accent:"#8fcac1",id:"food"},
 {x:1010,w:640,name:"THE ARTIFACT",accent:"#b89aff",id:"artifact"},
 {x:1710,w:290,name:"SPACE 05",accent:"#89c7bd"}
];
function drawLooksMaxStorefront(c,s){
 const {x,w}=s,cx=x+w/2,y=151,h=205;
 c.save();
 // Matte charcoal facade and high-end illuminated signage.
 c.fillStyle="#101622";c.beginPath();c.roundRect(x-8,y-16,w+16,h+21,7);c.fill();
 c.strokeStyle="#9574b9";c.lineWidth=5;c.strokeRect(x-8,y-16,w+16,h+21);
 const sign=c.createLinearGradient(x,y,x+w,y);
 sign.addColorStop(0,"#24132e");sign.addColorStop(.5,"#432346");sign.addColorStop(1,"#162837");
 c.fillStyle=sign;c.fillRect(x-1,y-9,w+2,54);
 c.fillStyle="#dfc7fa";c.textAlign="center";c.font="1000 24px system-ui,sans-serif";
 c.shadowColor="#bf70fa";c.shadowBlur=16;c.fillText("LOOKS MAX INC.",cx,y+23);c.shadowBlur=0;
 c.fillStyle="#5fe2de";c.fillRect(x+20,y+34,w-40,3);
 const pane=c.createLinearGradient(0,y+48,0,y+h);
 pane.addColorStop(0,"#526a86");pane.addColorStop(1,"#0e1526");
 c.fillStyle=pane;c.fillRect(x+9,y+47,w-18,h-53);
 // Display windows: two color-cycling neon poles and retail signs, no mannequins.
 // The two poles exchange purple and aqua shades on opposite phases.
 const phase=(Math.sin(performance.now()*0.00057)+1)/2;
 const blend=(a,b,t)=>Math.round(a+(b-a)*t);
 const tubeColor=t=>`rgb(${blend(202,84,t)},${blend(111,228,t)},${blend(244,223,t)})`;
 for(const side of [-1,1]){
  const wx=cx+side*102;
  const left=side<0;
  const neon=tubeColor(left?phase:1-phase);
  const windowX=wx-34,windowY=y+49;
  // Deep charcoal show window, outlined with satin metal trim.
  c.fillStyle="#111827";c.fillRect(windowX,windowY,68,142);
  const windowGlass=c.createLinearGradient(0,windowY,0,windowY+142);
  windowGlass.addColorStop(0,"#30344f");windowGlass.addColorStop(1,"#101e2c");
  c.fillStyle=windowGlass;c.fillRect(windowX+4,windowY+4,60,134);
  c.strokeStyle="#627789";c.lineWidth=2;c.strokeRect(windowX,windowY,68,142);
  // Upper-window signs are not interaction instructions.
  c.fillStyle="#101724de";c.beginPath();c.roundRect(wx-30,y+56,60,39,5);c.fill();
  c.strokeStyle=left?"#b9e8e5":"#c79be0";c.lineWidth=1.2;c.stroke();
  c.save();c.textAlign="center";
  if(left){
   c.shadowColor="#f989bd";c.shadowBlur=9;c.fillStyle="#ffb8d5";
   c.font="1000 17px system-ui,sans-serif";c.fillText("OPEN",wx,y+82);
  }else{
   c.shadowColor="#d4a3ff";c.shadowBlur=7;c.fillStyle="#f3d8fc";
   c.font="900 10px system-ui,sans-serif";c.fillText("NOW",wx,y+71);
   c.font="900 11px system-ui,sans-serif";c.fillText("HIRING!",wx,y+85);
  }
  c.restore();
  // One narrow vertical neon tube on each side, fading between their colors.
  const tubeX=wx+(left?-22:22);
  c.save();c.shadowColor=neon;c.shadowBlur=17;
  c.strokeStyle=neon;c.lineWidth=6;c.lineCap="round";
  c.beginPath();c.moveTo(tubeX,y+108);c.lineTo(tubeX,y+171);c.stroke();
  c.shadowBlur=0;c.strokeStyle="#f1ffffaa";c.lineWidth=1.4;
  c.beginPath();c.moveTo(tubeX-1,y+109);c.lineTo(tubeX-1,y+170);c.stroke();
  c.fillStyle="#6d7786";c.fillRect(tubeX-5,y+104,10,4);c.fillRect(tubeX-5,y+173,10,4);
  c.restore();
 }
 // Fixed storefront opening. Both leaves hinge outward based on nearby players.
 const dx=cx-68,dy=y+57,dw=136,dh=135,o=clamp(looksDoorOpen,0,1);
 c.fillStyle="#101827";c.fillRect(dx-7,dy-7,dw+14,dh+11);
 c.strokeStyle="#a6a8bd";c.lineWidth=4;c.strokeRect(dx-7,dy-7,dw+14,dh+11);
 c.strokeStyle="#c79bec";c.lineWidth=2;c.strokeRect(dx-3,dy-3,dw+6,dh+3);
 c.fillStyle="#322444";c.fillRect(dx,dy,dw,dh);
 c.fillStyle="#f5b8ff20";c.fillRect(dx+15,dy+6,dw-30,dh-12);
 const half=dw/2;
 for(const side of [-1,1]){
  const hinge=side<0?dx:dx+dw;
  const tip=side<0?dx+half:dx+half;
  const tw=half*(1-.72*o);
  const free=hinge-side*tw;
  c.beginPath();c.moveTo(hinge,dy);c.lineTo(free,dy+o*9);
  c.lineTo(free,dy+dh+o*14);c.lineTo(hinge,dy+dh);c.closePath();
  const paneDoor=c.createLinearGradient(hinge,0,free,0);
  paneDoor.addColorStop(0,"#2e566e");paneDoor.addColorStop(1,"#121e37");
  c.fillStyle=paneDoor;c.fill();c.strokeStyle="#bac8d2";c.lineWidth=2.5;c.stroke();
  c.strokeStyle="#c7f5f866";c.lineWidth=4;c.beginPath();
  c.moveTo(hinge+(free-hinge)*.25,dy+9);c.lineTo(hinge+(free-hinge)*.25,dy+dh-10);c.stroke();
  c.strokeStyle="#e6e3ef";c.lineWidth=3;c.beginPath();
  const hx=hinge+(free-hinge)*.76;c.moveTo(hx,dy+59);c.lineTo(hx,dy+83);c.stroke();
 }
 c.fillStyle="#b6c4ce";c.fillRect(dx-10,dy+dh,dw+20,6);
 c.restore();
}
function drawMediaMasterStorefront(c,s){
 const x=s.x,w=s.w,cx=x+w/2,y=151,h=205;
 c.save();
 // Black/brass picture-palace facade with marquee trim.
 c.fillStyle="#10151d";c.beginPath();c.roundRect(x-8,y-16,w+16,h+22,6);c.fill();
 c.strokeStyle="#bba06c";c.lineWidth=5;c.strokeRect(x-8,y-16,w+16,h+22);
 c.fillStyle="#1b1d29";c.fillRect(x,y-8,w,53);
 c.fillStyle="#e8d4a2";c.textAlign="center";c.font="1000 25px system-ui,sans-serif";
 c.shadowColor="#ffd68b";c.shadowBlur=12;c.fillText("MEDIA MASTER",cx,y+27);c.shadowBlur=0;
 c.fillStyle="#725038";c.fillRect(x+8,y+39,w-16,6);
 for(let i=0;i<14;i++){
  const px=x+16+i*20;
  c.fillStyle="#ffe7a0";c.shadowColor="#ffce6b";c.shadowBlur=7;
  c.beginPath();c.arc(px,y+42,2.5,0,Math.PI*2);c.fill();
 }
 c.shadowBlur=0;
 const wall=c.createLinearGradient(0,y+46,0,y+h);
 wall.addColorStop(0,"#333244");wall.addColorStop(1,"#141c29");
 c.fillStyle=wall;c.fillRect(x+8,y+49,w-16,h-56);
 // Subtle framed display panels and stylized film-reel motifs.
 for(const side of [-1,1]){
  const bx=cx+side*103;
  c.fillStyle="#132332";c.fillRect(bx-27,y+55,54,132);
  c.strokeStyle="#bd9a62";c.lineWidth=2;c.strokeRect(bx-27,y+55,54,132);
  c.fillStyle="#d7aa67";c.beginPath();c.arc(bx,y+105,17,0,Math.PI*2);c.fill();
  c.fillStyle="#192637";c.beginPath();c.arc(bx,y+105,5,0,Math.PI*2);c.fill();
  for(let j=0;j<5;j++){
   let a=j*Math.PI*2/5;
   c.fillStyle="#192637";c.beginPath();c.arc(bx+Math.cos(a)*10,y+105+Math.sin(a)*10,3.2,0,Math.PI*2);c.fill();
  }
  c.fillStyle="#a9bfc2";c.fillRect(bx-14,y+148,28,2);
 }
 // Twin doors stay closed until a nearby player approaches. Opening is visual only;
 // entering still requires a deliberate tap on the doorway.
 const dx=cx-68,dy=y+57,dw=136,dh=135,o=clamp(mediaDoorOpen,0,1);
 c.fillStyle="#090e19";c.fillRect(dx,dy,dw,dh);
 c.fillStyle="#9d8363";c.fillRect(dx-7,dy-7,dw+14,8);
 c.fillStyle="#d4b677";c.fillRect(dx-7,dy-7,5,dh+14);c.fillRect(dx+dw+2,dy-7,5,dh+14);
 c.fillStyle="#411e26";c.fillRect(dx+7,dy+8,dw-14,dh-14);
 c.fillStyle="#cc784a22";c.fillRect(dx+8,dy+8,dw-16,dh-16);
 for(const side of [-1,1]){
  const hingeX=cx+side*68;
  const freeX=cx+side*(2+o*40);
  const top=dy+4+(o*13),bottom=dy+dh-4+(o*11);
  const pane=c.createLinearGradient(hingeX,dy,freeX,dy);
  pane.addColorStop(0,"#466272");pane.addColorStop(1,"#1a2f43");
  c.beginPath();c.moveTo(hingeX,dy+2);c.lineTo(freeX,top);
  c.lineTo(freeX,bottom);c.lineTo(hingeX,dy+dh-2);c.closePath();
  c.fillStyle=pane;c.fill();c.strokeStyle="#b5c6c8";c.lineWidth=2.4;c.stroke();
  c.strokeStyle="#d4e6e47c";c.lineWidth=2;
  c.beginPath();c.moveTo(hingeX+side*-14,dy+15);c.lineTo(hingeX+side*-14,dy+dh-18);c.stroke();
  c.strokeStyle="#ffefcc";c.lineWidth=3;c.lineCap="round";
  c.beginPath();c.moveTo(freeX-side*12,dy+63);c.lineTo(freeX-side*12,dy+88);c.stroke();
 }
 c.fillStyle="#bd9e65";c.fillRect(dx-8,dy+dh-2,dw+16,5);
 c.restore();
}
function drawFoodNookStorefront(c,s){
 const {x,w}=s,cx=x+w/2,y=151,h=205;
 c.save();
 // Compact food-court outlet inspired by pretzel/cinnamon kiosks, not a full store.
 c.fillStyle="#f4ead8";c.beginPath();c.roundRect(x-8,y-10,w+16,h+13,8);c.fill();
 c.strokeStyle="#9f8f79";c.lineWidth=4;c.strokeRect(x-8,y-10,w+16,h+13);
 c.fillStyle="#cfded9";c.fillRect(x-3,y-7,w+6,14);
 c.fillStyle="#eff7f4";c.fillRect(x+9,y+8,w-18,28);
 c.fillStyle="#2f635f";c.fillRect(x+14,y+12,w-28,20);
 c.textAlign="center";
 c.shadowColor="#88e6dd";c.shadowBlur=11;c.fillStyle="#f6fffb";c.font="1000 22px system-ui,sans-serif";c.fillText("UNCLE AL'S",cx,y+29);c.shadowBlur=0;
 c.fillStyle="#6f4f3d";c.font="900 10px system-ui,sans-serif";c.fillText("PRETZELS · ROLLS · ICE CREAM",cx,y+47);
 // Soft striped canopy / kiosk header.
 const canopyY=y+56;
 for(let i=0;i<7;i++){
  c.fillStyle=i%2?"#72c7bf":"#f3faf8";
  c.beginPath();c.roundRect(x+20+i*36,canopyY,33,18,4);c.fill();
 }
 c.fillStyle="#5e7f80";c.fillRect(x+16,canopyY+16,w-32,6);
 // Warm service opening.
 const insetX=x+26,insetY=y+80,insetW=w-52,insetH=84;
 const warm=c.createLinearGradient(0,insetY,0,insetY+insetH);
 warm.addColorStop(0,"#f8f0d7");warm.addColorStop(1,"#ccac7c");
 c.fillStyle="#846952";c.fillRect(insetX-6,insetY-6,insetW+12,insetH+44);
 c.fillStyle=warm;c.fillRect(insetX,insetY,insetW,insetH);
 // Single smaller menu board on the right.
 const menuX=x+w-62, menuY=insetY+8, menuW=34, menuH=52;
 c.fillStyle="#304750";c.beginPath();c.roundRect(menuX,menuY,menuW,menuH,5);c.fill();
 c.strokeStyle="#b7d9d4";c.lineWidth=2;c.stroke();
 c.fillStyle="#f0fff8";c.font="900 8px system-ui,sans-serif";c.fillText("MENU",menuX+menuW/2,menuY+14);
 c.fillStyle="#baded7";
 for(let j=0;j<4;j++)c.fillRect(menuX+8,menuY+20+j*8,18,2.6);
 // Back shelf with ingredient containers.
 const shelfY=y+125;
 c.fillStyle="#735744";c.fillRect(cx-70,shelfY,140,5);
 const bins=[
  {x:cx-67,w:18,h:17,color:"#f2ead0",cap:"#6f5740"},
  {x:cx-46,w:18,h:18,color:"#ef9db3",cap:"#8a6a79"},
  {x:cx-25,w:18,h:16,color:"#8fd4c9",cap:"#5f7a76"},
  {x:cx-4,w:18,h:19,color:"#f0c569",cap:"#916e3b"},
  {x:cx+17,w:18,h:17,color:"#c9b5ff",cap:"#6a628b"}
 ];
 for(const bin of bins){
  c.fillStyle="#f5fbfb";c.beginPath();c.roundRect(bin.x,shelfY-bin.h,bin.w,bin.h,3);c.fill();
  c.fillStyle=bin.color;c.fillRect(bin.x+2,shelfY-bin.h+5,bin.w-4,bin.h-7);
  c.strokeStyle="#9db8b5";c.lineWidth=1.2;c.stroke();
  c.fillStyle=bin.cap;c.fillRect(bin.x+3,shelfY-bin.h-3,bin.w-6,3);
 }
 // Uncle Al's employee stands inside the kiosk behind the cashier's counter.
 const ex=UNCLE_ALS_EMPLOYEE.x+UNCLE_ALS_EMPLOYEE.w/2;
 const bob=Math.sin(performance.now()*0.0025)*.7;
 c.fillStyle="#416c70";c.beginPath();c.roundRect(ex-17,y+127+bob,34,47,10);c.fill();
 c.fillStyle="#eff7ef";c.beginPath();c.roundRect(ex-11,y+130+bob,22,39,4);c.fill(); // apron
 c.fillStyle="#54a69b";c.fillRect(ex-11,y+139+bob,22,4);
 c.strokeStyle="#34736c";c.lineWidth=3;c.beginPath();c.moveTo(ex-10,y+130+bob);c.lineTo(ex-5,y+146+bob);c.moveTo(ex+10,y+130+bob);c.lineTo(ex+5,y+146+bob);c.stroke();
 // Waving/register arm, mostly concealed behind the counter.
 c.strokeStyle="#c68d68";c.lineWidth=8;c.lineCap="round";
 c.beginPath();c.moveTo(ex+13,y+141+bob);c.lineTo(ex+24,y+156+bob);c.stroke();
 // Head and hair.
 c.fillStyle="#c9906e";c.beginPath();c.arc(ex,y+112+bob,15,0,Math.PI*2);c.fill();
 c.fillStyle="#372c2d";c.beginPath();c.arc(ex,y+108+bob,15,Math.PI*1.03,Math.PI*1.95);c.lineTo(ex+13,y+112+bob);c.lineTo(ex+8,y+103+bob);c.lineTo(ex-7,y+104+bob);c.closePath();c.fill();
 c.fillStyle="#302528";c.beginPath();c.arc(ex-5,y+114+bob,1.6,0,Math.PI*2);c.arc(ex+5,y+114+bob,1.6,0,Math.PI*2);c.fill();
 c.strokeStyle="#744837";c.lineWidth=1.7;c.beginPath();c.arc(ex,y+118+bob,4,.18,Math.PI-.18);c.stroke();
 // Small mint cap identifies a worker without any textual interaction hint.
 c.fillStyle="#63b4a9";c.beginPath();c.ellipse(ex,y+101+bob,15,5,0,0,Math.PI*2);c.fill();
 c.fillStyle="#416f71";c.fillRect(ex-13,y+99+bob,26,4);
 // Short speech bubble fades out after a nearby player's greeting.
 if(uncleGreeting&&performance.now()<uncleGreetingUntil){
  c.save();c.globalAlpha=Math.min(1,(uncleGreetingUntil-performance.now())/420);
  const bx=ex-102,by=y+74,bw=119,bh=26;
  c.fillStyle="#fffdf2";c.strokeStyle="#8dafa8";c.lineWidth=1.5;
  c.beginPath();c.roundRect(bx,by,bw,bh,9);c.fill();c.stroke();
  c.beginPath();c.moveTo(ex-2,by+bh);c.lineTo(ex+2,by+bh+8);c.lineTo(ex+10,by+bh);c.closePath();c.fill();c.stroke();
  c.fillStyle="#2f5354";c.font="900 9px system-ui,sans-serif";c.textAlign="center";
  c.fillText(uncleGreeting,bx+bw/2,by+17,bw-10);
  c.restore();
 }
 // Front counters and cases.
 const counterY=y+171;
 c.fillStyle="#d8c3a1";c.fillRect(x+24,counterY,w-48,18);
 c.fillStyle="#896851";c.fillRect(x+24,counterY+18,w-48,27);
 // One long connected display case that stops short of the register.
 const regX=x+w-92,regY=counterY-23;
 const gateX=x+w-45, gateW=22;
 const caseX=x+32, caseY=counterY-28, caseW=(regX-8)-caseX, caseH=28;
 c.fillStyle="#c8e3df";c.fillRect(caseX,caseY,caseW,caseH);
 c.strokeStyle="#86aba4";c.lineWidth=2;c.strokeRect(caseX,caseY,caseW,caseH);
 c.fillStyle="#e9f8f6";c.fillRect(caseX+2,caseY+2,caseW-4,4);
 // Register moved closer to the display case.
 c.fillStyle="#48535d";c.fillRect(regX,regY,28,16);
 c.fillStyle="#2e3740";c.fillRect(regX+4,regY-8,17,8);
 c.fillStyle="#bce7e0";c.fillRect(regX+7,regY-6,11,4);
 c.fillStyle="#616a74";c.fillRect(regX+20,regY+3,5,13);
 c.fillStyle="#e7d9be";c.fillRect(regX+4,regY+16,21,3);
 // Tip jar placed on top of the right edge of the display case.
 const jarW=14, jarH=14;
 const jarX=caseX+caseW-jarW-4, jarY=caseY-jarH;
 c.fillStyle="#dff7f5";c.beginPath();c.roundRect(jarX,jarY,jarW,jarH,4);c.fill();
 c.strokeStyle="#7fa9a4";c.lineWidth=1.4;c.stroke();
 c.fillStyle="#8b6a46";c.fillRect(jarX+3,jarY-2,8,2);
 c.fillStyle="#51736e";c.font="700 5px system-ui,sans-serif";c.fillText("TIPS",jarX+jarW/2,jarY+9);
 // Worker entry flap / swing-up counter gate on the far right.
 c.fillStyle="#7f5f47";c.fillRect(gateX,counterY,gateW,17);
 c.fillStyle="#654a38";c.fillRect(gateX,counterY+17,gateW,28);
 c.strokeStyle="#d1b58c";c.lineWidth=1.5;c.strokeRect(gateX,counterY,gateW,45);
 c.fillStyle="#8f7158";c.save();
 c.translate(gateX+gateW/2,counterY-5);c.rotate(-0.7);
 c.fillRect(-gateW/2,-5,gateW,8);
 c.fillStyle="#ceb48b";c.fillRect(-gateW/2,-5,gateW,2);
 c.restore();
 c.strokeStyle="#67503c";c.lineWidth=1.4;c.beginPath();c.moveTo(gateX+3,counterY-2);c.lineTo(gateX+7,counterY-14);c.moveTo(gateX+gateW-3,counterY-2);c.lineTo(gateX+gateW-7,counterY-14);c.stroke();
 // Soft food-court floor shadow / welcoming feel.
 c.fillStyle="#00000018";c.beginPath();c.ellipse(cx,y+h-3,118,14,0,0,Math.PI*2);c.fill();
 // Two stylized front columns / side trim to make it feel like a built-in nook.
 for(const sx of [x+8,x+w-18]){c.fillStyle="#e5ded1";c.fillRect(sx,y+58,10,133);c.fillStyle="#a8bab6";c.fillRect(sx,y+58,10,5)}
 c.restore();
}
// The Artifact is ONE double-width storefront across the original spaces 03 and 04.
function drawArtifactStorefront(c,s){
 const {x,w}=s,cx=s.x+w/2,y=146,h=213,opening=clamp(artifactDoorOpen,0,1);
 c.save();
 c.fillStyle="#0c111e";c.beginPath();c.roundRect(x-9,y-12,w+18,h+17,7);c.fill();
 c.strokeStyle="#7e749d";c.lineWidth=5;c.strokeRect(x-9,y-12,w+18,h+17);
 const header=c.createLinearGradient(x,y,x+w,y);
 header.addColorStop(0,"#17142c");header.addColorStop(.5,"#382d59");header.addColorStop(1,"#111d35");
 c.fillStyle=header;c.fillRect(x,y,w,73);
 c.fillStyle="#ddaefd";c.textAlign="center";c.font="1000 35px system-ui,sans-serif";
 c.shadowColor="#a978ff";c.shadowBlur=17;c.fillText("THE ARTIFACT",cx,y+35);c.shadowBlur=0;
 c.fillStyle="#9ce7de";c.font="800 12px system-ui,sans-serif";
 c.fillText("ARCADE AND LOUNGE",cx,y+56);
 c.fillStyle="#8562ae";c.fillRect(x+15,y+66,w-30,3);
 const glassY=y+78,glassH=123;
 for(const [wx,ww,index] of [[x+12,225,0],[x+w-237,225,1]]){
  const back=c.createLinearGradient(wx,glassY,wx,glassY+glassH);
  back.addColorStop(0,"#293958");back.addColorStop(1,"#141d35");
  c.fillStyle=back;c.fillRect(wx,glassY,ww,glassH);
  // Silhouettes are BEHIND the translucent frosted glazing.
  for(let i=0;i<3;i++){
   const sx=wx+24+i*67+(index?7:0),sy=glassY+25+(i%2)*7;
   c.fillStyle="#090e1bdb";c.beginPath();c.roundRect(sx,sy,44,94-(i%2)*8,4);c.fill();
   c.fillStyle=["#b279fe","#6adccf","#f0a768"][i];
   c.shadowColor=c.fillStyle;c.shadowBlur=11;
   c.fillRect(sx+7,sy+10,30,26);c.shadowBlur=0;
   c.fillStyle="#06111ecc";c.fillRect(sx+10,sy+14,24,18);
   c.fillStyle="#bdc3d6";c.fillRect(sx+17,sy+48,12,3);
  }
  const mist=c.createLinearGradient(wx,glassY,wx+ww,glassY+glassH);
  mist.addColorStop(0,"#c3e3f0a0");mist.addColorStop(.45,"#a2bed3a9");mist.addColorStop(1,"#7999b4b2");
  c.fillStyle=mist;c.fillRect(wx,glassY,ww,glassH);
  c.fillStyle="#e8fbff29";c.beginPath();c.moveTo(wx+20,glassY+4);
  c.lineTo(wx+66,glassY+4);c.lineTo(wx+125,glassY+glassH-4);
  c.lineTo(wx+96,glassY+glassH-4);c.closePath();c.fill();
  c.strokeStyle="#a8d0d9";c.lineWidth=3;c.strokeRect(wx,glassY,ww,glassH);
  c.fillStyle="#d8f3fc66";c.fillRect(wx+ww/2-2,glassY,4,glassH);
 }
 // Sliding pocket doors in the center; panels translate left/right, never swing.
 const door=ARTIFACT_STORE,dx=door.doorX,dy=door.doorY,dw=door.doorW,dh=door.doorH;
 c.fillStyle="#0b0d20";c.fillRect(dx-8,dy-5,dw+16,dh+12);
 const entry=c.createLinearGradient(0,dy,0,dy+dh);
 entry.addColorStop(0,"#352348");entry.addColorStop(.62,"#161f35");entry.addColorStop(1,"#495069");
 c.fillStyle=entry;c.fillRect(dx+2,dy+3,dw-4,dh-5);
 // Visible neon floor and machines beyond the opening when doors part.
 c.fillStyle=`rgba(117,232,216,${.14+.36*opening})`;c.fillRect(dx+27,dy+29,dw-54,4);
 for(const [mx,colour] of [[dx+24,"#dc80f4"],[dx+dw-46,"#64e8c5"]]){
  c.fillStyle="#0b0f23";c.fillRect(mx,dy+58,24,75);
  c.fillStyle=colour;c.globalAlpha=.3+.65*opening;c.fillRect(mx+4,dy+65,16,21);c.globalAlpha=1;
 }
 const leafW=dw/2-4,slide=opening*(leafW-3);
 for(const side of [-1,1]){
  const base=side===-1?dx+4:dx+dw/2;
  const px=base+side*slide;
  c.fillStyle="#91b0c5";c.fillRect(px,dy+6,leafW,dh-12);
  const pane=c.createLinearGradient(px,dy,px+leafW,dy+dh);
  pane.addColorStop(0,"#334769");pane.addColorStop(1,"#1b304a");
  c.fillStyle=pane;c.fillRect(px+4,dy+11,leafW-8,dh-20);
  c.fillStyle="#ecfaff22";c.fillRect(px+8,dy+14,8,dh-26);
  c.strokeStyle="#c2d4e3";c.lineWidth=2;c.strokeRect(px+4,dy+11,leafW-8,dh-20);
  const handleX=side===-1?px+leafW-12:px+9;
  c.fillStyle="#f1e2c5";c.fillRect(handleX,dy+70,3,23);
 }
 // The opening stays visibly unobstructed as the leaves slide into the pockets.
 c.strokeStyle="#afbad4";c.lineWidth=6;c.strokeRect(dx,dy,dw,dh);
 c.strokeStyle="#ab92cd";c.lineWidth=3;c.beginPath();c.moveTo(dx-6,dy+dh);c.lineTo(dx+dw+6,dy+dh);c.stroke();
 c.fillStyle="#86d4c0";c.fillRect(dx-4,dy-7,dw+8,3);
 c.restore();
}
function drawMallStore(c,s){
 if(s.id==="artifact"){drawArtifactStorefront(c,s);return;}
 if(MEDIA_MASTER_ENABLED&&s.id==="media"){drawMediaMasterStorefront(c,s);return}
 if(s.id==="looks"){drawLooksMaxStorefront(c,s);return}
 if(s.id==="food"){drawFoodNookStorefront(c,s);return}
 const x=s.x,w=s.w,y=151,h=205;
 const cx=x+w/2;
 c.save();
 c.fillStyle="#13232e";c.fillRect(x-7,y-13,w+14,h+16);
 c.strokeStyle="#8faab0";c.lineWidth=5;c.strokeRect(x-7,y-13,w+14,h+16);
 c.fillStyle="#1a303d";c.fillRect(x,y-3,w,43);
 c.fillStyle=s.accent;c.fillRect(x+15,y+36,w-30,3);
 c.fillStyle="#eaf4f2";c.textAlign="center";c.font="900 17px system-ui,sans-serif";
 c.fillText(s.name,cx,y+26);
 const glass=c.createLinearGradient(x,y+43,x,y+h);
 glass.addColorStop(0,"#628896");glass.addColorStop(.4,"#2e5669");glass.addColorStop(1,"#142b3b");
 c.fillStyle=glass;c.fillRect(x+6,y+45,w-12,h-51);
 c.fillStyle="#ccf6fb21";
 c.beginPath();c.moveTo(x+22,y+46);c.lineTo(x+58,y+46);c.lineTo(x+120,y+h-12);c.lineTo(x+92,y+h-12);c.fill();
 c.fillStyle="#91c4ca20";c.fillRect(x+w-86,y+45,15,h-58);
 c.strokeStyle="#b5c7c6";c.lineWidth=2;c.strokeRect(x+6,y+45,w-12,h-51);
 // Stylized placeholder entry centered within every storefront.
 const portalW=134,portalH=118,portalX=Math.round(cx-portalW/2),portalY=y+78;
 const framePad=14;
 c.fillStyle="#172936e8";c.beginPath();c.roundRect(portalX-framePad,portalY-18,portalW+framePad*2,portalH+28,12);c.fill();
 c.strokeStyle="#9eb4ba";c.lineWidth=3;c.stroke();
 c.fillStyle="#324754";c.fillRect(portalX-framePad+5,portalY-13,portalW+framePad*2-10,12);
 c.fillStyle=s.accent;c.fillRect(portalX-framePad+10,portalY-7,portalW+framePad*2-20,3);
 // Side-lite windows to give each placeholder unit a mall-entry feel.
 for(const sx of [portalX-26, portalX+portalW+8]){
  const sideGlass=c.createLinearGradient(sx,portalY-2,sx,portalY+portalH+8);
  sideGlass.addColorStop(0,"#4f7f90");sideGlass.addColorStop(.55,"#24455b");sideGlass.addColorStop(1,"#122b3d");
  c.fillStyle=sideGlass;c.fillRect(sx,portalY,18,portalH+2);
  c.fillStyle="#d0fbff18";c.fillRect(sx+3,portalY+6,4,portalH-10);
  c.strokeStyle="#8ea8ae";c.lineWidth=2;c.strokeRect(sx,portalY,18,portalH+2);
 }
 // Double-door frame and evenly spaced leaves.
 const doorFrameX=portalX,doorFrameY=portalY+10,doorFrameW=portalW,doorFrameH=portalH-6;
 c.fillStyle="#10212ddd";c.fillRect(doorFrameX,doorFrameY,doorFrameW,doorFrameH);
 c.strokeStyle="#aebfc3";c.lineWidth=3;c.strokeRect(doorFrameX,doorFrameY,doorFrameW,doorFrameH);
 c.fillStyle="#516b73";c.fillRect(doorFrameX+5,doorFrameY+4,doorFrameW-10,8);
 c.fillStyle="#c9d4d1";c.fillRect(doorFrameX+4,doorFrameY+doorFrameH-4,doorFrameW-8,4);
 const gap=10,innerPad=8;
 const leafH=doorFrameH-14;
 const leafY=doorFrameY+8;
 const availableW=doorFrameW-innerPad*2-gap;
 const leafW=Math.floor(availableW/2);
 const leftDoorX=Math.round(cx-gap/2-leafW);
 const rightDoorX=Math.round(cx+gap/2);
 for(const leafX of [leftDoorX,rightDoorX]){
  const doorGlass=c.createLinearGradient(leafX,leafY,leafX,leafY+leafH);
  doorGlass.addColorStop(0,"#5f8896");doorGlass.addColorStop(.4,"#2d5569");doorGlass.addColorStop(1,"#132c3e");
  c.fillStyle=doorGlass;c.fillRect(leafX,leafY,leafW,leafH);
  c.fillStyle="#dcfbff1c";c.fillRect(leafX+5,leafY+7,6,leafH-14);
  c.strokeStyle="#d8e7e5";c.lineWidth=2;c.strokeRect(leafX,leafY,leafW,leafH);
 }
 // Center seam and mirrored handles.
 c.fillStyle="#9eb4ba";c.fillRect(Math.round(cx-gap/2),leafY,1,leafH);
 c.fillRect(Math.round(cx+gap/2)-1,leafY,1,leafH);
 c.strokeStyle="#e7ecdf";c.lineWidth=3.2;c.lineCap="round";
 c.beginPath();
 c.moveTo(leftDoorX+leafW-12,leafY+leafH/2-13);c.lineTo(leftDoorX+leafW-12,leafY+leafH/2+13);
 c.moveTo(rightDoorX+12,leafY+leafH/2-13);c.lineTo(rightDoorX+12,leafY+leafH/2+13);
 c.stroke();
 // Placeholder leasing sign sits above the entry, not replacing the doors.
 c.fillStyle="#0d2230e6";c.beginPath();c.roundRect(cx-58,y+87,116,34,8);c.fill();
 c.strokeStyle=s.accent;c.lineWidth=2;c.strokeRect(cx-55,y+90,110,28);
 c.fillStyle="#ecf6f3";c.font="1000 14px system-ui,sans-serif";
 c.fillText("COMING SOON",cx,y+110);
 c.fillStyle="#c2cdca";c.fillRect(x-9,y+h,w+18,7);
 c.restore();
}

// Community board raster cache: redraw only when a stroke changes, not every frame.
const boardCache=document.createElement("canvas");boardCache.width=320;boardCache.height=200;
const boardCacheCtx=boardCache.getContext("2d");
let communityOpen=false,communityColor=0,communityPen=2,communityPointer=null,communityLastEmit=0;
let communityBoard={strokes:[],revision:0};
const communityCanvas=()=>$("communityDrawCanvas");
function boardSegment(c,segment){
 if(!Array.isArray(segment)||segment.length!==6)return;
 const [ax,ay,bx,by,color,size]=segment;
 c.strokeStyle=BOARD_COLORS[color]||BOARD_COLORS[0];
 c.lineWidth=({1:2.5,2:5.0,3:9.0})[size]||5;
 c.lineCap="round";c.lineJoin="round";
 c.beginPath();c.moveTo(ax*.32,ay*.2);c.lineTo(bx*.32,by*.2);c.stroke();
}
function repaintCommunityBoard(){
 boardCacheCtx.fillStyle="#ffffff";boardCacheCtx.fillRect(0,0,320,200);
 for(const stroke of communityBoard.strokes||[])boardSegment(boardCacheCtx,stroke);
 if(communityOpen)paintCommunityEditor();
}
function paintCommunityEditor(){
 const cv=communityCanvas();if(!cv)return;
 const c=cv.getContext("2d");c.clearRect(0,0,320,200);c.drawImage(boardCache,0,0);
}
function acceptBoardSnapshot(value){
 const safe=value&&Array.isArray(value.strokes)?value:{strokes:[],revision:0};
 communityBoard={strokes:safe.strokes.slice(-BOARD_LIMIT),revision:Number(safe.revision)||0};
 repaintCommunityBoard();
}
function appendBoardStroke(seg){
 communityBoard.strokes.push(seg);
 if(communityBoard.strokes.length>BOARD_LIMIT){communityBoard.strokes.splice(0,communityBoard.strokes.length-BOARD_LIMIT);repaintCommunityBoard();}
 else {boardSegment(boardCacheCtx,seg);if(communityOpen)paintCommunityEditor();}
}
function boardNearPlayer(p){
 if(!p||p.scene!=="mall"||!isMallAtrium())return false;
 const px=clamp(p.x,COMMUNITY_BOARD.x,COMMUNITY_BOARD.x+COMMUNITY_BOARD.w);
 const py=clamp(p.y,COMMUNITY_BOARD.y,COMMUNITY_BOARD.y+COMMUNITY_BOARD.h);
 return Math.hypot(p.x-px,p.y-py)<=126;
}
// Inventory is an empty, network-backed collection until items are introduced.
function inventoryIds(player=me()){
 return Array.isArray(player?.inventory)?[PERMANENT_PHONE_ID,...new Set(player.inventory.filter(id=>typeof id==="string"&&id!==PERMANENT_PHONE_ID))].slice(0,80):[];
}
function inventoryInfo(id){
 return INVENTORY_CATALOG[id]||{
  name:id.replace(/[-_]/g," ").replace(/\b\w/g,s=>s.toUpperCase()),
  description:"A collectible item. More details will be available when this item is introduced.",
  icon:"◇",category:"Item"
 };
}
function renderInventory(){
 const own=me(),ids=inventoryIds(own),equipped=own?.equippedItem||null;
 $("inventoryItemCount").textContent=ids.length+" "+(ids.length===1?"item":"items");
 $("inventoryEquippedName").textContent=equipped?inventoryInfo(equipped).name:"Nothing equipped";
 $("inventoryEmpty").classList.toggle("hidden",ids.length>0);
 const grid=$("inventoryGrid");grid.replaceChildren();
 if(!ids.includes(inventorySelected))inventorySelected=null;
 for(const id of ids){
  const def=inventoryInfo(id),tile=document.createElement("button");
  tile.type="button";tile.className="inventoryTile"+(id===inventorySelected?" selected":"");
  tile.setAttribute("aria-pressed",id===inventorySelected?"true":"false");
  const icon=document.createElement("span");icon.className="inventoryGlyph";icon.textContent=def.icon||"◇";
  const name=document.createElement("span");name.textContent=def.name;
  tile.append(icon,name);
  if(equipped===id){const chip=document.createElement("span");chip.className="inventoryEquipped";chip.textContent="✓";tile.append(chip)}
  tile.addEventListener("click",()=>{inventorySelected=id;renderInventory()});
  grid.append(tile);
 }
 const details=$("inventoryDetails");details.classList.toggle("hidden",!inventorySelected);
 if(inventorySelected){
  const item=inventoryInfo(inventorySelected),isEquipped=equipped===inventorySelected;
  $("inventoryItemType").textContent=(item.category||"Item").toUpperCase();
  $("inventoryItemName").textContent=item.name;
  $("inventoryItemDescription").textContent=item.description||"No description yet.";
  $("inventoryEquipBtn").textContent=isEquipped?"Unequip":"Equip";
  $("inventoryEquipBtn").disabled=!joined;
  $("inventoryTrashBtn").disabled=!joined||item.permanent===true;
  $("inventoryTrashBtn").title=item.permanent?"This item cannot be discarded.":"Discard this item";
  $("inventoryItemPermanent").classList.toggle("hidden",!item.permanent);
  $("inventoryPhoneHint").classList.toggle("hidden",inventorySelected!==PERMANENT_PHONE_ID);
 }
}
function openInventory(){
 if(!joined||!me())return;
 // Prevent overlapping dialogs with the inventory on mobile.
 if(uncleMenuOpen)closeUncleMenu();
 if(communityOpen)closeCommunityBoard();
 if(fridgeOpen)closeFridge();
 if(activityOpen)closeActivity();
 if(wardrobeOpen)closeWardrobe();
 inventoryOpen=true;inventorySelected=null;
 $("inventoryNotice").textContent="";
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 $("inventoryModal").classList.remove("hidden");renderInventory();
}
function closeInventory(){
 closeDiscardConfirmation();closePhone();
 inventoryOpen=false;inventorySelected=null;
 $("inventoryModal").classList.add("hidden");
}
$("inventoryBtn").addEventListener("click",()=>inventoryOpen?closeInventory():openInventory());
$("closeInventoryBtn").addEventListener("click",closeInventory);
$("inventoryModal").addEventListener("pointerdown",e=>{
 if(e.target===$("inventoryModal"))closeInventory();
});
$("inventoryEquipBtn").addEventListener("click",()=>{
 const p=me(),id=inventorySelected;
 if(!p||!id||!inventoryIds(p).includes(id))return;
 const unequip=p.equippedItem===id;
 broadcast("inventory-action",{action:unequip?"unequip":"equip",itemId:id});
 // Wait for authoritative equip state from the Durable Object.
});

// Discarding is always confirmed. The server performs the actual removal.
function closeDiscardConfirmation(){
 discardPending=null;
 $("inventoryDiscardModal").classList.add("hidden");
}
$("inventoryTrashBtn").addEventListener("click",()=>{
 const id=inventorySelected;
 if(!joined||!id||!inventoryIds().includes(id)||inventoryInfo(id).permanent)return;
 discardPending=id;
 $("inventoryDiscardName").textContent=inventoryInfo(id).name;
 $("inventoryDiscardModal").classList.remove("hidden");
});
$("inventoryDiscardNo").addEventListener("click",closeDiscardConfirmation);
$("inventoryDiscardYes").addEventListener("click",()=>{
 const id=discardPending;
 closeDiscardConfirmation();
 if(!id||id===PERMANENT_PHONE_ID||!inventoryIds().includes(id))return;
 $("inventoryNotice").textContent="Discarding "+inventoryInfo(id).name+"…";
 if(!broadcast("inventory-action",{action:"remove",itemId:id}))
  $("inventoryNotice").textContent="Not connected. Try again.";
});
$("inventoryDiscardModal").addEventListener("pointerdown",e=>{
 if(e.target===$("inventoryDiscardModal"))closeDiscardConfirmation();
});

// Phone controls, inbox, appearance, and mini-game. All changes to equipment
// and private-message delivery are authoritative on the room Durable Object.
const PHONE_APPS={notes:{name:"Notes"},flappy:{name:"Flappy"},dice:{name:"Dice"},clock:{name:"Clock"},messages:{name:"Messages"},settings:{name:"Settings"}};
const PHONE_DEFAULT_COLORS={frame:"#283d55",background:"#172d49"};
const PHONE_FRAME_PALETTE=["#283d55","#e48a9d","#4a987c","#c08ac9","#e4b665"];
const PHONE_BG_PALETTE=["#172d49","#233d38","#442c55","#4b3044","#514022"];
let phoneColors={...PHONE_DEFAULT_COLORS};
function phoneNotesKey(){return "socialhub-note-v1:"+encodeURIComponent(currentName||"Player")}
function phoneNotesRead(){try{return localStorage.getItem(phoneNotesKey())||""}catch{return ""}}
function phoneNotesSave(value){try{localStorage.setItem(phoneNotesKey(),value.slice(0,2000))}catch{}}
function phoneColorsKey(){return "socialhub-phone-colors-v1:"+encodeURIComponent(currentName||"Player")}
function isPhoneHex(value){return typeof value==="string"&&/^#[0-9a-fA-F]{6}$/.test(value)}
function restorePhoneColors(){
 try{const data=JSON.parse(localStorage.getItem(phoneColorsKey())||"{}");
  phoneColors={frame:isPhoneHex(data.frame)?data.frame:PHONE_DEFAULT_COLORS.frame,
   background:isPhoneHex(data.background)?data.background:PHONE_DEFAULT_COLORS.background};
 }catch{phoneColors={...PHONE_DEFAULT_COLORS}}
 applyPhoneColors();
}
function applyPhoneColors(){
 $("phoneModal").style.setProperty("--phone-shell-color",phoneColors.frame);
 $("phoneModal").style.setProperty("--phone-screen-color",phoneColors.background);
 $("phoneFrameColor").value=phoneColors.frame;
 $("phoneBgColor").value=phoneColors.background;
 for(const [field,palette,host] of [["frame",PHONE_FRAME_PALETTE,"phoneFrameSwatches"],["background",PHONE_BG_PALETTE,"phoneBgSwatches"]]){
  const wrap=$(host);wrap.replaceChildren();
  for(const color of palette){const btn=document.createElement("button");btn.type="button";
   btn.className="phoneSwatch"+(phoneColors[field].toLowerCase()===color?" active":"");
   btn.style.background=color;btn.setAttribute("aria-label","Set "+field+" color to "+color);
   btn.addEventListener("click",()=>setPhoneColor(field,color));wrap.append(btn);
  }
 }
}
function setPhoneColor(field,value){
 if(!isPhoneHex(value)||!(field in PHONE_DEFAULT_COLORS))return;
 phoneColors[field]=value;
 try{localStorage.setItem(phoneColorsKey(),JSON.stringify(phoneColors))}catch{}
 applyPhoneColors();
}
function unreadPhoneCount(){let n=0;for(const v of phoneUnread.values())n+=v;return n}
function updatePhoneHud(){
 const equipped=!!joined&&me()?.equippedItem===PERMANENT_PHONE_ID;
 $("phoneHudBtn").classList.toggle("hidden",!equipped);
 const unread=unreadPhoneCount();
 for(const [id,visible] of [["phoneUnreadBadge",equipped],["inventoryUnreadBadge",!equipped],["phoneMessagesBadge",true]]){
  const badge=$(id);badge.textContent=String(Math.min(unread,99))+(unread>99?"+":"");
  badge.classList.toggle("hidden",!unread||!visible);
 }
}
function openPhone(){
 if(!joined||me()?.equippedItem!==PERMANENT_PHONE_ID)return;
 // Keep phone and inventory as independent full-screen modals on narrow phones.
 if(inventoryOpen)closeInventory();
 closeDiscardConfirmation();
 phoneOpen=true;phoneApp=null;phoneThreadId=null;
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 $("phoneModal").classList.remove("hidden");
 restorePhoneColors();showPhoneHome();
}
function closePhone(){
 stopPhoneFlappy();phoneOpen=false;phoneApp=null;phoneThreadId=null;
 $("phoneModal").classList.add("hidden");
}
function showPhoneHome(){
 stopPhoneFlappy();phoneApp=null;phoneThreadId=null;
 $("phoneAppTitle").textContent="Apps";
 $("phoneBackBtn").classList.add("hidden");
 $("phoneHome").classList.remove("hidden");
 $("phoneAppView").classList.add("hidden");
 updatePhoneHud();
}
function renderPhoneClock(){
 const n=new Date();
 $("phoneClockTime").textContent=n.toLocaleTimeString([], {hour:"numeric",minute:"2-digit",second:"2-digit"});
 $("phoneClockDate").textContent=n.toLocaleDateString([], {weekday:"long",month:"long",day:"numeric",year:"numeric"});
}
function openPhoneApp(name){
 if(!PHONE_APPS[name]||!phoneOpen)return;
 stopPhoneFlappy();phoneApp=name;
 $("phoneAppTitle").textContent=PHONE_APPS[name].name;
 $("phoneBackBtn").classList.remove("hidden");
 $("phoneHome").classList.add("hidden");
 const view=$("phoneAppView");view.classList.remove("hidden");
 for(const part of view.querySelectorAll("[data-phone-panel]"))
  part.classList.toggle("hidden",part.dataset.phonePanel!==name);
 if(name==="notes")$("phoneNotes").value=phoneNotesRead();
 if(name==="clock")renderPhoneClock();
 if(name==="dice")$("phoneDiceResult").textContent="Tap Roll to begin";
 if(name==="messages"){phoneThreadId=null;renderPhoneMessages();}
 if(name==="settings")applyPhoneColors();
 if(name==="flappy")resetPhoneFlappy();
}
$("phoneHudBtn").addEventListener("click",()=>phoneOpen?closePhone():openPhone());
$("closePhoneBtn").addEventListener("click",closePhone);
$("phoneBackBtn").addEventListener("click",showPhoneHome);
$("phoneModal").addEventListener("pointerdown",e=>{if(e.target===$("phoneModal"))closePhone()});
for(const btn of document.querySelectorAll("[data-phone-app]"))
 btn.addEventListener("click",()=>openPhoneApp(btn.dataset.phoneApp));
$("phoneNotes").addEventListener("input",e=>{
 phoneNotesSave(e.target.value);$("phoneNotesSaved").textContent="Saved on this device";
});
$("phoneDiceRoll").addEventListener("click",()=>{
 $("phoneDiceResult").textContent=String(1+Math.floor(Math.random()*6));
});
$("phoneClockRefresh").addEventListener("click",renderPhoneClock);
$("phoneFrameColor").addEventListener("input",e=>setPhoneColor("frame",e.target.value));
$("phoneBgColor").addEventListener("input",e=>setPhoneColor("background",e.target.value));
$("phoneColorsReset").addEventListener("click",()=>{
 phoneColors={...PHONE_DEFAULT_COLORS};
 try{localStorage.setItem(phoneColorsKey(),JSON.stringify(phoneColors))}catch{}
 applyPhoneColors();
});

// Private messages are point-to-point via the DO: they never enter the shared
// room chat or room snapshot. Only this tab's recent conversation is retained.
function ensurePhoneRoom(){
 const key=roomCode||"";
 if(phoneRoomKey===key)return;
 phoneRoomKey=key;phoneMessages.clear();phoneUnread.clear();phoneThreadId=null;updatePhoneHud();
}
function getPhoneThread(peerId){
 if(!phoneMessages.has(peerId))phoneMessages.set(peerId,[]);
 return phoneMessages.get(peerId);
}
function receivePrivateMessage(message){
 if(!message||typeof message.text!=="string"||!joined)return;
 if(message.fromId!==clientId&&message.toId!==clientId)return;
 ensurePhoneRoom();
 const peerId=message.fromId===clientId?message.toId:message.fromId;
 if(typeof peerId!=="string")return;
 const thread=getPhoneThread(peerId);
 if(thread.some(m=>m.id===message.id))return;
 thread.push({id:message.id,fromId:message.fromId,toId:message.toId,text:message.text.slice(0,320),at:Number(message.at)||Date.now(),peerName:message.fromId===clientId?message.toName:message.fromName});
 if(thread.length>70)thread.splice(0,thread.length-70);
 if(message.fromId!==clientId&&(!phoneOpen||phoneApp!=="messages"||phoneThreadId!==peerId))
  phoneUnread.set(peerId,Math.min(99,(phoneUnread.get(peerId)||0)+1));
 updatePhoneHud();
 if(phoneOpen&&phoneApp==="messages")renderPhoneMessages();
}
function displayPeerName(peerId){
 const p=state?.players?.find(p=>p.id===peerId);
 if(p)return p.name;
 const t=phoneMessages.get(peerId)||[];
 return t.length?t[t.length-1].peerName||"Player":"Player";
}
function renderPhoneMessages(){
 if(!phoneOpen||phoneApp!=="messages")return;
 ensurePhoneRoom();
 const isThread=!!phoneThreadId;
 $("phoneMessagesInbox").classList.toggle("hidden",isThread);
 $("phoneMessagesThread").classList.toggle("hidden",!isThread);
 if(isThread){
  $("phoneThreadName").textContent=displayPeerName(phoneThreadId);
  const log=$("phoneChatLog");log.replaceChildren();
  const messages=getPhoneThread(phoneThreadId);
  if(!messages.length){const empty=document.createElement("div");empty.className="phoneEmptyNotice";empty.textContent="Say hello! Private messages appear here.";log.append(empty)}
  for(const msg of messages){
   const bubble=document.createElement("div");bubble.className="phoneBubble"+(msg.fromId===clientId?" mine":"");bubble.textContent=msg.text;
   const stamp=document.createElement("small");stamp.textContent=new Date(msg.at).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"});bubble.append(stamp);log.append(bubble);
  }
  log.scrollTop=log.scrollHeight;
 }else{
  const host=$("phoneMessagesPeople");host.replaceChildren();
  const online=(state?.players||[]).filter(p=>p.id!==clientId&&!p.disconnectedAt);
  const people=new Set([...online.map(p=>p.id),...phoneMessages.keys()]);
  if(!people.size){const empty=document.createElement("div");empty.className="phoneEmptyNotice";empty.textContent="No other players here yet. When someone joins, you can message them here.";host.append(empty)}
  for(const id of people){
   const p=(state?.players||[]).find(p=>p.id===id),available=online.some(o=>o.id===id);
   const btn=document.createElement("button");btn.type="button";btn.className="phoneMessagePerson";
   const title=document.createElement("span");const strong=document.createElement("strong");strong.textContent=displayPeerName(id);
   const meta=document.createElement("small");meta.textContent=available?"Online · tap to message":"Offline · conversation history";title.append(strong,meta);btn.append(title);
   if(phoneUnread.get(id)){const chip=document.createElement("span");chip.className="phonePersonUnread";chip.textContent=String(phoneUnread.get(id));btn.append(chip)}
   btn.addEventListener("click",()=>openPhoneThread(id));host.append(btn);
  }
 }
 updatePhoneHud();
}
function openPhoneThread(id){
 phoneThreadId=id;phoneUnread.delete(id);$("phoneMessageStatus").textContent="";
 renderPhoneMessages();
}
$("phoneMessagesRefresh").addEventListener("click",renderPhoneMessages);
$("phoneThreadBack").addEventListener("click",()=>{phoneThreadId=null;$("phoneMessageStatus").textContent="";renderPhoneMessages()});
$("phoneChatForm").addEventListener("submit",e=>{
 e.preventDefault();const recipient=phoneThreadId;
 const text=$("phoneChatInput").value.trim().slice(0,320);
 if(!recipient||!text)return;
 if(!broadcast("private-message",{toId:recipient,text})){
  $("phoneMessageStatus").textContent="Not connected. Try again.";return;
 }
 $("phoneChatInput").value="";
 $("phoneMessageStatus").textContent="";
 // Wait for the server's authoritative private-message echo.
});

// Lightweight arcade mini-game: fixed logical pixels, requestAnimationFrame
// only while the Flappy app is visible, including on iPhone touch screens.
const flappyCanvas=$("phoneFlappyCanvas"),flappyCtx=flappyCanvas.getContext("2d");
const flappy={phase:"ready",y:152,velocity:0,pipes:[],score:0,best:0,frame:0,last:0,raf:0};
function flappyBestKey(){return "socialhub-flappy-best-v1:"+encodeURIComponent(currentName||"Player")}
function stopPhoneFlappy(){if(flappy.raf)cancelAnimationFrame(flappy.raf);flappy.raf=0;flappy.last=0}
function resetPhoneFlappy(){
 stopPhoneFlappy();Object.assign(flappy,{phase:"ready",y:152,velocity:0,pipes:[],score:0,frame:0,last:0});
 try{flappy.best=Math.max(0,Number(localStorage.getItem(flappyBestKey()))||0)}catch{flappy.best=0}
 drawPhoneFlappy();updateFlappyCopy();
}
function updateFlappyCopy(){
 $("phoneFlappyScore").textContent="Score "+flappy.score+" · Best "+flappy.best;
 $("phoneFlappyHint").textContent=flappy.phase==="over"?"Game over! Tap to try again.":flappy.phase==="ready"?"Tap the game or Flap to start.":"Tap to flap between the pipes!";
 $("phoneFlappyBtn").textContent=flappy.phase==="over"?"Play again":"Flap";
}
function phoneFlap(){
 if(!phoneOpen||phoneApp!=="flappy")return;
 if(flappy.phase==="over")resetPhoneFlappy();
 if(flappy.phase==="ready"){
  flappy.phase="playing";flappy.last=0;flappy.raf=requestAnimationFrame(stepPhoneFlappy);
 }
 flappy.velocity=-4.7;updateFlappyCopy();
}
function flappyEnd(){
 flappy.phase="over";stopPhoneFlappy();
 if(flappy.score>flappy.best){flappy.best=flappy.score;try{localStorage.setItem(flappyBestKey(),String(flappy.best))}catch{}}
 updateFlappyCopy();drawPhoneFlappy();
}
function stepPhoneFlappy(t){
 if(!phoneOpen||phoneApp!=="flappy"||flappy.phase!=="playing"){stopPhoneFlappy();return}
 const dt=Math.min(2,flappy.last?Math.max(.25,(t-flappy.last)/16.67):1);flappy.last=t;
 flappy.frame+=dt;flappy.velocity+=.255*dt;flappy.y+=flappy.velocity*dt;
 if(flappy.pipes.length===0||flappy.pipes[flappy.pipes.length-1].x<160){
  flappy.pipes.push({x:300,gapY:90+Math.random()*120,scored:false});
 }
 for(const p of flappy.pipes){
  p.x-=1.75*dt;
  if(!p.scored&&p.x+43<72){p.scored=true;flappy.score++;updateFlappyCopy()}
  if(p.x<89&&p.x+43>56&&(flappy.y-11<p.gapY-55||flappy.y+11>p.gapY+55)){
   flappyEnd();return;
  }
 }
 flappy.pipes=flappy.pipes.filter(p=>p.x>-55);
 if(flappy.y<12||flappy.y>292){flappyEnd();return}
 drawPhoneFlappy();flappy.raf=requestAnimationFrame(stepPhoneFlappy);
}
function drawPhoneFlappy(){
 const c=flappyCtx;c.clearRect(0,0,280,320);
 c.fillStyle="#92dff0";c.fillRect(0,0,280,320);
 c.fillStyle="#ecfbff";
 for(const [x,y] of [[20,45],[164,60],[245,22]]){
  c.beginPath();c.ellipse(x,y,26,10,0,0,Math.PI*2);c.fill();
 }
 c.fillStyle="#84c2a9";c.fillRect(0,300,280,20);
 c.fillStyle="#d8c78e";c.fillRect(0,305,280,15);
 for(const pipe of flappy.pipes){
  c.fillStyle="#399b5f";c.fillRect(pipe.x,0,43,pipe.gapY-55);
  c.fillRect(pipe.x,pipe.gapY+55,43,300-(pipe.gapY+55));
  c.fillStyle="#6ddc86";c.fillRect(pipe.x+4,0,6,Math.max(0,pipe.gapY-55));
  c.fillRect(pipe.x+4,pipe.gapY+55,6,300-(pipe.gapY+55));
  c.fillStyle="#267947";c.fillRect(pipe.x-3,pipe.gapY-66,49,11);
  c.fillRect(pipe.x-3,pipe.gapY+55,49,11);
 }
 c.save();c.translate(72,flappy.y);c.rotate(Math.max(-.35,Math.min(.65,flappy.velocity*.07)));
 c.fillStyle="#e8bd46";c.beginPath();c.ellipse(0,0,13,11,0,0,Math.PI*2);c.fill();
 c.fillStyle="#ffe986";c.beginPath();c.ellipse(-5,4,7,5,0,0,Math.PI*2);c.fill();
 c.fillStyle="#f7864b";c.beginPath();c.moveTo(11,-1);c.lineTo(21,3);c.lineTo(11,7);c.fill();
 c.fillStyle="#fff";c.beginPath();c.arc(5,-4,4.2,0,Math.PI*2);c.fill();
 c.fillStyle="#283f4c";c.beginPath();c.arc(6,-4,1.7,0,Math.PI*2);c.fill();c.restore();
 if(flappy.phase!=="playing"){
  c.fillStyle="#153b4bbc";c.beginPath();c.roundRect(29,125,222,76,13);c.fill();
  c.fillStyle="#fff";c.textAlign="center";c.font="bold 18px system-ui";
  c.fillText(flappy.phase==="over"?"GAME OVER":"FLAPPY",140,154);
  c.font="13px system-ui";c.fillText(flappy.phase==="over"?"Tap to restart":"Tap to start",140,178);
 }
}
flappyCanvas.addEventListener("pointerdown",e=>{e.preventDefault();phoneFlap()},{passive:false});
$("phoneFlappyBtn").addEventListener("click",phoneFlap);
document.addEventListener("keydown",e=>{
 if(phoneOpen&&phoneApp==="flappy"&&(e.code==="Space"||e.code==="ArrowUp")&&document.activeElement?.tagName!=="INPUT"){
  e.preventDefault();phoneFlap();
 }
});

function renderUncleMenu(resetScroll=false){
 const drinks=uncleMenuCategory==="drinks";
 const items=UNCLE_ALS_MENU[uncleMenuCategory];
 const owned=new Set(inventoryIds(me()));
 for(const tab of document.querySelectorAll("[data-uncle-category]")){
  const active=tab.dataset.uncleCategory===uncleMenuCategory;
  tab.classList.toggle("selected",active);
  tab.setAttribute("aria-selected",active?"true":"false");
 }
 const list=$("uncleMenuItems"),previousScroll=list.scrollTop;list.replaceChildren();
 for(const item of items){
  const have=owned.has(item.id);
  const card=document.createElement("button");card.type="button";
  card.className="uncleMenuItem"+(have?" owned":"");
  card.setAttribute("aria-label",item.name+(have?", already in inventory":", add to inventory"));
  const icon=document.createElement("div");icon.className="uncleMenuIcon";icon.textContent=item.icon;
  icon.style.setProperty("--food-tint",item.accent);
  const detail=document.createElement("div");detail.className="uncleMenuDetail";
  const name=document.createElement("strong");name.textContent=item.name;
  const desc=document.createElement("span");desc.textContent=item.desc;
  detail.append(name,desc);
  const action=document.createElement("span");action.className="uncleMenuAdd";
  action.textContent=have?"✓ Owned":"+ Add";
  card.append(icon,detail,action);
  card.addEventListener("click",()=>{
   if(!joined||!nearUncleAl(me())){
    $("uncleMenuNotice").textContent="Walk closer to Uncle Al's counter.";
    return;
   }
   if(inventoryIds().includes(item.id)){
    $("uncleMenuNotice").textContent=item.name+" is already in your inventory.";
    return;
   }
   if(inventoryIds().length>=80){
    $("uncleMenuNotice").textContent="Inventory full (80 items).";return;
   }
   if(!broadcast("inventory-action",{action:"add",itemId:item.id})){
    $("uncleMenuNotice").textContent="You're not connected right now.";return;
   }
   $("uncleMenuNotice").textContent="Adding "+item.name+"…";
  });
  list.appendChild(card);
 }
 $("uncleMenuSectionTitle").textContent=drinks?"Something to sip":"Something to snack on";
 $("uncleMenuCount").textContent=items.length+" choices";
 list.scrollTop=resetScroll?0:previousScroll;
}
function openUncleMenu(){
 if(!nearUncleAl(me()))return;
 uncleMenuOpen=true;uncleMenuCategory="drinks";
 $("uncleMenuNotice").textContent="Tap any item to add it to your inventory.";
 input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 $("uncleMenuModal").classList.remove("hidden");
 renderUncleMenu(true);
}
function closeUncleMenu(){
 uncleMenuOpen=false;$("uncleMenuModal").classList.add("hidden");
}
$("closeUncleMenuBtn").addEventListener("click",closeUncleMenu);
for(const tab of document.querySelectorAll("[data-uncle-category]")){
 tab.addEventListener("click",()=>{
  uncleMenuCategory=tab.dataset.uncleCategory;
  renderUncleMenu(true);
 });
}
$("uncleMenuModal").addEventListener("pointerdown",e=>{
 if(e.target===$("uncleMenuModal"))closeUncleMenu();
});
function openCommunityBoard(){
 if(!boardNearPlayer(me()))return;
 communityOpen=true;communityPointer=null;input.x=input.y=0;
 $("stick").style.transform="translate(0,0)";
 $("communityModal").classList.remove("hidden");paintCommunityEditor();
 broadcast("community-sync");
}
function closeCommunityBoard(){communityOpen=false;communityPointer=null;$("communityModal").classList.add("hidden")}
function communityPosition(e){
 const r=communityCanvas().getBoundingClientRect();
 return {x:clamp(Math.round((e.clientX-r.left)*1000/r.width),0,1000),
         y:clamp(Math.round((e.clientY-r.top)*1000/r.height),0,1000)};
}
function submitCommunitySegment(a,b){
 if(!boardNearPlayer(me())){closeCommunityBoard();return}
 const seg=[a.x,a.y,b.x,b.y,communityColor,communityPen];
 appendBoardStroke(seg);
 broadcast("community-draw",{segment:seg});
}
function setupCommunityBoard(){
 const swatches=$("communitySwatches");
 BOARD_COLORS.forEach((color,i)=>{
  const b=document.createElement("button");b.type="button";b.className="communityColor"+(i===0?" selected":"");
  b.style.background=color;b.setAttribute("aria-label",i===BOARD_COLORS.length-1?"White eraser":`Color ${i+1}`);
  b.addEventListener("click",()=>{
   communityColor=i;
   for(const child of swatches.children)child.classList.toggle("selected",child===b);
  });swatches.appendChild(b);
 });
 $("closeCommunityBtn").addEventListener("click",closeCommunityBoard);
 $("communityPenSize").addEventListener("change",()=>{communityPen=Number($("communityPenSize").value)||2});
 $("communityClearBtn").addEventListener("click",()=>{
  if(!boardNearPlayer(me())){closeCommunityBoard();return}
  if(!confirm("Clear everyone's drawing from this room's whiteboard?"))return;
  broadcast("community-clear");
  // The server broadcasts the authoritative new board to all participants.
 });
 const cv=communityCanvas();
 cv.addEventListener("pointerdown",e=>{
  if(!communityOpen||!boardNearPlayer(me()))return;
  e.preventDefault();cv.setPointerCapture?.(e.pointerId);
  communityPointer={id:e.pointerId,point:communityPosition(e)};
  communityLastEmit=0;
  // A dot is still visible when a player only taps once.
  submitCommunitySegment(communityPointer.point,communityPointer.point);
 },{passive:false});
 cv.addEventListener("pointermove",e=>{
  if(!communityPointer||communityPointer.id!==e.pointerId)return;
  e.preventDefault();
  const next=communityPosition(e);
  if(Math.abs(next.x-communityPointer.point.x)+Math.abs(next.y-communityPointer.point.y)<2)return;
  const t=performance.now();if(t-communityLastEmit<22)return;
  submitCommunitySegment(communityPointer.point,next);
  communityPointer.point=next;communityLastEmit=t;
 },{passive:false});
 const end=e=>{
  if(!communityPointer||communityPointer.id!==e.pointerId)return;
  if(e.type==="pointerup"){
   const last=communityPosition(e);
   if(Math.abs(last.x-communityPointer.point.x)+Math.abs(last.y-communityPointer.point.y)>=2)
     submitCommunitySegment(communityPointer.point,last);
   broadcast("community-finish");
  }
  communityPointer=null;
 };
 cv.addEventListener("pointerup",end);cv.addEventListener("pointercancel",end);
 repaintCommunityBoard();
}
setupCommunityBoard();
function drawCommunityWorldBoard(c){
 const {x,y,w,h}=COMMUNITY_BOARD;
 // Freestanding framed board near the middle of the shopping arcade.
 c.fillStyle="#142b35aa";c.beginPath();c.ellipse(x+w/2,y+h+49,115,16,0,0,Math.PI*2);c.fill();
 c.fillStyle="#4f6c70";c.fillRect(x+29,y+h-1,9,54);c.fillRect(x+w-38,y+h-1,9,54);
 c.fillStyle="#345159";c.fillRect(x+8,y+h+44,w-16,8);
 c.fillStyle="#52696c";c.beginPath();c.roundRect(x-4,y-5,w+8,h+12,10);c.fill();
 c.strokeStyle="#a8c1c0";c.lineWidth=3;c.stroke();
 c.fillStyle="#dbe8e4";c.beginPath();c.roundRect(x+5,y+5,w-10,h-10,5);c.fill();
 c.fillStyle="#1f5260";c.beginPath();c.roundRect(x+12,y+11,w-24,24,3);c.fill();
 c.textAlign="center";c.fillStyle="#eefafa";c.font="900 13px system-ui,sans-serif";
 c.fillText("COMMUNITY BOARD",x+w/2,y+27);
 c.drawImage(boardCache,x+11,y+40,w-22,h-52);
 c.strokeStyle="#adc9c6";c.lineWidth=1;c.strokeRect(x+11,y+40,w-22,h-52);
 c.fillStyle="#d6b77f";c.fillRect(x+56,y+h+3,92,4);
}
function drawPublicBench(c,x,y){
 c.fillStyle="#1f344150";c.beginPath();c.ellipse(x,y+28,65,12,0,0,Math.PI*2);c.fill();
 c.fillStyle="#3b545e";c.beginPath();c.roundRect(x-52,y-16,104,22,6);c.fill();
 c.fillStyle="#9bb7b2";c.fillRect(x-47,y-13,94,4);
 c.fillStyle="#526f74";c.beginPath();c.roundRect(x-53,y+3,106,15,5);c.fill();
 c.fillStyle="#b0c7c0";c.fillRect(x-48,y+4,96,3);
 for(const dx of [-43,36]){c.fillStyle="#344850";c.fillRect(x+dx,y+18,7,19);}
}
function drawLatestUpdateBoard(c){
 const x=517,y=612,w=171,h=126;
 c.fillStyle="#34454b";c.fillRect(x+13,y+h-3,8,30);c.fillRect(x+w-21,y+h-3,8,30);
 c.fillStyle="#547476";c.beginPath();c.roundRect(x-3,y-4,w+6,h+8,8);c.fill();
 c.fillStyle="#fbfcf9";c.beginPath();c.roundRect(x+5,y+5,w-10,h-10,4);c.fill();
 c.fillStyle="#1d5762";c.fillRect(x+12,y+13,w-24,24);
 c.textAlign="center";c.fillStyle="#fff";c.font="900 11px system-ui,sans-serif";c.fillText("LATEST UPDATE · v0.19.6",x+w/2,y+29);
 c.fillStyle="#243b43";c.textAlign="left";c.font="800 11px system-ui,sans-serif";
 for(const [i,line] of ["The Artifact arcade","Central lounge seating","Sliding storefront doors"].entries()){
  c.fillStyle=["#58aaa6","#c58bdb","#76b0c8"][i];c.beginPath();c.arc(x+19,y+54+i*22,3,0,Math.PI*2);c.fill();
  c.fillStyle="#263d46";c.fillText(line,x+30,y+58+i*22);
 }
}

function drawMallCorridor(){
 const c=ctx,w=MALL_WORLD_W;
 c.save();
 const wall=c.createLinearGradient(0,0,0,366);
 wall.addColorStop(0,"#132231");wall.addColorStop(.45,"#304655");wall.addColorStop(1,"#56666d");
 c.fillStyle=wall;c.fillRect(0,0,w,363);
 // Continuous roof-light bays and structural ribs.
 c.fillStyle="#162737";c.fillRect(0,0,w,78);
 const left=Math.max(0,Math.floor((mallCameraX-40)/230)*230);
 const right=Math.min(w,mallCameraX+WORLD_W+260);
 for(let x=left;x<right;x+=230){
  c.fillStyle="#a6d2dc";c.beginPath();c.moveTo(x+23,0);c.lineTo(x+205,0);c.lineTo(x+189,60);c.lineTo(x+40,60);c.closePath();c.fill();
  c.fillStyle="#d7edf170";c.fillRect(x+66,0,22,56);
  c.strokeStyle="#4e7684";c.lineWidth=5;
  c.beginPath();c.moveTo(x+114,0);c.lineTo(x+114,61);c.stroke();
 }
 c.fillStyle="#314958";c.fillRect(0,78,w,12);
 c.fillStyle="#6d929c";c.fillRect(0,90,w,5);
 c.fillStyle="#263f4c";c.fillRect(0,95,w,46);
 c.fillStyle="#b3babb";c.fillRect(0,355,w,6);
 c.fillStyle="#3b515b";c.fillRect(0,361,w,11);
 // The floor stays greyscale and seamless like the atrium's polished stone.
 const floor=c.createLinearGradient(0,372,0,780);
 floor.addColorStop(0,"#99a5a9");floor.addColorStop(.52,"#aeb7b7");floor.addColorStop(1,"#849298");
 c.fillStyle=floor;c.fillRect(0,372,w,408);
 c.fillStyle="#ffffff12";c.fillRect(0,373,w,22);
 for(let y=395;y<777;y+=18){
  for(let x=Math.floor(mallCameraX/28)*28;x<right;x+=28){
   const hash=(x*37+y*19)%97,shade=105+(hash%70),alpha=.035+(hash%8)*.006;
   c.fillStyle=`rgba(${shade},${shade},${shade},${alpha})`;
   c.fillRect(x+(hash%5),y+(hash%3),2+(hash%3),1+(hash%2));
  }
 }
 // Display windows and masonry pillars.
 for(const s of MALL_STORES){
  if(s.x+s.w<mallCameraX-80||s.x>right)continue;
  drawMallStore(c,s);
 }
 for(let i=0;i<MALL_STORES.length-1;i++){
  const leftStore=MALL_STORES[i],rightStore=MALL_STORES[i+1];
  const leftEdge=(leftStore.x-8)+(leftStore.w+16);
  const rightEdge=(rightStore.x-7);
  const x=Math.round((leftEdge+rightEdge)/2-18);
  if(x<mallCameraX-65||x>right)continue;
  const stone=c.createLinearGradient(x,0,x+36,0);
  stone.addColorStop(0,"#4b606b");stone.addColorStop(.45,"#a7b4b2");stone.addColorStop(1,"#475967");
  c.fillStyle=stone;c.fillRect(x,135,36,236);
  c.fillStyle="#b9c6c2";c.fillRect(x-7,132,50,8);c.fillRect(x-5,361,46,7);
 }
 // The mall's return entrance is a pair of outward-swinging hinged doors.
 // "Outward" means AWAY from the mall viewer, INTO the atrium. The far/free
 // edges therefore recede in perspective rather than swinging toward the floor.
 c.save();
 const doorOpen=clamp(mallReturnDoorOpen,0,1);
 const doorX=80,doorRight=220,doorTop=164,doorBottom=348;
 const doorCenter=(doorX+doorRight)/2, doorMidY=(doorTop+doorBottom)/2;
 const angle=doorOpen*Math.PI*69/180;
 const projectedHalf=(doorRight-doorX)/2*Math.cos(angle);
 const depth=(doorRight-doorX)/2*Math.sin(angle);
 const perspective=390/(390+depth);
 const leftFreeX=doorCenter+(doorX+projectedHalf-doorCenter)*perspective;
 const rightFreeX=doorCenter+(doorRight-projectedHalf-doorCenter)*perspective;
 const freeTopY=doorMidY+(doorTop-doorMidY)*perspective;
 const freeBottomY=doorMidY+(doorBottom-doorMidY)*perspective;
 // Architectural jambs remain stationary.
 const entranceWall=c.createLinearGradient(52,140,238,140);
 entranceWall.addColorStop(0,"#334653");entranceWall.addColorStop(.22,"#788990");
 entranceWall.addColorStop(.8,"#657a83");entranceWall.addColorStop(1,"#293f4e");
 c.fillStyle=entranceWall;c.fillRect(55,135,185,235);
 c.fillStyle="#c2d0cc";c.fillRect(50,133,194,9);
 c.fillStyle="#556a72";c.fillRect(50,364,194,8);
 c.fillStyle="#142630";c.fillRect(67,152,165,204);
 // Light is revealed ONLY through the growing gap between the door leaves.
 // At zero openness the passage and the floor are completely unlit.
 const gap=rightFreeX-leftFreeX;
 if(doorOpen>.006&&gap>1){
  const lightAmount=Math.pow(doorOpen,1.25);
  c.save();
  c.beginPath();c.rect(leftFreeX,doorTop,rightFreeX-leftFreeX,doorBottom-doorTop);c.clip();
  const portal=c.createLinearGradient(98,155,183,355);
  portal.addColorStop(0,"#738083");portal.addColorStop(.37,"#beae87");
  portal.addColorStop(.78,"#f5dba2");portal.addColorStop(1,"#ffedbb");
  c.globalAlpha=lightAmount;
  c.fillStyle=portal;c.fillRect(doorX,doorTop,doorRight-doorX,doorBottom-doorTop);
  c.fillStyle="#fff3c65e";
  c.beginPath();c.moveTo(143,167);c.lineTo(177,167);c.lineTo(215,345);
  c.lineTo(177,345);c.closePath();c.fill();
  c.restore();
  // The spill widens as the leaves open, and vanishes completely when closed.
  // It starts below the door threshold, not behind the glass panels.
  c.save();
  const spread=145*doorOpen;
  c.beginPath();c.moveTo(leftFreeX,356);c.lineTo(rightFreeX,356);
  c.lineTo(rightFreeX+spread,588);c.lineTo(leftFreeX-spread,588);
  c.closePath();c.clip();
  const spill=c.createLinearGradient(0,351,0,591);
  spill.addColorStop(0,"#ffe9adad");spill.addColorStop(.45,"#ffe6a957");
  spill.addColorStop(1,"#ffe8bc00");
  c.globalAlpha=lightAmount;
  c.fillStyle=spill;c.fillRect(0,354,365,236);
  c.restore();
 }
 // The two opaque leaves begin joined at the middle and retract toward their
 // jambs while the free edges diminish into the atrium's vanishing point.
 for(const leftLeaf of [true,false]){
  const hingeX=leftLeaf?doorX:doorRight;
  const freeX=leftLeaf?leftFreeX:rightFreeX;
  const at=(t,v)=>{
   const edgeX=hingeX+(freeX-hingeX)*t;
   const top=doorTop+(freeTopY-doorTop)*t;
   const bottom=doorBottom+(freeBottomY-doorBottom)*t;
   return [edgeX,top+(bottom-top)*v];
  };
  const polygon=points=>{
   c.beginPath();c.moveTo(...points[0]);
   for(let i=1;i<points.length;i++)c.lineTo(...points[i]);
   c.closePath();
  };
  c.save();
  polygon([at(0,0),at(1,0),at(1,1),at(0,1)]);
  const face=c.createLinearGradient(hingeX,0,freeX,0);
  face.addColorStop(0,"#3d7182");face.addColorStop(.55,"#285066");face.addColorStop(1,"#122e42");
  c.fillStyle=face;c.fill();
  c.strokeStyle="#abc5c8";c.lineWidth=2.8;c.stroke();
  polygon([at(.12,.04),at(.30,.04),at(.59,.96),at(.41,.96)]);
  c.fillStyle="#d0f7f525";c.fill();
  c.beginPath();c.moveTo(...at(.09,.04));c.lineTo(...at(.09,.96));
  c.strokeStyle="#c6f4eb55";c.lineWidth=1.8;c.stroke();
  // Pull handle and lit free-edge trim follow the rotating panel.
  c.beginPath();c.moveTo(...at(.85,.44));c.lineTo(...at(.85,.61));
  c.strokeStyle="#f2e8cf";c.lineWidth=3.5;c.lineCap="round";c.stroke();
  c.beginPath();c.moveTo(...at(1,0));c.lineTo(...at(1,1));
  c.strokeStyle="#d3e8e2a8";c.lineWidth=2;c.stroke();
  c.restore();
 }
 // Fixed stone frame and threshold, with illumination enabled by door opening.
 c.strokeStyle="#aebfc0";c.lineWidth=6;c.strokeRect(76,160,147,191);
 c.strokeStyle="#516773";c.lineWidth=4;
 c.beginPath();c.moveTo(77,354);c.lineTo(223,354);c.stroke();
 if(doorOpen>.006){
  c.strokeStyle=`rgba(255,229,172,${.8*doorOpen})`;c.lineWidth=3;
  c.beginPath();c.moveTo(leftFreeX,354);c.lineTo(rightFreeX,354);c.stroke();
 }
 // Dark textured entrance mat, just outside the threshold.
 c.fillStyle="#162b36a9";
 c.beginPath();c.moveTo(92,376);c.lineTo(209,376);
 c.lineTo(239,418);c.lineTo(66,418);c.closePath();c.fill();
 c.strokeStyle="#a1b0b1";c.lineWidth=3;c.stroke();
 c.strokeStyle="#77949a";c.lineWidth=1.4;
 for(let i=0;i<6;i++){
  const startX=103+i*18;
  c.beginPath();c.moveTo(startX,383);c.lineTo(startX+(i-2)*4,409);c.stroke();
 }
 c.restore();
 // Shared collision-enabled mall benches.
 for(const {x,y} of WALKWAY_BENCHES){
  if(x<mallCameraX-85||x>right)continue;
  c.fillStyle="#16293640";c.beginPath();c.ellipse(x,650,80,16,0,0,Math.PI*2);c.fill();
  c.fillStyle="#4b616b";c.beginPath();c.roundRect(x-48,611,96,15,6);c.fill();
  c.fillStyle="#253e4c";c.fillRect(x-37,626,7,26);c.fillRect(x+30,626,7,26);
  c.fillStyle="#aab9b6";c.fillRect(x-42,610,84,4);
 }
 for(const x of [450,1110,1580,1980]){
  if(x<mallCameraX-80||x>right)continue;
  c.fillStyle="#36515a55";c.beginPath();c.ellipse(x,477,49,14,0,0,Math.PI*2);c.fill();
  c.fillStyle="#4b666a";c.beginPath();c.roundRect(x-34,456,68,25,7);c.fill();
  c.fillStyle="#a9b5ab";c.fillRect(x-34,456,68,4);
  c.fillStyle="#3b735d";
  for(let i=0;i<6;i++){c.save();c.translate(x-22+i*9,453);c.rotate((i-3)*.15);
   c.beginPath();c.ellipse(0,-12,6,19,0,0,Math.PI*2);c.fill();c.restore()}
 }
 drawCommunityWorldBoard(c);
 c.fillStyle="#1a2b39";c.fillRect(w-27,0,27,780);
 c.fillStyle="#a0b4b8";c.fillRect(w-27,0,5,780);
 c.fillStyle="#dcebec";c.font="900 15px system-ui,sans-serif";c.save();
 c.translate(w-13,430);c.rotate(Math.PI/2);c.fillText("MORE STORES COMING SOON",0,0);c.restore();
 c.restore();
}

// Mall Atrium v0.15: a public entrance concourse inspired by GMod Tower's
// vaulted entertainment plaza. These graphics are decoration, not hit zones.
function drawMallAtrium(){
 const c=ctx;
 c.save();
 // Vaulted ceiling and stone-clad upper walls.
 const wall=c.createLinearGradient(0,0,0,345);
 wall.addColorStop(0,"#111d2b");wall.addColorStop(.22,"#273647");
 wall.addColorStop(.78,"#455362");wall.addColorStop(1,"#253749");
 c.fillStyle=wall;c.fillRect(0,0,700,356);
 // Ceiling coffers narrow into the roof light.
 c.fillStyle="#101b28";c.beginPath();c.moveTo(0,0);c.lineTo(700,0);c.lineTo(655,92);c.lineTo(45,92);c.closePath();c.fill();
 c.fillStyle="#425461";c.beginPath();c.moveTo(111,0);c.lineTo(589,0);c.lineTo(543,73);c.lineTo(157,73);c.closePath();c.fill();
 const skylight=c.createLinearGradient(0,0,0,75);skylight.addColorStop(0,"#d0eaf0");skylight.addColorStop(1,"#80afbd");
 c.fillStyle=skylight;c.beginPath();c.moveTo(146,0);c.lineTo(554,0);c.lineTo(525,65);c.lineTo(175,65);c.closePath();c.fill();
 c.strokeStyle="#3d6171";c.lineWidth=6;
 for(const x of [225,307,390,470]){c.beginPath();c.moveTo(x,0);c.lineTo(350+(x-350)*.77,66);c.stroke()}
 c.fillStyle="#ebf8f44f";c.beginPath();c.moveTo(285,0);c.lineTo(416,0);c.lineTo(402,65);c.lineTo(300,65);c.fill();
 // Upper mezzanine windows and stone masonry.
 for(const left of [0,480]){
  const x=left+24;
  c.fillStyle="#162a38";c.fillRect(x,93,190,126);
  for(let i=0;i<4;i++){
   const wx=x+7+i*45;
   const glass=c.createLinearGradient(wx,103,wx,206);glass.addColorStop(0,"#789ca9");glass.addColorStop(1,"#183244");
   c.fillStyle=glass;c.fillRect(wx,104,37,103);
   c.fillStyle="#8fd9d72b";c.fillRect(wx+4,108,5,96);
   c.strokeStyle="#b4bdba5c";c.lineWidth=2;c.strokeRect(wx,104,37,103);
  }
 }
 c.fillStyle="#283d4a";c.fillRect(0,207,700,15);
 c.fillStyle="#9fa7a2";c.fillRect(0,212,700,5);
 c.fillStyle="#172b39";c.fillRect(0,224,700,13);
 // Balustrade establishes a second level above the entrance.
 for(let x=17;x<700;x+=33){c.fillStyle="#aab8ba";c.fillRect(x,221,7,37)}
 c.fillStyle="#758b91";c.fillRect(0,251,700,9);
 c.fillStyle="#bfd0ca";c.fillRect(0,257,700,4);
 // Tall entrance glazing, upper center atrium.
 c.fillStyle="#152c3b";c.beginPath();c.roundRect(234,90,232,230,8);c.fill();
 const glass=c.createLinearGradient(0,98,0,317);
 glass.addColorStop(0,"#b1d4dc");glass.addColorStop(.48,"#5c94a8");glass.addColorStop(1,"#142b40");
 c.fillStyle=glass;c.beginPath();c.roundRect(246,98,208,209,4);c.fill();
 c.fillStyle="#e5fcff27";c.beginPath();c.moveTo(268,104);c.lineTo(290,104);c.lineTo(354,304);c.lineTo(333,304);c.fill();
 // These automatic hinged doors are decorative only; they do not
 // transport players or restore any of the old interaction targets.
 c.strokeStyle="#6e8a95";c.lineWidth=6;c.beginPath();c.moveTo(350,101);c.lineTo(350,234);c.moveTo(249,188);c.lineTo(451,188);c.stroke();
 drawAtriumSwingDoors(c);
 // Large sign integrated into the stone lintel, not a UI control.
 c.shadowColor="#9ed8d9";c.shadowBlur=19;
 c.fillStyle="#193441";c.beginPath();c.roundRect(257,120,185,52,6);c.fill();
 c.shadowBlur=0;c.strokeStyle="#a9c3bd";c.lineWidth=2;c.strokeRect(259,122,181,48);
 c.fillStyle="#f1f8ee";c.font="900 31px system-ui,sans-serif";c.textAlign="center";c.fillText("THE VIBE",350,157);
 // Side alcoves are intentionally plain masonry, with no false doors.
 // The existing wall gradient continues uninterrupted behind the columns.
 // Grand stone columns with capitals and warm uplighting.
 for(const x of [197,503]){
  c.fillStyle="#111f2b7a";c.fillRect(x-19,105,38,259);
  const stone=c.createLinearGradient(x-24,0,x+24,0);
  stone.addColorStop(0,"#394956");stone.addColorStop(.27,"#9baaa8");stone.addColorStop(.57,"#c1c8bd");stone.addColorStop(1,"#42525f");
  c.fillStyle=stone;c.fillRect(x-19,110,38,241);
  c.fillStyle="#8e9b9a";c.fillRect(x-29,103,58,17);c.fillRect(x-26,332,52,28);
  c.fillStyle="#d6d6c6";c.fillRect(x-26,105,52,4);c.fillRect(x-25,336,50,5);
  c.fillStyle="#d7b47c";c.shadowBlur=19;c.shadowColor="#eac18c";
  c.fillRect(x-22,314,4,19);c.fillRect(x+18,314,4,19);c.shadowBlur=0;
 }
 // Symmetrical stairs form a ceremonial landing behind the open floor.
 c.fillStyle="#637782";c.fillRect(226,319,248,37);
 for(let i=0;i<5;i++){
  const sy=329+i*10;
  c.fillStyle=i%2?"#85969a":"#9eaba8";
  c.fillRect(229-i*7,sy,242+i*14,10);
  c.fillStyle="#4a626e";c.fillRect(229-i*7,sy+8,242+i*14,3);
 }
 // Main ground is cleaner polished stone: no grid, just subtle tonal variation.
 const floor=c.createLinearGradient(0,351,0,780);
 floor.addColorStop(0,"#909ba2");floor.addColorStop(.46,"#aab2b5");floor.addColorStop(1,"#879297");
 c.fillStyle=floor;c.fillRect(0,354,700,426);
 c.fillStyle="#ffffff10";c.beginPath();c.ellipse(350,430,210,55,0,0,Math.PI*2);c.fill();
 c.fillStyle="#00000010";c.beginPath();c.ellipse(350,700,290,120,0,0,Math.PI*2);c.fill();
 // Greyscale terrazzo-like speckling keeps the floor from feeling flat.
 for(let y=362;y<776;y+=14){
  for(let x=18+(y%28===0?8:0);x<684;x+=22){
   const hash=(x*17+y*31)%97;
   const alpha=.03+(hash%9)*.006;
   const tone=150+(hash%40);
   c.fillStyle=`rgba(${tone},${tone},${tone},${alpha.toFixed(3)})`;
   c.fillRect(x,y+(hash%5),2+(hash%3),1+(hash%2));
   if(hash%4===0){
    const tone2=98+(hash%30);
    c.fillStyle=`rgba(${tone2},${tone2},${tone2},${(.018+(hash%5)*.004).toFixed(3)})`;
    c.fillRect(x+6,y+3+(hash%4),1+(hash%2),1);
   }
  }
 }
 // Decorative central terrazzo medallion, flush with the floor: spawn point.
 c.save();c.translate(350,515);c.scale(1,.64);
 c.fillStyle="#7b8d93";c.strokeStyle="#d8cfac";c.lineWidth=9;
 c.beginPath();c.arc(0,0,118,0,Math.PI*2);c.fill();c.stroke();
 c.strokeStyle="#4b5f67";c.lineWidth=5;c.beginPath();c.arc(0,0,96,0,Math.PI*2);c.stroke();
 c.fillStyle="#d4ceb0";c.beginPath();
 for(let i=0;i<16;i++){
  const a=i*Math.PI/8-Math.PI/2,r=i%2===0?80:32;
  if(i===0)c.moveTo(Math.cos(a)*r,Math.sin(a)*r);
  else c.lineTo(Math.cos(a)*r,Math.sin(a)*r);
 }
 c.closePath();c.fill();
 c.fillStyle="#5f7b84";c.beginPath();c.arc(0,0,24,0,Math.PI*2);c.fill();
 c.restore();
 // Wall-side green islands and suspended sign provide scale, not interactions.
 for(const [x,y] of [[65,429],[633,429]]){
  c.fillStyle="#344c4e66";c.beginPath();c.ellipse(x,y+35,55,19,0,0,Math.PI*2);c.fill();
  c.fillStyle="#4e6668";c.beginPath();c.roundRect(x-44,y+4,88,30,9);c.fill();
  c.fillStyle="#a9b6a7";c.fillRect(x-44,y+5,88,5);
  c.fillStyle="#396e56";
  for(let i=0;i<7;i++){
   const px=x-30+i*10,angle=(i-3)*.18;
   c.save();c.translate(px,y+2);c.rotate(angle);
   c.beginPath();c.ellipse(0,-13,7,23,0,0,Math.PI*2);c.fill();c.restore();
  }
 }
 // Added atrium benches, with sit targets represented by their natural surfaces.
 for(const bench of ATRIUM_BENCHES)drawPublicBench(c,bench.x,bench.y);
 drawLatestUpdateBoard(c);
 // Foreground masonry returns and indirect ceiling reflections.
 const edge=c.createLinearGradient(0,0,90,0);
 edge.addColorStop(0,"#253b4cdb");edge.addColorStop(1,"#253b4c00");
 c.fillStyle=edge;c.fillRect(0,0,95,780);
 c.save();c.translate(700,0);c.scale(-1,1);c.fillStyle=edge;c.fillRect(0,0,95,780);c.restore();
 // Gentle, consistent natural-light cast. Purely decorative animation.
 c.fillStyle="#e5f5ef";c.globalAlpha=.032+.008*Math.sin(ambientTick*.012);
 c.beginPath();c.moveTo(264,0);c.lineTo(433,0);c.lineTo(620,780);c.lineTo(90,780);c.fill();
 c.globalAlpha=1;
 c.restore();
}

function drawVibeBackdrop(){
 ctx.save();
 const wall=ctx.createLinearGradient(0,0,0,236);
 wall.addColorStop(0,"#0b1132");wall.addColorStop(.63,"#251347");wall.addColorStop(1,"#221a3e");
 ctx.fillStyle=wall;ctx.fillRect(0,0,WORLD_W,236);
 // Accent wall slats and light pillars.
 ctx.fillStyle="#8655c21b";
 for(let x=0;x<700;x+=36)ctx.fillRect(x,0,9,228);
 for(const x of [9,682]){
  ctx.fillStyle="#cd87ff";ctx.shadowColor="#c679ff";ctx.shadowBlur=14;
  ctx.fillRect(x,3,7,220);
 }
 ctx.shadowBlur=0;
 // Panoramic night-city windows flank the neon venue logo.
 for(const [x,w] of [[170,97],[438,97]]){
  ctx.fillStyle="#070f24";ctx.strokeStyle="#6e5f9e";ctx.lineWidth=4;
  ctx.beginPath();ctx.roundRect(x,30,w,135,12);ctx.fill();ctx.stroke();
  const skyline=[23,40,28,61,37,53,24,35];
  ctx.fillStyle="#18294a";
  skyline.forEach((h,i)=>ctx.fillRect(x+8+i*10,157-h,9,h));
  ctx.fillStyle="#73e6ff88";
  skyline.forEach((h,i)=>{if(i%2===0)for(let j=0;j<2;j++)ctx.fillRect(x+11+i*10,151-h+j*12,2,3)});
  ctx.strokeStyle="#678abb";ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(x+w/2,32);ctx.lineTo(x+w/2,164);ctx.stroke();
 }
 // Oversized illuminated welcome sign, as the focal point of the public hub.
 ctx.shadowColor="#de70fa";ctx.shadowBlur=25;
 ctx.fillStyle="#331849";ctx.strokeStyle="#cd75ee";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(275,35,152,111,17);ctx.fill();ctx.stroke();
 ctx.shadowBlur=12;ctx.fillStyle="#f6d8ff";ctx.textAlign="center";
 ctx.font="1000 17px system-ui,sans-serif";ctx.fillText("THE",351,64);
 ctx.font="1000 35px system-ui,sans-serif";ctx.fillText("VIBE",351,107);
 ctx.shadowBlur=0;
 ctx.fillStyle="#9ceff1";ctx.font="800 10px system-ui,sans-serif";
 ctx.fillText("PUBLIC SOCIAL HUB",351,128);
 // Edge-lit wall trim with pulsing cyan and pink bulbs.
 ctx.fillStyle="#0b0c1c";ctx.fillRect(0,228,700,14);
 ctx.shadowColor="#45dff4";ctx.shadowBlur=10;ctx.fillStyle="#54e3f6";ctx.fillRect(0,227,700,3);
 ctx.shadowBlur=0;
 // Dark purple terrazzo tile, a different floor from the private lounge.
 const floor=ctx.createLinearGradient(0,242,0,WORLD_H);
 floor.addColorStop(0,"#202546");floor.addColorStop(1,"#11172f");
 ctx.fillStyle=floor;ctx.fillRect(0,242,700,538);
 ctx.strokeStyle="#9a80cc1d";ctx.lineWidth=1;
 for(let x=0;x<700;x+=45){ctx.beginPath();ctx.moveTo(x,242);ctx.lineTo(x,780);ctx.stroke()}
 for(let y=242;y<780;y+=45){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(700,y);ctx.stroke()}
 // Central dance floor: animated rings under avatars (not a touch target).
 const pulse=.68+.25*Math.sin(ambientTick*.035);
 const disc=ctx.createRadialGradient(347,383,9,347,383,176);
 disc.addColorStop(0,"#6041a4");disc.addColorStop(.72,"#332555");disc.addColorStop(1,"#171833");
 ctx.fillStyle=disc;ctx.strokeStyle="#7859b0";ctx.lineWidth=8;
 ctx.beginPath();ctx.ellipse(347,388,168,119,0,0,Math.PI*2);ctx.fill();ctx.stroke();
 ctx.save();ctx.globalAlpha=pulse;ctx.strokeStyle="#77f5ff";ctx.shadowColor="#4be7f5";ctx.shadowBlur=14;ctx.lineWidth=4;
 ctx.beginPath();ctx.ellipse(347,388,136,92,0,0,Math.PI*2);ctx.stroke();
 ctx.strokeStyle="#f4a5f7";ctx.shadowColor="#e977e5";
 ctx.beginPath();ctx.ellipse(347,388,93,62,0,0,Math.PI*2);ctx.stroke();
 ctx.restore();
 // Animated disco tile inlays.
 for(let i=0;i<12;i++){
  const a=i*Math.PI/6;const x=347+108*Math.cos(a),y=388+70*Math.sin(a);
  ctx.fillStyle=i%2?"#a588e5":"#87dcea";ctx.globalAlpha=.2+.12*Math.sin(i+ambientTick*.04);
  ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();
 }
 ctx.globalAlpha=1;
 // Faceted disco ball and gentle beams.
 const shimmer=.65+.2*Math.sin(ambientTick*.055);
 ctx.strokeStyle="#a6b7d3";ctx.lineWidth=2;
 ctx.beginPath();ctx.moveTo(350,145);ctx.lineTo(350,207);ctx.stroke();
 ctx.fillStyle="#cfe2f9";ctx.shadowBlur=14;ctx.shadowColor="#8bd8ff";
 ctx.beginPath();ctx.arc(350,211,19,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
 ctx.strokeStyle="#607da9";ctx.lineWidth=1;
 for(let i=-12;i<=12;i+=8){ctx.beginPath();ctx.moveTo(332,211+i);ctx.lineTo(368,211+i);ctx.stroke()}
 ctx.beginPath();ctx.moveTo(350,192);ctx.lineTo(350,230);ctx.stroke();
 ctx.fillStyle=`rgba(155,240,251,${.035*shimmer})`;
 ctx.beginPath();ctx.moveTo(350,226);ctx.lineTo(182,486);ctx.lineTo(520,486);ctx.closePath();ctx.fill();
 // Game corner landing pad, same position as the private activity table.
 ctx.fillStyle="#19162e";ctx.strokeStyle="#ad74d077";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(19,553,183,155,23);ctx.fill();ctx.stroke();
 ctx.strokeStyle="#f38bd688";ctx.lineWidth=2;
 ctx.beginPath();ctx.roundRect(28,562,165,137,17);ctx.stroke();
 // Floor guidance, low contrast and below player model.
 ctx.fillStyle="#b5a6de";ctx.globalAlpha=.6;ctx.font="900 12px system-ui,sans-serif";ctx.textAlign="center";
 ctx.fillText("DANCE · CHAT · HANG OUT",351,536);
 ctx.globalAlpha=1;
 ctx.restore();
}
function drawVibeFurniture(){
 ctx.save();
 // Right-side banquette: preserve sofa1 and sofa2 hitboxes/seating anchors.
 ctx.fillStyle="#08091988";ctx.beginPath();ctx.ellipse(568,522,103,25,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#482959";ctx.strokeStyle="#c478d6";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(482,440,177,86,22);ctx.fill();ctx.stroke();
 ctx.fillStyle="#2c214a";
 ctx.beginPath();ctx.roundRect(495,455,72,53,13);ctx.fill();
 ctx.beginPath();ctx.roundRect(574,455,72,53,13);ctx.fill();
 ctx.strokeStyle="#ffa4ed";ctx.lineWidth=2;
 ctx.beginPath();ctx.moveTo(570,454);ctx.lineTo(570,515);ctx.stroke();
 ctx.fillStyle="#f4c9ff";ctx.textAlign="center";ctx.font="900 10px system-ui,sans-serif";
 ctx.fillText("SIT",532,497);ctx.fillText("SIT",606,497);
 // Lounge coffee table and existing smoke interaction.
 ctx.fillStyle="#070b1988";ctx.beginPath();ctx.ellipse(416,533,60,19,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#302b48";ctx.strokeStyle="#9876c2";ctx.lineWidth=3;
 ctx.beginPath();ctx.roundRect(365,498,100,49,12);ctx.fill();ctx.stroke();
 ctx.strokeStyle="#54d7e0";ctx.lineWidth=2;
 ctx.beginPath();ctx.moveTo(380,506);ctx.lineTo(451,506);ctx.stroke();
 drawBong();
 // Decorative DJ console along the upper-right wall, non-interactive.
 ctx.fillStyle="#0d1027";ctx.strokeStyle="#6a81a6";ctx.lineWidth=3;
 ctx.beginPath();ctx.roundRect(500,197,170,70,10);ctx.fill();ctx.stroke();
 ctx.fillStyle="#a774db";ctx.font="900 12px system-ui,sans-serif";ctx.textAlign="center";
 ctx.fillText("VIBE STATION",583,217);
 for(const x of [537,633]){
  ctx.strokeStyle="#7fdfed";ctx.lineWidth=2;
  ctx.beginPath();ctx.arc(x,245,14,0,Math.PI*2);ctx.stroke();
  ctx.fillStyle="#182944";ctx.beginPath();ctx.arc(x,245,6,0,Math.PI*2);ctx.fill();
 }
 for(let x=559;x<615;x+=9){ctx.fillStyle=(x%3===0)?"#f794e4":"#79e7e8";ctx.fillRect(x,238,4,17)}
 // Decorative planters; no obstruction to movement or interactions.
 drawPlant(204,173,.7);drawPlant(675,321,.78);
 ctx.restore();
}
function drawTheatreDoor(){
 const d=THEATRE_DOOR;
 ctx.save();
 ctx.fillStyle="#07111b99";ctx.beginPath();ctx.ellipse(d.x+65,d.y+d.h+15,90,21,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#50647b";ctx.strokeStyle="#a6c8d8";ctx.lineWidth=5;
 ctx.beginPath();ctx.roundRect(d.x-5,d.y-10,d.w+10,d.h+15,13);ctx.fill();ctx.stroke();
 ctx.fillStyle="#121d30";ctx.beginPath();ctx.roundRect(d.x+7,d.y+4,d.w-14,d.h-16,8);ctx.fill();
 ctx.fillStyle="#789bb1";ctx.fillRect(d.x+65,d.y+6,3,d.h-20);
 ctx.fillStyle="#87d9ff";ctx.shadowBlur=12;ctx.shadowColor="#7fd4ff";
 ctx.beginPath();ctx.arc(d.x+d.w-29,d.y+105,6,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
 ctx.textAlign="center";ctx.fillStyle="#fff";ctx.font="900 14px sans-serif";
 ctx.fillText("THEATRE",d.x+d.w/2,d.y+33);
 ctx.font="800 12px sans-serif";ctx.fillStyle="#a8d9fa";ctx.fillText("TAP TO",d.x+d.w/2,d.y+62);ctx.fillText("ENTER",d.x+d.w/2,d.y+78);
 ctx.restore();
}
function drawTheatreBackdrop(){
 const g=ctx.createLinearGradient(0,0,0,WORLD_H);g.addColorStop(0,"#0b101b");g.addColorStop(.64,"#19202d");g.addColorStop(1,"#342b39");
 ctx.fillStyle=g;ctx.fillRect(0,0,WORLD_W,WORLD_H);
 // Tall side curtains, cinematic wall and velvet floor aisle.
 ctx.fillStyle="#351b31";ctx.fillRect(0,0,23,505);ctx.fillRect(677,0,23,505);
 ctx.strokeStyle="#854d6d";ctx.lineWidth=4;
 for(const x of [5,17,683,695]){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,505);ctx.stroke()}
 ctx.fillStyle="#11121c";ctx.fillRect(0,490,WORLD_W,14);
 ctx.fillStyle="#402b40";ctx.beginPath();ctx.moveTo(0,520);ctx.lineTo(WORLD_W,520);ctx.lineTo(WORLD_W,WORLD_H);ctx.lineTo(0,WORLD_H);ctx.closePath();ctx.fill();
 ctx.strokeStyle="#a6666955";ctx.lineWidth=3;
 for(let y=545;y<WORLD_H;y+=47){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(WORLD_W,y);ctx.stroke()}
 ctx.fillStyle="#7b394b";ctx.beginPath();ctx.moveTo(270,510);ctx.lineTo(430,510);ctx.lineTo(490,780);ctx.lineTo(210,780);ctx.closePath();ctx.fill();
 ctx.strokeStyle="#d7a26b6b";ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(270,515);ctx.lineTo(210,780);ctx.moveTo(430,515);ctx.lineTo(490,780);ctx.stroke();
 // Projector beam and wall sconces outside of the embedded player.
 for(const x of [42,657]){
  ctx.fillStyle="#e7a95b";ctx.shadowColor="#ffba6d";ctx.shadowBlur=15;
  ctx.beginPath();ctx.arc(x,483,8,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
 }
 // Seat backs on the cinema floor (screen remains unobstructed).
 for(const [x,y,w] of [[260,540,56],[328,540,56],[398,540,56],[262,620,64],[346,620,64],[438,620,64]]){
  ctx.fillStyle="#101620";ctx.beginPath();ctx.ellipse(x,y+42,w*.53,13,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#663344";ctx.strokeStyle="#b06780";ctx.lineWidth=3;
  ctx.beginPath();ctx.roundRect(x-w/2,y,w,50,14);ctx.fill();ctx.stroke();
 }
 ctx.fillStyle="#f3d4df";ctx.font="800 9px sans-serif";ctx.textAlign="center";
 for(const s of LOUNGE_SEATS.filter(s=>s.scene==="theatre"))ctx.fillText("SIT",s.x,s.y+4);
 // The real clickable video layer is mounted above, not drawn into the canvas.
 ctx.fillStyle="#0e1420";ctx.beginPath();ctx.roundRect(18,70,664,388,12);ctx.fill();
 ctx.strokeStyle="#7f93a6";ctx.lineWidth=5;ctx.stroke();
 drawTheatreExit();drawTheatrePanel();
}
function drawTheatreExit(){
 const d=THEATRE_EXIT;
 ctx.fillStyle="#5c5769";ctx.strokeStyle="#c2b3c7";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(d.x,d.y,d.w,d.h,12);ctx.fill();ctx.stroke();
 ctx.fillStyle="#171828";ctx.beginPath();ctx.roundRect(d.x+10,d.y+12,d.w-20,d.h-22,9);ctx.fill();
 ctx.fillStyle="#9dcfe6";ctx.textAlign="center";ctx.font="900 17px sans-serif";
 ctx.fillText("EXIT",d.x+d.w/2,d.y+55);
 ctx.font="800 13px sans-serif";ctx.fillText("TO LOBBY",d.x+d.w/2,d.y+83);
 ctx.fillStyle="#ffd5a3";ctx.beginPath();ctx.arc(d.x+d.w-20,d.y+102,5,0,Math.PI*2);ctx.fill();
}
function drawTheatrePanel(){
 const d=THEATRE_PANEL;
 ctx.fillStyle="#2d3b4c";ctx.strokeStyle="#89a5ba";ctx.lineWidth=4;
 ctx.beginPath();ctx.roundRect(d.x,d.y,d.w,d.h,13);ctx.fill();ctx.stroke();
 ctx.fillStyle="#101c28";ctx.beginPath();ctx.roundRect(d.x+10,d.y+10,d.w-20,d.h-20,9);ctx.fill();
 ctx.fillStyle="#8be8ab";ctx.beginPath();ctx.arc(d.x+29,d.y+30,6,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#eaf5ff";ctx.font="900 12px sans-serif";ctx.textAlign="center";
 ctx.fillText("VIDEO",d.x+d.w/2,d.y+60);ctx.fillText("CONTROLS",d.x+d.w/2,d.y+76);
 ctx.fillStyle="#bad8e9";ctx.font="800 10px sans-serif";ctx.fillText("TAP PANEL",d.x+d.w/2,d.y+100);
}
// Media Master: a cinematic corridor. The three screens are future destinations;
// marquee lettering and poster artwork are intentionally placeholders.
// Auditorium bays are spaced along a horizontally explorable cinema hallway.
const MEDIA_SCREEN_ENTRIES=[{x:430,id:1,accent:"#f1b25c"},{x:1035,id:2,accent:"#d783a7"},{x:1640,id:3,accent:"#7ac8cc"}];
function drawMediaPoster(c,x,y,seed){
 const w=53,h=147;
 c.fillStyle="#080b12";c.beginPath();c.roundRect(x-5,y-7,w+10,h+14,5);c.fill();
 c.strokeStyle="#c8a574";c.lineWidth=3;c.stroke();
 const hue=["#304f74","#673a65","#2b635e","#764a3b","#323859","#476641"][seed%6];
 c.fillStyle=hue;c.fillRect(x,y,w,h);
 c.save();c.beginPath();c.rect(x,y,w,h);c.clip();
 const pg=c.createLinearGradient(x,y,x+w,y+h);pg.addColorStop(0,"#ffffff20");pg.addColorStop(1,"#040b23df");
 c.fillStyle=pg;c.fillRect(x,y,w,h);
 // Six pieces of self-contained placeholder movie art.
 c.fillStyle=["#ffd18e","#f3acc8","#89e3d9","#e1a98b","#b0befe","#c9eaa4"][seed%6];
 c.beginPath();c.arc(x+26+(seed%3-1)*5,y+43,16+seed%5,0,Math.PI*2);c.fill();
 c.fillStyle="#0c1929b0";c.beginPath();c.moveTo(x-8,y+110);
 c.lineTo(x+13,y+65+(seed%3)*7);c.lineTo(x+35,y+101);c.lineTo(x+61,y+63);c.lineTo(x+61,y+h);c.lineTo(x-8,y+h);c.fill();
 c.fillStyle="#eff0e7";c.textAlign="center";c.font="900 8px system-ui,sans-serif";
 c.fillText("PREVIEW",x+26,y+125);c.fillText("SOON",x+26,y+135);
 c.restore();
 c.strokeStyle="#e0c996";c.lineWidth=1;c.strokeRect(x+2,y+2,w-4,h-4);
}
function drawMediaMarquee(c,x,y,w,h,index,t){
 c.fillStyle="#070c13";c.beginPath();c.roundRect(x-5,y-5,w+10,h+10,6);c.fill();
 c.strokeStyle="#bfa477";c.lineWidth=3;c.stroke();
 c.fillStyle="#101a1c";c.fillRect(x,y,w,h);
 c.save();c.beginPath();c.rect(x+4,y+3,w-8,h-6);c.clip();
 c.font="900 13px ui-monospace,monospace";
 c.textAlign="left";c.fillStyle="#ffc879";c.shadowColor="#eeb765";c.shadowBlur=5;
 const words=["SCREEN 1   *   COMING SOON   *   FEATURE TBA   *   ",
              "SCREEN 2   *   SHOWTIMES TBA   *   COMING SOON   *   ",
              "SCREEN 3   *   FEATURE TBA   *   COMING SOON   *   "][index];
 const width=c.measureText(words).width,step=Math.max(width,1),offset=(t*(29+index*4)/1000)%step;
 for(let xx=x+6-offset;xx<x+w+step;xx+=step)c.fillText(words,xx,y+19);
 c.restore();
}
function drawMediaInterior(){
 const c=ctx,t=performance.now(),w=MEDIA_WORLD_W;
 c.save();
 // Continuous theatre hallway: burgundy panels, brass trim and ceiling lights.
 const back=c.createLinearGradient(0,0,0,460);
 back.addColorStop(0,"#101421");back.addColorStop(.49,"#3b2234");back.addColorStop(1,"#221e2c");
 c.fillStyle=back;c.fillRect(0,0,w,780);
 c.fillStyle="#080c14";c.fillRect(0,0,w,102);
 c.fillStyle="#bd9865";c.fillRect(0,97,w,5);
 c.fillStyle="#e7c98b";c.textAlign="center";c.font="1000 34px system-ui,sans-serif";
 c.shadowColor="#df9e62";c.shadowBlur=16;c.fillText("MEDIA MASTER",350,68);c.shadowBlur=0;
 // Repeating architectural ribs and sconces extend down the full hallway.
 for(let x=50;x<w;x+=125){
  c.fillStyle="#a67a552a";c.fillRect(x,116,4,276);
  c.fillStyle="#fbd59d";c.shadowColor="#f9ba6c";c.shadowBlur=9;
  c.beginPath();c.arc(x+2,148,3.5,0,Math.PI*2);c.fill();c.shadowBlur=0;
 }
 c.fillStyle="#7d5a57";c.fillRect(0,392,w,9);
 const carpet=c.createLinearGradient(0,402,0,780);
 carpet.addColorStop(0,"#4a222e");carpet.addColorStop(1,"#260e22");
 c.fillStyle=carpet;c.fillRect(0,400,w,380);
 // Twin brass carpet border strips, without a distracting tile grid.
 c.fillStyle="#b6956680";c.fillRect(0,403,w,4);
 c.fillStyle="#c69d6f50";c.fillRect(0,771,w,3);
 for(let y=421;y<780;y+=66){
  c.fillStyle="#cc9b5a1d";
  for(let x=Math.max(30,Math.floor((mediaCameraX-60)/76)*76);x<Math.min(w,mediaCameraX+WORLD_W+140);x+=76){
   c.beginPath();c.moveTo(x,y);c.lineTo(x+8,y+8);c.lineTo(x,y+16);c.lineTo(x-8,y+8);c.closePath();c.fill();
  }
 }
 for(let i=0;i<MEDIA_SCREEN_ENTRIES.length;i++){
  const ent=MEDIA_SCREEN_ENTRIES[i],x=ent.x,dy=204,dw=150,dh=180;
  if(x+dw+100<mediaCameraX||x-100>mediaCameraX+WORLD_W)continue;
  // Each recessed pair of auditorium doors, separated by long sections of wall.
  c.fillStyle="#0c121b";c.beginPath();c.roundRect(x-11,188,dw+22,200,8);c.fill();
  c.strokeStyle="#ac8964";c.lineWidth=5;c.stroke();
  c.fillStyle="#18121e";c.fillRect(x,dy,dw,dh);
  const g=c.createLinearGradient(x,dy,x,dy+dh);
  g.addColorStop(0,"#653640");g.addColorStop(1,"#2b1727");
  c.fillStyle=g;c.fillRect(x+5,dy+5,dw-10,dh-10);
  c.fillStyle="#a16d65";c.fillRect(x+dw/2-2,dy+5,4,dh-11);
  c.strokeStyle="#d5b687";c.lineWidth=2;c.strokeRect(x+5,dy+5,dw-10,dh-10);
  for(const side of [-1,1]){
   c.strokeStyle="#ddc6a2";c.lineWidth=3;c.lineCap="round";
   const hx=x+dw/2+side*13;
   c.beginPath();c.moveTo(hx,dy+95);c.lineTo(hx,dy+121);c.stroke();
  }
  c.fillStyle="#e3b46b";c.fillRect(x-13,dy+dh-4,dw+26,5);
  // Posters sit on either side of the doors, not in front of the panels.
  drawMediaPoster(c,x-88,220,i*2);
  drawMediaPoster(c,x+dw+34,220,i*2+1);
  drawMediaMarquee(c,x-2,145,dw+4,29,i,t);
 }
 // Decorative sconces between auditorium bays for depth in the long passage.
 for(const x of [345,790,946,1400,1544,1990]){
  if(x<mediaCameraX-80||x>mediaCameraX+WORLD_W+80)continue;
  c.fillStyle="#fbd495";c.shadowColor="#f4bb69";c.shadowBlur=16;
  c.beginPath();c.ellipse(x,340,5,15,0,0,Math.PI*2);c.fill();c.shadowBlur=0;
 }
 // The doorway back to the mall stays near the corridor's starting point.
 const ex=MEDIA_EXIT;
 c.fillStyle="#121720";c.beginPath();c.roundRect(ex.x-6,ex.y-8,ex.w+12,ex.h+12,9);c.fill();
 const light=c.createLinearGradient(0,ex.y,0,ex.y+ex.h);
 light.addColorStop(0,"#4a5e70");light.addColorStop(1,"#cab186");
 c.fillStyle=light;c.fillRect(ex.x+5,ex.y+5,ex.w-10,ex.h-10);
 c.fillStyle="#fff1c81c";c.beginPath();c.moveTo(ex.x+23,ex.y+8);
 c.lineTo(ex.x+46,ex.y+8);c.lineTo(ex.x+110,ex.y+ex.h-3);c.lineTo(ex.x+80,ex.y+ex.h-3);c.fill();
 c.strokeStyle="#b89c74";c.lineWidth=7;
 c.beginPath();c.moveTo(ex.x,ex.y+ex.h);c.lineTo(ex.x,ex.y+6);
 c.quadraticCurveTo(ex.x,ex.y,ex.x+6,ex.y);c.lineTo(ex.x+ex.w-6,ex.y);
 c.quadraticCurveTo(ex.x+ex.w,ex.y,ex.x+ex.w,ex.y+6);
 c.lineTo(ex.x+ex.w,ex.y+ex.h);c.stroke();
 const beam=c.createLinearGradient(0,ex.y+ex.h-25,0,780);
 beam.addColorStop(0,"#f1dca430");beam.addColorStop(1,"#f1dca400");
 c.fillStyle=beam;c.beginPath();c.moveTo(ex.x+34,ex.y+ex.h-7);
 c.lineTo(ex.x+ex.w-34,ex.y+ex.h-7);c.lineTo(ex.x+ex.w+12,780);
 c.lineTo(ex.x-12,780);c.fill();
 // Finish the passage with a dark end wall, no additional interaction yet.
 c.fillStyle="#1a1222";c.fillRect(w-28,103,28,677);
 c.fillStyle="#bb9569";c.fillRect(w-28,103,5,677);
 c.restore();
}
function drawLooksInterior(){
 const c=ctx;
 c.save();
 const bg=c.createLinearGradient(0,0,0,490);
 bg.addColorStop(0,"#101320");bg.addColorStop(.67,"#252135");bg.addColorStop(1,"#3d354a");
 c.fillStyle=bg;c.fillRect(0,0,700,780);
 // Dark fashion store soffit, violet light bars and neon header.
 c.fillStyle="#090d17";c.fillRect(0,0,700,109);
 for(let x=30;x<700;x+=105){c.fillStyle="#b9f5f022";c.fillRect(x,14,62,10)}
 c.fillStyle="#e6c5fa";c.textAlign="center";c.font="1000 38px system-ui,sans-serif";
 c.shadowColor="#aa58d7";c.shadowBlur=22;c.fillText("LOOKS MAX INC.",350,71);c.shadowBlur=0;
 c.fillStyle="#7b4cb1";c.fillRect(65,97,570,4);
 // Back-wall painted poster panels and contrasting masonry.
 for(let x=0;x<700;x+=60){c.fillStyle=x%120?"#342e43":"#2b283b";c.fillRect(x,112,59,286)}
 c.strokeStyle="#4c385b";c.lineWidth=8;c.strokeRect(0,105,700,290);
 // Mirrors are physically separated with illuminated frames.
 LOOKS_MIRRORS.forEach((m,i)=>{
   c.fillStyle="#101723";c.beginPath();c.roundRect(m.x-9,m.y-9,m.w+18,m.h+18,13);c.fill();
   c.strokeStyle=i===1?"#d69af7":"#79e4dd";c.lineWidth=5;c.stroke();
   const mirror=c.createLinearGradient(m.x,m.y,m.x+m.w,m.y+m.h);
   mirror.addColorStop(0,"#bdc7d4");mirror.addColorStop(.5,"#557a91");mirror.addColorStop(1,"#263b59");
   c.fillStyle=mirror;c.beginPath();c.roundRect(m.x,m.y,m.w,m.h,8);c.fill();
   c.fillStyle="#e7fbff29";c.beginPath();c.moveTo(m.x+12,m.y+9);c.lineTo(m.x+42,m.y+9);
   c.lineTo(m.x+92,m.y+m.h-9);c.lineTo(m.x+67,m.y+m.h-9);c.closePath();c.fill();
   c.fillStyle="#ffffff42";c.fillRect(m.x+m.w-17,m.y+12,3,m.h-24);
   c.fillStyle="#bb95d1";c.fillRect(m.x-6,m.y+m.h+9,m.w+12,8);
 });
 // Merchandise racks on either side, plus skateboard wall display.
 for(const side of [0,1]){
   const rackX=side?584:16;
   c.fillStyle="#131b26";c.fillRect(rackX,424,101,129);
   c.strokeStyle="#93a4ac";c.lineWidth=4;c.strokeRect(rackX,424,101,129);
   c.strokeStyle="#cad1d9";c.beginPath();c.moveTo(rackX+9,447);c.lineTo(rackX+91,447);c.stroke();
   for(let j=0;j<5;j++){
     const cx=rackX+15+j*17;
     c.fillStyle=["#985bbb","#b7d3d5","#c16a93","#668aaa","#d4ac69"][j];
     c.beginPath();c.moveTo(cx-7,458);c.lineTo(cx-11,468);c.lineTo(cx-5,477);
     c.lineTo(cx-5,518);c.lineTo(cx+6,518);c.lineTo(cx+6,477);c.lineTo(cx+11,468);c.lineTo(cx+7,458);c.closePath();c.fill();
   }
 }
 for(let i=0;i<4;i++){
  const x=66+i*26; c.save();c.translate(x,135);c.rotate((i-1.5)*.1);
  c.fillStyle=["#9b64d8","#e5af6c","#6fd4ca","#d77698"][i];
  c.beginPath();c.roundRect(-8,-28,16,56,8);c.fill();
  c.fillStyle="#f9fbff";c.beginPath();c.arc(0,-18,3,0,Math.PI*2);c.arc(0,18,3,0,Math.PI*2);c.fill();c.restore();
 }
 // Polished checkerboard/stone floor and central display table.
 const floor=c.createLinearGradient(0,395,0,780);
 floor.addColorStop(0,"#474656");floor.addColorStop(1,"#292c3b");
 c.fillStyle=floor;c.fillRect(0,396,700,384);
 for(let y=398;y<780;y+=62)for(let x=0;x<700;x+=62){
  c.fillStyle=((x+y)/62|0)%2?"#ffffff06":"#060c1d15";c.fillRect(x,y,62,62);
 }
 c.fillStyle="#ae77bd33";c.beginPath();c.ellipse(350,572,165,66,0,0,Math.PI*2);c.fill();
 c.fillStyle="#161f2a";c.beginPath();c.roundRect(295,445,110,66,11);c.fill();
 c.fillStyle="#7fe3e0";c.fillRect(305,445,90,5);
 c.fillStyle="#9663a7";c.fillRect(306,451,88,12);
 c.fillStyle="#3f5670";c.fillRect(304,511,9,39);c.fillRect(386,511,9,39);
 // Foreground streetwear rails and sneaker shelving sit above the floor plane.
 for(const side of [0,1]){
   const rx=side?576:13;
   c.fillStyle="#0e1826";c.beginPath();c.roundRect(rx,431,111,125,8);c.fill();
   c.strokeStyle="#a179c5";c.lineWidth=3;c.stroke();
   c.fillStyle="#718395";c.fillRect(rx+11,447,89,5);
   for(let j=0;j<5;j++){
     const sx=rx+14+j*18;
     c.fillStyle=["#a965bd","#4b9a9f","#d7a16d","#aa557f","#b8c4cb"][j];
     c.beginPath();c.moveTo(sx-6,461);c.lineTo(sx-11,474);
     c.lineTo(sx-6,479);c.lineTo(sx-5,520);c.lineTo(sx+7,520);
     c.lineTo(sx+8,479);c.lineTo(sx+13,474);c.lineTo(sx+7,461);c.closePath();c.fill();
   }
   c.strokeStyle="#7e90a0";c.lineWidth=3;c.beginPath();
   c.moveTo(rx+9,541);c.lineTo(rx+102,541);c.stroke();
 }
 // Flat skate decks and small sneaker display, visually non-interactive.
 for(let j=0;j<3;j++){
   const x=526+j*28;
   c.save();c.translate(x,124+j%2*9);c.rotate(.13*(j-1));
   c.fillStyle=["#a870c7","#79c4bf","#d78eac"][j];
   c.beginPath();c.roundRect(-9,-25,18,51,8);c.fill();
   c.fillStyle="#172637";c.fillRect(-3,-18,6,36);c.restore();
 }
 // Exit: a simple open doorframe, softly lit from the mall beyond.
 // No door leaves, handles or instructional text.
 const exitX=270,exitY=676,exitW=160,exitH=90;
 c.fillStyle="#101521";c.beginPath();c.roundRect(exitX-6,exitY-6,exitW+12,exitH+9,9);c.fill();
 const passage=c.createLinearGradient(0,exitY,0,exitY+exitH);
 passage.addColorStop(0,"#546c76");passage.addColorStop(.58,"#85858d");
 passage.addColorStop(1,"#baa98b");
 c.fillStyle=passage;c.fillRect(exitX+7,exitY+7,exitW-14,exitH-11);
 c.fillStyle="#f7e4bd18";c.beginPath();c.moveTo(311,exitY+8);
 c.lineTo(339,exitY+8);c.lineTo(386,exitY+exitH-4);
 c.lineTo(366,exitY+exitH-4);c.closePath();c.fill();
 // Restrained warm light spread on the nearby floor.
 const light=c.createLinearGradient(0,exitY+exitH-15,0,780);
 light.addColorStop(0,"#f7deb136");light.addColorStop(1,"#f7deb100");
 c.fillStyle=light;c.beginPath();c.moveTo(303,exitY+exitH-6);
 c.lineTo(397,exitY+exitH-6);c.lineTo(417,780);
 c.lineTo(283,780);c.closePath();c.fill();
 // Outer jambs and header remain solid and visibly framed.
 c.strokeStyle="#a286b9";c.lineWidth=6;c.beginPath();
 c.moveTo(exitX,exitY+exitH);c.lineTo(exitX,exitY+5);
 c.quadraticCurveTo(exitX,exitY,exitX+5,exitY);
 c.lineTo(exitX+exitW-5,exitY);
 c.quadraticCurveTo(exitX+exitW,exitY,exitX+exitW,exitY+5);
 c.lineTo(exitX+exitW,exitY+exitH);c.stroke();
 c.strokeStyle="#e2cfef";c.lineWidth=1.5;c.beginPath();
 c.moveTo(exitX+5,exitY+exitH-3);c.lineTo(exitX+5,exitY+8);
 c.lineTo(exitX+exitW-5,exitY+8);c.lineTo(exitX+exitW-5,exitY+exitH-3);c.stroke();
 const mat=c.createLinearGradient(0,763,0,780);
 mat.addColorStop(0,"#32273e");mat.addColorStop(1,"#1a1322");
 c.fillStyle=mat;c.beginPath();c.roundRect(289,768,122,12,4);c.fill();
 c.fillStyle="#9270af";c.fillRect(301,771,98,1.5);
 c.restore();
}
// Walkable 1700-unit arcade with a distinct enclosed central lounge.
// Cabinet screens animate, but gameplay on the floor machines is future content.
function drawArtifactCabinet(c,x,y,i,lower=false){
 const colors=["#ad78ff","#65d8d0","#e7a36c","#fd84b8","#90b2ff"];
 const col=colors[i%colors.length];
 c.save();c.translate(x,y);
 // Cabinet footprint and pronounced cabinet silhouette.
 c.fillStyle="#070b16aa";c.beginPath();c.ellipse(0,90,44,11,0,0,Math.PI*2);c.fill();
 c.fillStyle="#101327";c.beginPath();c.moveTo(-39,-59);c.lineTo(38,-59);
 c.lineTo(35,89);c.lineTo(-34,89);c.closePath();c.fill();
 c.strokeStyle=col;c.lineWidth=3;c.stroke();
 c.fillStyle="#263052";c.fillRect(-32,-51,64,24);
 c.fillStyle="#e9e8fc";c.font="900 10px system-ui,sans-serif";
 c.textAlign="center";c.fillText(["STAR RUN","LEVEL UP","GALAXY","RALLY X","TETRA"][i%5],0,-34);
 c.shadowColor=col;c.shadowBlur=13;c.fillStyle=col;c.fillRect(-28,-23,56,48);c.shadowBlur=0;
 c.fillStyle="#0c1730";c.fillRect(-24,-19,48,40);
 // Animated star/track pattern on cabinet CRT; gentle motion, no heavy particle loops.
 const t=performance.now()/850+i*2;
 c.fillStyle=col;
 if(i%3===0){
  c.fillRect(-9+Math.sin(t)*9,-7,18,4);
  c.fillRect(-2,1+Math.cos(t)*9,4,12);
 }else if(i%3===1){
  c.beginPath();c.arc(Math.sin(t)*12,Math.cos(t)*9,6,0,Math.PI*2);c.fill();
  c.fillStyle="#f4ebff";c.fillRect(-17,8,5,5);
 }else{
  for(let q=0;q<3;q++)c.fillRect(-19+q*16,4+Math.sin(t+q)*8,10,6);
 }
 c.fillStyle="#28324c";c.beginPath();c.moveTo(-28,29);c.lineTo(28,29);
 c.lineTo(32,48);c.lineTo(-32,48);c.closePath();c.fill();
 c.fillStyle="#f6dc87";c.beginPath();c.arc(-13,35,4,0,Math.PI*2);c.fill();
 c.fillStyle=col;c.beginPath();c.arc(14,38,3,0,Math.PI*2);c.fill();
 c.fillStyle="#0e1427";c.fillRect(-26,52,52,30);
 c.fillStyle="#b6c4d8";c.fillRect(-24,76,48,4);
 c.restore();
}
function drawArtifactSofa(c,cx,y,i){
 c.save();c.translate(cx,y);
 c.fillStyle="#00000055";c.beginPath();c.ellipse(0,34,66,17,0,0,Math.PI*2);c.fill();
 const upholstery=["#66557e","#426d72","#805b72"][i%3];
 c.fillStyle="#111524";c.beginPath();c.roundRect(-64,-40,128,78,13);c.fill();
 c.fillStyle=upholstery;c.beginPath();c.roundRect(-58,-35,116,52,10);c.fill();
 c.fillStyle="#9e8bab";c.fillRect(-54,-32,108,5);
 for(const tx of [-47,2]){
  c.fillStyle="#a28cae";c.beginPath();c.roundRect(tx,-24,45,34,7);c.fill();
  c.fillStyle="#695c80";c.beginPath();c.roundRect(tx+3,-22,39,26,5);c.fill();
 }
 c.fillStyle="#26263e";c.beginPath();c.roundRect(-58,9,116,18,6);c.fill();
 c.fillStyle="#947ba1";c.fillRect(-56,9,112,4);
 c.fillStyle="#171d2c";c.fillRect(-49,27,10,11);c.fillRect(39,27,10,11);
 c.restore();
}
function drawArtifactInterior(){
 const c=ctx,w=ARTIFACT_WORLD_W,cam=artifactCameraX;
 c.save();
 const back=c.createLinearGradient(0,0,0,780);
 back.addColorStop(0,"#0c1022");back.addColorStop(.44,"#24263f");back.addColorStop(1,"#181b2e");
 c.fillStyle=back;c.fillRect(0,0,w,780);
 // Header and ornamental arcade lighting continue the whole width.
 c.fillStyle="#070b18";c.fillRect(0,0,w,99);
 c.fillStyle="#9e7edd";c.fillRect(0,96,w,4);
 for(let x=72;x<w;x+=154){
  c.fillStyle="#413859";c.fillRect(x,13,112,9);
  c.fillStyle="#83eddf";c.shadowColor="#64d4d2";c.shadowBlur=13;
  c.fillRect(x+7,15,98,4);c.shadowBlur=0;
 }
 c.fillStyle="#e5d5ff";c.textAlign="center";c.font="1000 31px system-ui,sans-serif";
 c.shadowColor="#9c65e5";c.shadowBlur=13;c.fillText("THE ARTIFACT",850,59);c.shadowBlur=0;
 c.fillStyle="#83e3d2";c.font="800 12px system-ui,sans-serif";
 c.fillText("ARCADE  •  LOUNGE",850,78);
 // Backwall brickwork is visible between arcade cabinets.
 for(let y=110;y<349;y+=30){
  c.strokeStyle="#ffffff08";c.lineWidth=1;
  c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke();
  for(let x=(Math.floor(cam/95)*95)+((Math.floor(y/30)%2)*45);x<cam+WORLD_W+160;x+=95){
   c.beginPath();c.moveTo(x,y);c.lineTo(x,y+30);c.stroke();
  }
 }
 c.fillStyle="#996ec0";c.fillRect(0,337,w,5);
 // Polished floor, decorative light-strip checker pattern.
 const floor=c.createLinearGradient(0,349,0,780);
 floor.addColorStop(0,"#3a3953");floor.addColorStop(1,"#232537");
 c.fillStyle=floor;c.fillRect(0,349,w,431);
 for(let y=355;y<780;y+=70){
  for(let x=Math.floor(cam/70)*70;x<Math.min(w,cam+WORLD_W+140);x+=70){
   c.fillStyle=((x/70+y/70)&1)?"#ffffff07":"#05081c1b";
   c.fillRect(x,y,70,70);
  }
 }
 c.fillStyle="#c4a4ea38";c.fillRect(0,349,w,4);
 c.fillStyle="#85e2d328";c.fillRect(0,766,w,3);
 // Perimeter arcade machines along the back and lower walls, away from the lounge doorway.
 for(let i=0;i<ARTIFACT_MACHINE_XS.length;i++){
  const x=ARTIFACT_MACHINE_XS[i];if(x<cam-65||x>cam+WORLD_W+65)continue;
  drawArtifactCabinet(c,x,222,i);
 }
 for(let i=0;i<8;i++){
  const x=i<4?155+i*114:1203+(i-4)*114;
  if(x<cam-65||x>cam+WORLD_W+65)continue;
  // Small side-row of cabinets backed into the lower arcade wall.
  c.fillStyle="#101326";c.fillRect(x-43,556,86,111);
  c.fillStyle=["#d28cfa","#7bdace","#f2c38e","#80b0e8"][i%4];
  c.fillRect(x-33,566,66,8);
  c.fillStyle="#28304d";c.fillRect(x-31,586,62,50);
  c.fillStyle="#151b32";c.fillRect(x-26,591,52,39);
  c.fillStyle=["#ab83e4","#70e5d0","#f2a963","#8dbdff"][i%4];
  c.beginPath();c.arc(x+Math.sin(performance.now()/950+i)*8,608,7,0,Math.PI*2);c.fill();
  c.fillStyle="#a8b3cd";c.fillRect(x-23,644,46,3);
  c.strokeStyle="#767ca9";c.lineWidth=3;c.strokeRect(x-43,556,86,111);
 }
 // Separate the lounge as its own central ROOM with glass partition walls.
 const lx=ARTIFACT_LOUNGE.x,ly=ARTIFACT_LOUNGE.y,lw=ARTIFACT_LOUNGE.w,lh=ARTIFACT_LOUNGE.h;
 c.fillStyle="#151629";c.beginPath();c.roundRect(lx,ly,lw,lh,13);c.fill();
 const rug=c.createLinearGradient(0,ly,0,ly+lh);
 rug.addColorStop(0,"#3d3057");rug.addColorStop(1,"#2b243e");
 c.fillStyle=rug;c.beginPath();c.roundRect(lx+13,ly+14,lw-26,lh-27,8);c.fill();
 c.strokeStyle="#9976c1";c.lineWidth=4;c.strokeRect(lx+15,ly+15,lw-30,lh-30);
 // Staggered inset carpet pattern.
 for(let yy=ly+35;yy<ly+lh-15;yy+=31){
  c.fillStyle="#b492ca18";
  for(let xx=lx+31;xx<lx+lw-20;xx+=42){
   c.beginPath();c.moveTo(xx,yy);c.lineTo(xx+7,yy+7);c.lineTo(xx,yy+14);c.lineTo(xx-7,yy+7);c.closePath();c.fill();
  }
 }
 // The back wall and side partitions are waist-high glazed acoustic walls.
 c.fillStyle="#0f1225";c.fillRect(lx,ly-15,lw,29);
 c.strokeStyle="#a48bd6";c.lineWidth=4;c.strokeRect(lx,ly-15,lw,29);
 c.fillStyle="#d6c1ff";c.font="1000 19px system-ui,sans-serif";c.textAlign="center";
 c.fillText("THE LOUNGE",850,ly+7);
 for(const wx of [lx,lx+lw-12]){
  c.fillStyle="#37405d";c.fillRect(wx,ly+14,12,lh-12);
  c.fillStyle="#a9ceea55";c.fillRect(wx+3,ly+25,6,lh-40);
  c.fillStyle="#b5a0e4";c.fillRect(wx,ly+15,12,4);
 }
 // Two glass return walls make the lounge feel enclosed, but leave a wide center entrance.
 for(const [wx,ww] of [[lx,157],[lx+lw-157,157]]){
  c.fillStyle="#161b32";c.fillRect(wx,ly+lh-12,ww,16);
  c.strokeStyle="#ac9bc6";c.lineWidth=3;c.strokeRect(wx,ly+lh-12,ww,16);
 }
 // Three two-person couches + central coffee table. The floor positions
 // of sofa seats are synchronized with the server and collision geometry.
 for(let i=0;i<ARTIFACT_SOFA_CENTERS.length;i++)drawArtifactSofa(c,ARTIFACT_SOFA_CENTERS[i],487,i);
 c.fillStyle="#00000077";c.beginPath();c.ellipse(850,585,66,14,0,0,Math.PI*2);c.fill();
 c.fillStyle="#132331";c.beginPath();c.roundRect(798,552,104,31,10);c.fill();
 c.strokeStyle="#6de0ce";c.lineWidth=3;c.stroke();
 c.fillStyle="#b9d5e0";c.fillRect(820,558,60,3);
 c.fillStyle="#46526e";c.fillRect(812,583,9,18);c.fillRect(878,583,9,18);
 // Bottom entrance/exit back to the mall. The door gap is always accessible.
 const ex=ARTIFACT_EXIT;
 c.fillStyle="#111528";c.beginPath();c.roundRect(ex.x-7,ex.y-5,ex.w+14,ex.h+9,8);c.fill();
 const passage=c.createLinearGradient(0,ex.y,0,ex.y+ex.h);
 passage.addColorStop(0,"#576b82");passage.addColorStop(1,"#b7a6a1");
 c.fillStyle=passage;c.fillRect(ex.x+6,ex.y+5,ex.w-12,ex.h-9);
 c.fillStyle="#ffe0b121";c.beginPath();c.moveTo(ex.x+26,ex.y+8);
 c.lineTo(ex.x+43,ex.y+8);c.lineTo(ex.x+ex.w-29,ex.y+ex.h-5);
 c.lineTo(ex.x+ex.w-58,ex.y+ex.h-5);c.closePath();c.fill();
 c.strokeStyle="#b39ad2";c.lineWidth=6;c.strokeRect(ex.x,ex.y,ex.w,ex.h);
 c.fillStyle="#9d7ac5";c.fillRect(ex.x+6,ex.y+5,ex.w-12,4);
 c.fillStyle="#182338cc";c.beginPath();c.roundRect(ex.x+24,ex.y+22,ex.w-48,24,7);c.fill();
 c.textAlign="center";c.fillStyle="#f6eafa";c.font="900 13px system-ui,sans-serif";
 c.fillText("MALL",ex.x+ex.w/2,ex.y+39);
 // Decorative left and right end rails, to visually bound the large scene.
 for(const xx of [10,w-21]){
  c.fillStyle="#10172a";c.fillRect(xx,101,11,679);
  c.fillStyle="#a078cd";c.fillRect(xx+3,101,3,679);
 }
 c.restore();
}
function drawWorld(){
 ctx.clearRect(0,0,WORLD_W,WORLD_H);
 ambientTick=(ambientTick+1)%100000;
 const mallScene=currentScene()==="mall"&&isMallAtrium();
 if(mallScene){ctx.save();ctx.translate(-Math.round(mallCameraX),0);drawMallCorridor();}
 if(currentScene()==="looks")drawLooksInterior();
 const artifactScene=currentScene()==="artifact"&&isMallAtrium();
 if(artifactScene){ctx.save();ctx.translate(-Math.round(artifactCameraX),0);drawArtifactInterior();}
 const mediaScene=currentScene()==="media"&&isMallAtrium();
 if(mediaScene){ctx.save();ctx.translate(-Math.round(mediaCameraX),0);drawMediaInterior();}

 if(currentScene()==="lobby"){
  if(isMallAtrium()){
   drawMallAtrium();
  }else if(isPublicRoomCode(roomCode)){
   drawVibeBackdrop();
   drawVibeFurniture();
  }else{
   drawRoomBackdrop();
   drawWindow();
   drawStringLights();
   drawWallDecor();
   drawLoungeFurniture();
  }
  if(!isMallAtrium())drawFridge();
 }

 if(currentScene()==="theatre"){
   drawTheatreBackdrop();
 }else if(!isMallAtrium()){
   drawTheatreDoor();
   drawActivityTable();
   drawWardrobe();
 }

 if(state){
   const sorted=state.players.filter(p=>(p.scene||"lobby")===currentScene()).sort((a,b)=>a.y-b.y);
   for(const p of sorted)drawPlayer(p);
 }
 if(mallScene||mediaScene||artifactScene)ctx.restore();
}
function bodyStyleFor(p){
 const c=bodyColors.find(x=>x.id===p.color)||bodyColors[0];
 const shape=p.shape||"pill";
 if(shape==="round")return{w:50,h:50,r:25,color:c.color};
 if(shape==="tall")return{w:38,h:74,r:20,color:c.color};
 if(shape==="squat")return{w:56,h:48,r:20,color:c.color};
 if(shape==="square")return{w:52,h:58,r:9,color:c.color};
 if(shape==="mini")return{w:38,h:48,r:17,color:c.color};
 return{w:44,h:62,r:22,color:c.color};
}

function drawHatTo(c,style,w,h){
 if(!style)return;
 c.save();
 const top=-h/2;
 switch(style){
  case "cap":
   c.fillStyle="#2a5d9f";
   c.beginPath();c.arc(0,top+2,w*.34,Math.PI,0);c.fill();
   c.fillRect(-w*.22,top+1,w*.44,7);
   c.fillStyle="#183c6b";c.fillRect(6,top+5,18,5);
   break;

  case "crown":
   c.fillStyle="#ffd45f";c.strokeStyle="#a86b10";c.lineWidth=2;
   c.beginPath();
   c.moveTo(-18,top+5);c.lineTo(-14,top-12);c.lineTo(-5,top-2);
   c.lineTo(0,top-16);c.lineTo(8,top-2);c.lineTo(17,top-12);
   c.lineTo(18,top+5);c.closePath();c.fill();c.stroke();
   c.fillStyle="#ef5f67";
   for(const x of[-9,0,9]){c.beginPath();c.arc(x,top-3,2.5,0,Math.PI*2);c.fill()}
   break;

  case "cowboy":
   c.fillStyle="#8a5b35";
   c.beginPath();c.ellipse(0,top+3,25,7,0,0,Math.PI*2);c.fill();
   c.fillStyle="#9b6940";
   c.beginPath();c.roundRect(-13,top-14,26,18,7);c.fill();
   c.strokeStyle="#4d301e";c.lineWidth=2;
   c.beginPath();c.moveTo(-12,top-1);c.lineTo(12,top-1);c.stroke();
   break;

  case "wizard":
   c.fillStyle="#6b4ba8";
   c.beginPath();c.moveTo(-18,top+5);c.lineTo(4,top-30);c.lineTo(17,top+5);c.closePath();c.fill();
   c.fillStyle="#3b2b67";c.fillRect(-20,top+2,40,6);
   c.fillStyle="#ffe27a";
   c.beginPath();c.arc(2,top-12,3,0,Math.PI*2);c.fill();
   break;

  case "halo":
   c.strokeStyle="#ffeaa5";c.lineWidth=4;
   c.shadowBlur=8;c.shadowColor="#ffeaa5";
   c.beginPath();c.ellipse(0,top-13,18,6,0,0,Math.PI*2);c.stroke();
   c.shadowBlur=0;
   break;

  case "party":
   c.fillStyle="#f05d8c";
   c.beginPath();c.moveTo(-13,top+4);c.lineTo(0,top-25);c.lineTo(13,top+4);c.closePath();c.fill();
   c.fillStyle="#6bd7ff";c.beginPath();c.arc(-4,top-7,3,0,Math.PI*2);c.fill();
   c.fillStyle="#ffd45f";c.beginPath();c.arc(0,top-25,4,0,Math.PI*2);c.fill();
   break;

  case "flower":
   c.fillStyle="#ffd34d";c.beginPath();c.arc(0,top-8,4,0,Math.PI*2);c.fill();
   c.strokeStyle="#ff8eb6";c.lineWidth=5;
   for(let a=0;a<Math.PI*2;a+=Math.PI/3){
    c.beginPath();c.moveTo(Math.cos(a)*4,top-8+Math.sin(a)*4);
    c.lineTo(Math.cos(a)*10,top-8+Math.sin(a)*10);c.stroke()
   }
   break;

  case "antenna":
   c.strokeStyle="#8edcff";c.lineWidth=3;
   c.beginPath();c.moveTo(0,top+2);c.lineTo(0,top-20);c.stroke();
   c.fillStyle="#ff6d86";c.beginPath();c.arc(0,top-23,5,0,Math.PI*2);c.fill();
   break;

  case "mushroom":
   c.fillStyle="#ef6a63";
   c.beginPath();c.ellipse(0,top-2,22,12,0,Math.PI,0);c.fill();
   c.fillStyle="#fff4d6";
   for(const x of[-10,0,11]){c.beginPath();c.arc(x,top-7,3,0,Math.PI*2);c.fill()}
   c.fillStyle="#d7c9ad";c.fillRect(-5,top-2,10,8);
   break;

  case "chef":
   c.fillStyle="#f7f7f3";
   c.beginPath();c.arc(-9,top-8,9,0,Math.PI*2);c.arc(0,top-13,10,0,Math.PI*2);c.arc(10,top-8,9,0,Math.PI*2);c.fill();
   c.fillRect(-15,top-7,30,12);
   c.strokeStyle="#cfd6db";c.lineWidth=1.5;c.strokeRect(-15,top-7,30,12);
   break;

  case "saturn":
   c.fillStyle="#d8a55f";c.beginPath();c.arc(0,top-12,9,0,Math.PI*2);c.fill();
   c.strokeStyle="#c5e0ff";c.lineWidth=3;
   c.beginPath();c.ellipse(0,top-12,18,6,-.25,0,Math.PI*2);c.stroke();
   break;
  case "beanie":
   c.fillStyle="#dc7e91";c.beginPath();c.arc(0,top+3,17,Math.PI,0);c.fill();
   c.fillStyle="#aa465f";c.beginPath();c.roundRect(-18,top-2,36,10,4);c.fill();
   c.fillStyle="#f5bfce";c.beginPath();c.arc(0,top-14,5,0,Math.PI*2);c.fill();break;
  case "top":
   c.fillStyle="#232635";c.beginPath();c.roundRect(-12,top-25,24,29,3);c.fill();
   c.fillRect(-23,top+1,46,6);c.fillStyle="#a5d5ff";c.fillRect(-12,top-4,24,4);break;
  case "horns":
   c.fillStyle="#e1d3bd";
   for(const sign of [-1,1]){c.beginPath();c.moveTo(sign*9,top+6);c.quadraticCurveTo(sign*27,top-15,sign*14,top-22);c.quadraticCurveTo(sign*24,top,sign*18,top+8);c.closePath();c.fill();}break;
  case "bunny":
   for(const x of [-11,11]){
    c.fillStyle="#f5ebe6";c.beginPath();c.ellipse(x,top-15,8,22,x<0?-.12:.12,0,Math.PI*2);c.fill();
    c.fillStyle="#efa4b4";c.beginPath();c.ellipse(x,top-15,3.5,14,0,0,Math.PI*2);c.fill();
   }break;
  case "headphones":
   c.strokeStyle="#263f5a";c.lineWidth=6;c.beginPath();c.arc(0,top+8,20,Math.PI,0);c.stroke();
   c.fillStyle="#5dcaff";c.beginPath();c.roundRect(-22,top+2,8,19,4);c.roundRect(14,top+2,8,19,4);c.fill();break;
 }
 c.restore();
}

function drawMaskTo(c,style,w,h){
 if(!style)return;
 const y=-4;
 c.save();
 switch(style){
  case "bandit":
   c.fillStyle="#242a34";c.beginPath();c.roundRect(-w*.38,y-8,w*.76,18,7);c.fill();
   c.fillStyle="#eaf7ff";c.fillRect(-11,y-2,7,3);c.fillRect(4,y-2,7,3);
   c.strokeStyle="#454f5d";c.lineWidth=2;c.beginPath();c.moveTo(-w*.38,y);c.lineTo(w*.38,y);c.stroke();
   break;

  case "robot":
   c.fillStyle="#687a8d";c.strokeStyle="#b8c9d8";c.lineWidth=2;
   c.beginPath();c.roundRect(-17,y-13,34,27,6);c.fill();c.stroke();
   c.fillStyle="#72e0ff";c.fillRect(-11,y-4,7,5);c.fillRect(4,y-4,7,5);
   c.fillStyle="#29323c";c.fillRect(-8,y+7,16,3);
   break;

  case "shades":
   c.fillStyle="#101820";
   c.beginPath();c.roundRect(-17,y-7,14,10,4);c.roundRect(3,y-7,14,10,4);c.fill();
   c.fillRect(-3,y-4,6,3);
   c.fillStyle="#4cd8ff";c.globalAlpha=.55;c.fillRect(-14,y-5,8,2);c.fillRect(6,y-5,8,2);
   break;

  case "ghost":
   c.fillStyle="#f2f6f7";c.beginPath();c.roundRect(-16,y-14,32,30,13);c.fill();
   c.fillStyle="#222";c.beginPath();c.arc(-7,y-3,3,0,Math.PI*2);c.arc(7,y-3,3,0,Math.PI*2);c.fill();
   c.beginPath();c.arc(0,y+7,4,0,Math.PI);c.strokeStyle="#222";c.lineWidth=2;c.stroke();
   break;

  case "alien":
   c.fillStyle="#8df0a9";c.beginPath();c.ellipse(0,y,18,15,0,0,Math.PI*2);c.fill();
   c.fillStyle="#09110c";c.beginPath();c.ellipse(-7,y-2,4,7,-.3,0,Math.PI*2);c.ellipse(7,y-2,4,7,.3,0,Math.PI*2);c.fill();
   c.strokeStyle="#55b76e";c.lineWidth=2;c.beginPath();c.arc(0,y+6,5,.1*Math.PI,.9*Math.PI);c.stroke();
   break;

  case "skull":
   c.fillStyle="#f3efe4";c.beginPath();c.roundRect(-16,y-14,32,27,10);c.fill();
   c.fillStyle="#202020";c.beginPath();c.arc(-7,y-3,4,0,Math.PI*2);c.arc(7,y-3,4,0,Math.PI*2);c.fill();
   c.fillRect(-4,y+7,8,5);c.fillStyle="#f3efe4";
   for(const x of[-3,1])c.fillRect(x,y+8,2,4);
   break;

  case "frog":
   c.fillStyle="#72d47b";c.beginPath();c.roundRect(-17,y-12,34,25,9);c.fill();
   c.fillStyle="#fff";c.beginPath();c.arc(-9,y-9,6,0,Math.PI*2);c.arc(9,y-9,6,0,Math.PI*2);c.fill();
   c.fillStyle="#1b2b1d";c.beginPath();c.arc(-9,y-9,2.5,0,Math.PI*2);c.arc(9,y-9,2.5,0,Math.PI*2);c.fill();
   break;

  case "cat":
   c.fillStyle="#f0b16d";c.beginPath();c.roundRect(-16,y-12,32,24,8);c.fill();
   c.beginPath();c.moveTo(-14,y-10);c.lineTo(-9,y-23);c.lineTo(-3,y-10);c.fill();
   c.beginPath();c.moveTo(14,y-10);c.lineTo(9,y-23);c.lineTo(3,y-10);c.fill();
   c.fillStyle="#342418";c.beginPath();c.arc(-6,y-3,2,0,Math.PI*2);c.arc(6,y-3,2,0,Math.PI*2);c.fill();
   break;

  case "cyclops":
   c.strokeStyle="#9de8ff";c.lineWidth=4;c.shadowBlur=7;c.shadowColor="#9de8ff";
   c.beginPath();c.arc(0,y-2,9,0,Math.PI*2);c.stroke();c.shadowBlur=0;
   c.fillStyle="#0a1219";c.beginPath();c.arc(0,y-2,3,0,Math.PI*2);c.fill();
   break;

  case "clown":
   c.fillStyle="#f7f0e7";c.beginPath();c.ellipse(0,y,16,14,0,0,Math.PI*2);c.fill();
   c.fillStyle="#ff5b68";c.beginPath();c.arc(0,y,6,0,Math.PI*2);c.fill();
   c.fillStyle="#3b91ff";c.beginPath();c.arc(-7,y-5,2,0,Math.PI*2);c.arc(7,y-5,2,0,Math.PI*2);c.fill();
   break;

  case "visor":
   c.fillStyle="#43e0ff";c.shadowBlur=10;c.shadowColor="#43e0ff";
   c.beginPath();c.roundRect(-18,y-7,36,11,5);c.fill();c.shadowBlur=0;
   c.fillStyle="#d6fbff";c.globalAlpha=.55;c.fillRect(-13,y-5,18,2);
   break;
  case "monocle":
   c.strokeStyle="#f5d18a";c.lineWidth=3;c.beginPath();c.arc(7,y-4,8,0,Math.PI*2);c.stroke();
   c.lineWidth=1.5;c.beginPath();c.moveTo(13,y+1);c.lineTo(17,y+17);c.stroke();break;
  case "pirate":
   c.fillStyle="#17232d";c.beginPath();c.ellipse(-7,y-3,10,8,0,0,Math.PI*2);c.fill();
   c.strokeStyle="#17232d";c.lineWidth=3;c.beginPath();c.moveTo(-18,y-9);c.lineTo(18,y-13);c.stroke();break;
  case "sleepy":
   c.strokeStyle="#203242";c.lineWidth=2.7;c.beginPath();
   c.arc(-7,y-3,5,.15*Math.PI,.85*Math.PI);c.arc(7,y-3,5,.15*Math.PI,.85*Math.PI);c.stroke();break;
  case "heart":
   c.fillStyle="#ed6d94";
   for(const x of [-8,8]){c.beginPath();c.moveTo(x,y+4);c.bezierCurveTo(x-13,y-4,x-7,y-13,x,y-8);c.bezierCurveTo(x+7,y-13,x+13,y-4,x,y+4);c.fill();}
   c.fillStyle="#ffe6ef";c.fillRect(-2,y-7,4,2);break;
  case "goofy":
   c.strokeStyle="#12202c";c.lineWidth=2;c.beginPath();c.arc(0,y+3,12,0,Math.PI);c.stroke();
   c.fillStyle="#ffffff";c.beginPath();c.roundRect(-8,y+3,16,7,3);c.fill();
   c.strokeStyle="#273747";c.beginPath();c.moveTo(0,y+4);c.lineTo(0,y+9);c.stroke();break;
 }
 c.restore();
}

function drawOutfitTo(c,style,w,h,r){
 if(!style)return;
 c.save();c.beginPath();c.roundRect(-w/2,-h/2,w,h,r);c.clip();
 const top=h*.08,bottom=h*.44;
 switch(style){
  case "stripes":
   c.fillStyle="#28476199";
   for(let y=top;y<bottom;y+=9)c.fillRect(-w/2,y,w,4);
   break;
  case "spots":
   c.fillStyle="#fef9e6cc";
   for(let y=top+3;y<bottom;y+=12)for(let x=-w/2+8;x<w/2;x+=15){
    c.beginPath();c.arc(x+(Math.floor(y/12)%2)*5,y,3.6,0,Math.PI*2);c.fill();
   }
   break;
  case "star":
   c.fillStyle="#fff4b3";c.beginPath();
   for(let i=0;i<10;i++){
    const a=i*Math.PI/5-Math.PI/2,R=i%2?6:13,x=Math.cos(a)*R,y=h*.25+Math.sin(a)*R;
    if(i===0)c.moveTo(x,y);else c.lineTo(x,y);
   }c.closePath();c.fill();break;
  case "sash":
   c.fillStyle="#b5486a";c.beginPath();c.moveTo(-w*.5,-h*.10);c.lineTo(-w*.3,-h*.10);
   c.lineTo(w*.38,h*.5);c.lineTo(w*.16,h*.5);c.closePath();c.fill();
   c.fillStyle="#fce5a9";c.beginPath();c.arc(w*.13,h*.26,5,0,Math.PI*2);c.fill();break;
  case "jacket":
   c.fillStyle="#2c496a";c.fillRect(-w/2,h*.10,w,h*.42);
   c.fillStyle="#c7e7ff";c.beginPath();c.moveTo(-w*.12,h*.1);c.lineTo(0,h*.23);c.lineTo(w*.12,h*.1);c.closePath();c.fill();
   c.strokeStyle="#88b8d8";c.lineWidth=2;c.beginPath();c.moveTo(0,h*.24);c.lineTo(0,h*.5);c.stroke();break;
  case "belt":
   c.fillStyle="#604533";c.fillRect(-w/2,h*.20,w,11);
   c.fillStyle="#f5d48b";c.fillRect(-7,h*.21,14,9);
   c.fillStyle="#3a2c26";c.fillRect(-3,h*.24,6,3);break;
 }
 c.restore();
}

// Main-world wrappers.
function drawHat(style,w,h){drawHatTo(ctx,style,w,h)}
function drawMask(style,w,h){drawMaskTo(ctx,style,w,h)}

function drawHeldDrink(p,s){
 const d=DRINKS.find(x=>x.id===p.drink);if(!d)return;
 const x=s.w/2+8,y=s.h*.12;
 ctx.save();ctx.translate(x,y);ctx.rotate(-.16);
 ctx.fillStyle="#d6e6f0";ctx.strokeStyle="#f8fdff";ctx.lineWidth=1.2;
 if(d.kind==="bottle"){
  ctx.fillStyle=d.color;ctx.beginPath();ctx.roundRect(-6,-12,13,23,4);ctx.fill();ctx.stroke();
  ctx.fillRect(-3,-21,7,10);ctx.strokeRect(-3,-21,7,10);
  ctx.fillStyle="#ffffffcc";ctx.fillRect(-6,-9,13,10);
 }else{
  ctx.fillStyle=d.color;ctx.beginPath();ctx.roundRect(-7,-13,15,26,3);ctx.fill();ctx.stroke();
  ctx.fillStyle="#dbe2e5";ctx.fillRect(-6,-13,13,3);
  ctx.fillStyle="#ffffffb5";ctx.fillRect(-6,-9,13,2);
 }
 ctx.fillStyle=d.kind==="bottle"?"#23313b":"#fff";
 ctx.font="900 5px sans-serif";ctx.textAlign="center";
 ctx.fillText(d.short.slice(0,4),0,2,15);
 ctx.restore();
}
// Small vector food/drink props are drawn in the avatar's hand (world canvas),
// not as emojis or HUD overlays. All other clients render the synchronized ID.
function drawHeldMenuItem(p,s){
 const id=p.equippedItem;
 const def=INVENTORY_CATALOG[id];
 if(!def)return false;
 if(id===PERMANENT_PHONE_ID){
  ctx.save();ctx.translate(s.w/2+12,s.h*.07);ctx.rotate(-.24);
  ctx.fillStyle="#0b1524";ctx.strokeStyle="#b9cbd9";ctx.lineWidth=1.5;
  ctx.beginPath();ctx.roundRect(-7,-15,14,28,3);ctx.fill();ctx.stroke();
  ctx.fillStyle="#345a83";ctx.fillRect(-5,-11,10,19);
  ctx.fillStyle="#7bddc2";ctx.fillRect(-3,-8,6,4);
  ctx.fillStyle="#ebf9ff";ctx.fillRect(-3,-1,6,2);
  ctx.fillStyle="#b7c4ce";ctx.beginPath();ctx.arc(0,10,1.1,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#e7f0f7";ctx.beginPath();ctx.ellipse(-6,10,3,3.5,0,0,Math.PI*2);ctx.fill();
  ctx.restore();return true;
 }
 const drink=def.category==="Drink";
 const cx=s.w/2+11,cy=s.h*.06;
 ctx.save();ctx.translate(cx,cy);ctx.rotate(-.14);
 ctx.lineJoin="round";ctx.lineCap="round";
 const fill=(color,x,y,w,h,r=0)=>{ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill()};
 const stroke=(color,x,y,w,h,r=0,lw=1.2)=>{ctx.strokeStyle=color;ctx.lineWidth=lw;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.stroke()};
 const oval=(color,x,y,rx,ry=rx)=>{ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill()};
 const line=(color,lw,points)=>{ctx.strokeStyle=color;ctx.lineWidth=lw;ctx.beginPath();
  points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.stroke()};
 if(drink){
  if(id==="cold-water"){
   fill("#9dd4ed",-6,-12,12,24,3);fill("#d7f2fa",-4,-20,8,9,1);
   fill("#327fa9",-4,-22,8,3,1);fill("#f3ffff",-5,-3,10,9,1);
   line("#5ebde9",1.5,[[-3,3],[0,-1],[3,3]]);
  }else if(id==="hot-cocoa"){
   fill("#b7744e",-8,-9,16,20,3);stroke("#fae1c7",-8,-9,16,20,3);
   ctx.strokeStyle="#f3e2cf";ctx.lineWidth=3;ctx.beginPath();ctx.arc(10,-2,5,-Math.PI/2,Math.PI/2);ctx.stroke();
   oval("#6b3a2f",0,-9,7,2.4);oval("#fff9ed",-3,-10,2.2,2);oval("#fff9ed",2,-10,2,2);
  }else{
   const base=({"fresh-lemonade":"#f6d766","strawberry-lemonade":"#e9899f","iced-peach-tea":"#ca8e55",
    "vanilla-milkshake":"#f2e5c6","chocolate-milkshake":"#906046","berry-fizz":"#a29add"})[id]||"#addcd4";
   const shake=id.includes("milkshake"),fizz=id==="berry-fizz";
   ctx.fillStyle=base;ctx.beginPath();ctx.moveTo(-8,-11);ctx.lineTo(8,-11);ctx.lineTo(6,12);ctx.lineTo(-6,12);ctx.closePath();ctx.fill();
   line("#f7fff5",1.5,[[-8,-11],[8,-11],[6,12],[-6,12],[-8,-11]]);
   fill(shake?"#fffcf1":"#cce8d9",-9,-13,18,3,1);
   line(shake?"#e85388":"#5dabaa",2.3,[[2,-13],[5,-24]]);
   if(shake){oval("#fff9ea",0,-15,7,5);oval(id==="chocolate-milkshake"?"#643b2e":"#d3ac7d",0,-19,2,2)}
   if(id==="fresh-lemonade"||id==="strawberry-lemonade"){
    oval(id==="fresh-lemonade"?"#f6ea85":"#f28295",-2,1,3,3);
    oval("#fffaf0",-2,1,1.3,1.3);
   }
   if(fizz){oval("#f8e5fb",-2,-2,1.7);oval("#f8e5fb",3,4,1.3)}
  }
 }else{
  if(id==="classic-soft-pretzel"||id==="cheddar-pretzel"){
   // Two-loop twisted pretzel and center knot.
   ctx.strokeStyle="#ae733d";ctx.lineWidth=5.7;
   ctx.beginPath();ctx.moveTo(0,7);ctx.bezierCurveTo(-17,-7,-10,-14,-2,-4);
   ctx.bezierCurveTo(4,6,-3,7,0,7);ctx.bezierCurveTo(3,7,-4,6,2,-4);
   ctx.bezierCurveTo(10,-14,17,-7,0,7);ctx.stroke();
   ctx.strokeStyle="#f3c483";ctx.lineWidth=1.8;ctx.beginPath();ctx.moveTo(-10,-2);ctx.lineTo(-8,-5);
   ctx.moveTo(7,-6);ctx.lineTo(9,-3);ctx.stroke();
   if(id==="cheddar-pretzel"){fill("#f0b146",3,5,8,6,2);oval("#ffe278",7,5,3,1.4)}
  }else if(id==="cinnamon-roll"){
   oval("#cf955f",0,0,12,10);oval("#f4d2a2",0,0,9,8);
   ctx.strokeStyle="#8e5a3e";ctx.lineWidth=2.5;ctx.beginPath();
   ctx.arc(0,0,6,0,Math.PI*1.8);ctx.arc(0,0,2.5,0,Math.PI*1.8);ctx.stroke();
   line("#fff7dc",2,[[-8,-2],[-1,-7],[7,-3],[4,6]]);
  }else if(id==="pretzel-nuggets"||id==="churro-bites"){
   fill("#f2dfb8",-11,-2,22,16,3);fill("#ba8660",-11,-2,22,3,2);
   for(let i=0;i<4;i++){
    const x=-7+(i%2)*9,y=-7-Math.floor(i/2)*5;
    fill(id==="churro-bites"?"#d99a55":"#c38a4e",x,y,8,7,3);
    line("#f6d7a3",1.1,[[x+2,y+2],[x+5,y+5]]);
   }
  }else if(id==="ice-cream-cup"||id==="mini-sundae"){
   fill(id==="mini-sundae"?"#e0a2bf":"#91c9d7",-9,2,18,13,3);
   fill("#f8f6ea",-7,0,14,4,2);
   oval("#f4e7d1",-3,-3,7,6);oval("#aa7352",3,-5,5,6);
   if(id==="mini-sundae"){
    line("#9c4c57",2.5,[[-5,-6],[0,-2],[5,-6]]);oval("#e93c66",1,-12,3,3);
    fill("#ffe580",-7,-2,3,2);fill("#61b6a3",5,-3,3,2);
   }
  }else if(id==="cookie-ice-cream-sandwich"){
   oval("#c0864b",0,-4,10,7);fill("#fff1d9",-10,-1,20,9,3);
   oval("#ba7c42",0,7,10,6);
   for(const [x,y] of [[-5,-6],[4,-5],[-2,6],[5,8]])oval("#583e30",x,y,1.6);
  }else{
   fill("#c69d78",-8,-9,16,18,4);
  }
 }
 // The small finger/hand at the grip makes the model appear held.
 oval(p.id===clientId?"#f0f5f7":"#dfebee",-6,9,3.6,3.4);
 ctx.restore();
 return true;
}

function drawSmokePuffs(p,t,y){
 const started=smokeEvents.get(p.id);
 if(!started)return;
 const elapsed=t-started;if(elapsed>2900){smokeEvents.delete(p.id);return}
 ctx.save();
 for(let n=0;n<5;n++){
  const progress=(elapsed-n*210)/1800;
  if(progress<0||progress>1)continue;
  ctx.globalAlpha=.55*(1-progress);
  const px=p.x+11+progress*42+n*3;
  const py=y+7-progress*(43+8*n)+Math.sin(progress*8+n)*5;
  ctx.fillStyle="#dfe9f0";ctx.beginPath();ctx.arc(px,py,4+progress*10,0,Math.PI*2);ctx.fill();
 }
 ctx.restore();
}
function drawPlayer(p){
 const s=bodyStyleFor(p);
 const t=performance.now();
 const phase=playerPhase(p.id);
 const moving=(playerMotionUntil.get(p.id)||0)>t;
 const targetSeat=p.seat?1:0;
 let seatBlend=seatAnimation.get(p.id)??targetSeat;
 seatBlend+=Math.max(-.12,Math.min(.12,targetSeat-seatBlend));
 seatAnimation.set(p.id,seatBlend);
 const seated=seatBlend>.02;
 const active=(p.action in EMOTE_DURATIONS)&&Date.now()-p.actionAt<EMOTE_DURATIONS[p.action]?p.action:null;
 const actionTime=active?(Date.now()-p.actionAt)/1000:0;
 const bob=seated?0:active==="dance"?Math.abs(Math.sin(actionTime*9))*-7:moving?0:Math.sin(t*.002+phase)*1.35;
 const breathe=moving?1:1+Math.sin(t*.0018+phase)*.008;
 const visualY=p.y+bob;
 const reconnecting=!!p.disconnectedAt;

 ctx.save();
 ctx.globalAlpha=reconnecting?.42:1;
 ctx.fillStyle="#07101866";
 ctx.beginPath();ctx.ellipse(p.x,p.y+s.h*.38,s.w*.47,8,0,0,Math.PI*2);ctx.fill();
 ctx.restore();

 ctx.save();
 ctx.globalAlpha=reconnecting?.55:1;
 ctx.translate(p.x,visualY);
 if(active==="dance")ctx.rotate(Math.sin(actionTime*7)*.13);
 if(active==="facepalm")ctx.rotate(-.13);
 if(active==="sleep")ctx.rotate(.15);
 if(active==="cheer")ctx.translate(0,-Math.abs(Math.sin(actionTime*9))*7);
 if(seated){ctx.translate(0,11*seatBlend);ctx.scale(1+.04*seatBlend,1-.34*seatBlend)}
 ctx.scale(1/breathe,breathe);
 const mine=p.id===clientId;
 ctx.shadowBlur=mine?14:6;ctx.shadowColor=mine?"#7fd4ff":"#0008";
 ctx.fillStyle=s.color;ctx.strokeStyle=mine?"#dff6ff":"#d7e0ec";ctx.lineWidth=3;
 ctx.beginPath();ctx.roundRect(-s.w/2,-s.h/2,s.w,s.h,s.r);ctx.fill();ctx.stroke();
 ctx.shadowBlur=0;
 drawOutfitTo(ctx,p.outfit,s.w,s.h,s.r);

 const blink=((t/1000+phase)%4.8)>4.62;
 ctx.strokeStyle="#10151b";ctx.fillStyle="#10151b";ctx.lineWidth=2;
 if(blink){
   ctx.beginPath();ctx.moveTo(-9,-5);ctx.lineTo(-5,-5);ctx.moveTo(5,-5);ctx.lineTo(9,-5);ctx.stroke();
 }else{
   ctx.beginPath();ctx.arc(-7,-5,2.3,0,Math.PI*2);ctx.arc(7,-5,2.3,0,Math.PI*2);ctx.fill();
 }

 const hat=cosmetics.hats.find(h=>h.id===p.hat)?.draw||null;
 const mask=cosmetics.masks.find(m=>m.id===p.mask)?.draw||null;
 drawHat(hat,s.w,s.h);
 drawMask(mask,s.w,s.h);
 if(!drawHeldMenuItem(p,s))drawHeldDrink(p,s);
 if(active&&["wave","cheer","point","facepalm","dance"].includes(active)){
  ctx.save();ctx.lineCap="round";ctx.lineWidth=5;ctx.strokeStyle=s.color;
  const handX=active==="facepalm"?-7:active==="point"?30:s.w/2+7;
  const handY=active==="facepalm"?-8:active==="point"?-10:-s.h/2-9+(active==="wave"?Math.sin(actionTime*12)*9:active==="dance"?Math.sin(actionTime*11)*18:0);
  ctx.beginPath();ctx.moveTo(s.w/2-5,5);ctx.lineTo(handX,handY);ctx.stroke();ctx.restore();
 }
 if(active==="sleep"){
  ctx.fillStyle="#d9f5ff";ctx.font="bold 14px sans-serif";ctx.fillText("zZ",s.w/2+10,-s.h/2-13);
 }

 ctx.font="900 12px -apple-system,sans-serif";ctx.fillStyle="#eef5ff";ctx.textAlign="center";
 ctx.fillText(p.name,0,s.h/2+18);
 if(p.id===state?.hostId){
   ctx.fillStyle="#ffd16d";
   ctx.beginPath();ctx.arc(-ctx.measureText(p.name).width/2-8,s.h/2+14,3.5,0,Math.PI*2);ctx.fill();
 }
 ctx.restore();
 drawSmokePuffs(p,t,visualY);

 if(reconnecting)drawPresenceBubble(p.x,visualY-s.h/2-14,"RECONNECTING","emote");
 else drawSocialPresence(p,visualY,s);
}

// v0.18.7: shared geometry map for player/object collisions.
// New solid scenery should be added here using its rendered world coordinates.
// Each rect is the object's physical footprint, not its drop shadow or artwork.
const COLLISION_RADIUS=17;
function collisionRects(scene=currentScene()){
 const r=[];
 const add=(x,y,w,h)=>r.push({x,y,w,h});
 if(scene==="artifact"&&isMallAtrium()){
  // Back-wall cabinets and the recessed lower-row cabinets are solid.
  for(const x of ARTIFACT_MACHINE_XS)add(x-40,163,80,157);
  for(let i=0;i<8;i++){
   const x=i<4?155+i*114:1203+(i-4)*114;
   add(x-43,556,86,111);
  }
  // Acoustic lounge partitions and both halves of its bottom wall.
  const L=ARTIFACT_LOUNGE;
  add(L.x,L.y-15,L.w,29);
  add(L.x,L.y+14,12,L.h-12);add(L.x+L.w-12,L.y+14,12,L.h-12);
  add(L.x,L.y+L.h-12,157,16);add(L.x+L.w-157,L.y+L.h-12,157,16);
  for(const cx of ARTIFACT_SOFA_CENTERS)add(cx-62,459,124,67);
  add(798,552,104,49);
  add(0,0,28,WORLD_H);add(ARTIFACT_WORLD_W-28,0,28,WORLD_H);
 }else if(scene==="mall"&&isMallAtrium()){
  // The passage back to the atrium is the gap x=~80..220 in the back wall.
  // All storefronts, including the not-yet-enterable shops, stay solid.
  add(0,0,79,366);
  add(222,0, MALL_WORLD_W-222,366);
  // Structural divider poles are already contained within the storefront wall.
  // The kiosk counter is in that same wall, so no duplicate collider is needed.
  // Footprints of mall benches, rather than their elongated ground shadows.
  for(const {x} of WALKWAY_BENCHES)add(x-48,610,96,44);
  add(COMMUNITY_BOARD.x,COMMUNITY_BOARD.y+14,COMMUNITY_BOARD.w,COMMUNITY_BOARD.h-12);
  // Rectangular planter bases along the concourse.
  for(const x of [450,1110,1580,1980])add(x-34,455,68,27);
  // Solid end wall of the scrollable mall.
  add(MALL_WORLD_W-27,0,27,WORLD_H);
 }else if(scene==="lobby"&&isMallAtrium()){
  // Atrium entrance remains a real opening; do not obstruct its portal range.
  add(0,0,275,331);
  add(425,0,275,331);
  add(275,0,150,233);
  // Planter islands on the entrance floor (the central star is floor art).
  add(21,433,88,31);
  add(589,433,88,31);
  for(const {x,y} of ATRIUM_BENCHES)add(x-52,y-16,104,52);
  add(514,608,177,138);
 }else if(scene==="looks"){
  // Wall-mounted mirrors/decks are above the walking area.
  add(0,0,700,397);
  for(const rack of LOOKS_RACKS)add(rack.x,rack.y,rack.w,rack.h);
  add(295,445,110,66); // center merchandise table
 }else if(scene==="media"&&isMallAtrium()){
  // Preserved for when the shelved media store is enabled again.
  add(0,0,MEDIA_WORLD_W,367);
  for(const door of MEDIA_SCREEN_ENTRIES)add(door.x-80,368,160,12);
 }else if(scene==="theatre"){
  // Screen wall and actual chair backs. Keep both side aisles and exit clear.
  add(0,0,700,503);
  for(const [sx,sy,sw] of [[260,540,56],[328,540,56],[398,540,56],
                          [262,620,64],[346,620,64],[438,620,64]]){
   add(sx-sw/2,sy,sw,45);
  }
  // The exit on the left and TV controls on the right remain approach-able.
 }else if(scene==="lobby"){
  // Old private-room and Vibe furniture retain their original hit locations.
  add(0,0,700,isPublicRoomCode(roomCode)?235:177);
  if(isPublicRoomCode(roomCode)){
   add(482,440,177,86); // banquette
   add(365,498,100,49); // coffee table
   add(500,197,170,70); // DJ console (back wall)
   add(657,321,36,34); // plant base
  }else{
   add(488,446,164,78); // couch
   add(365,498,100,49); // coffee table
   add(632,308,30,29); // plant pot near right wall
  }
  add(THEATRE_DOOR.x,THEATRE_DOOR.y,THEATRE_DOOR.w,THEATRE_DOOR.h);
  add(ACTIVITY.x,ACTIVITY.y,ACTIVITY.w,ACTIVITY.h);
  // Wardrobe and fridge are anchored to the rear wall above the floor line.
 }
 return r;
}
function circleTouchesRect(x,y,rect,radius=COLLISION_RADIUS){
 const px=clamp(x,rect.x,rect.x+rect.w);
 const py=clamp(y,rect.y,rect.y+rect.h);
 return (x-px)*(x-px)+(y-py)*(y-py)<radius*radius;
}
function moveWithCollisions(p,dx,dy){
 const scene=currentScene(),walls=collisionRects(scene);
 const minX=PLAYER_RADIUS+8,maxX=worldWidthForScene(scene)-PLAYER_RADIUS-8;
 const minY=PLAYER_RADIUS+34,maxY=WORLD_H-PLAYER_RADIUS-20;
 // Let seated players stand up from a chair that now counts as a solid.
 // These particular obstructions are ignored only until the avatar leaves them.
 const startedInside=new Set();
 walls.forEach((wall,i)=>{if(circleTouchesRect(p.x,p.y,wall))startedInside.add(i)});
 const blocked=(x,y)=>{
  for(let i=0;i<walls.length;i++){
   const wall=walls[i];
   if(startedInside.has(i)){
    if(!circleTouchesRect(x,y,wall))startedInside.delete(i);
    else continue;
   }
   if(circleTouchesRect(x,y,wall))return true;
  }
  return false;
 };
 // Small swept steps prevent clipping through thin props during slow frames.
 const steps=Math.max(1,Math.ceil(Math.hypot(dx,dy)/5));
 const sx=dx/steps,sy=dy/steps;
 for(let i=0;i<steps;i++){
  const tx=clamp(p.x+sx,minX,maxX);
  if(!blocked(tx,p.y))p.x=tx;
  const ty=clamp(p.y+sy,minY,maxY);
  if(!blocked(p.x,ty))p.y=ty;
 }
}

function updateMovement(dt){
 if(!state||wardrobeOpen||activityOpen||tvPanelOpen||fridgeOpen||communityOpen||uncleMenuOpen||inventoryOpen||phoneOpen)return;
 const p=me();if(!p)return;

 const len=Math.hypot(input.x,input.y);
 if(len>0.001){
   if(p.seat)standUp();
   playerMotionUntil.set(clientId,performance.now()+180);
   const nx=input.x/Math.max(1,len),ny=input.y/Math.max(1,len);
   moveWithCollisions(p,nx*PLAYER_SPEED*dt,ny*PLAYER_SPEED*dt);
   p.seenAt=now();
   // Enter the hallway by actually walking into the open atrium doors.
   if(canEnterMall(p)&&ny<0){changeMallScene("mall");return}
   // Walk north into the back-wall doorway to return to the atrium.
   if(canExitMall(p)&&ny<0){changeMallScene("lobby");return}
   // The exit can also be walked through if a mobile joystick overlays the doorway.
   if(currentScene()==="artifact"&&ny>0&&p.x>=790&&p.x<=910&&p.y>=726){changeArtifactScene("mall");return;}

   const t=performance.now();
   if(t-lastPosBroadcast>50){
     lastPosBroadcast=t;
     broadcast("player-update",{id:clientId,patch:{x:p.x,y:p.y,seenAt:p.seenAt}});
   }
 }

 if(currentScene()==="theatre"){
  $("wardrobeHint").classList.remove("show");$("activityHint").classList.remove("show");
  $("tvHint").classList.remove("show");
  $("doorHint").classList.remove("show");
  $("fridgeHint").classList.remove("show");
  $("smokeHint").classList.remove("show");
 }else if(isMallAtrium()){
  for(const id of ["wardrobeHint","tvHint","fridgeHint","smokeHint","activityHint"])
   $(id).classList.remove("show");
  // Public transitions are indicated by their environment, not text prompts.
  $("doorHint").classList.remove("show");
 }else{
  const cx=WARDROBE.x+WARDROBE.w/2,cy=WARDROBE.y+WARDROBE.h/2;
  $("wardrobeHint").classList.toggle("show",Math.hypot(p.x-cx,p.y-cy)<105);
  $("tvHint").classList.remove("show");
  $("doorHint").classList.toggle("show",nearProp(p,THEATRE_DOOR,95));
  $("fridgeHint").classList.toggle("show",nearProp(p,FRIDGE,100));
  $("smokeHint").classList.toggle("show",nearProp(p,{x:399,y:474,w:53,h:58},110));
  const acx=ACTIVITY.x+ACTIVITY.w/2,acy=ACTIVITY.y+ACTIVITY.h/2;
  $("activityHint").classList.toggle("show",Math.hypot(p.x-acx,p.y-acy)<145);
  $("activityHint").textContent=state?.activity?.game?"TAP GAME TABLE · "+activityName().toUpperCase():"TAP GAME TABLE";
 }
}
function frame(t){
 const dt=Math.min(.033,(t-lastFrame)/1000||0);lastFrame=t;
 updateMovement(dt);updateUncleGreeting();updateAtriumDoors(dt);updateMallReturnDoor(dt);updateMallCamera(dt);updateMediaCamera(dt);updateArtifactCamera(dt);updateLooksDoor(dt);updateMediaDoor(dt);updateArtifactDoor(dt);drawWorld();requestAnimationFrame(frame)
}
requestAnimationFrame(frame);

function wakeJoystick(){
 $("joystick").classList.remove("idle");
 clearTimeout(joyIdleTimer);
 joyIdleTimer=setTimeout(()=>{$("joystick").classList.add("idle")},5000);
}
function setJoystickIdleSoon(){
 clearTimeout(joyIdleTimer);
 joyIdleTimer=setTimeout(()=>{$("joystick").classList.add("idle")},5000);
}
wakeJoystick();

function joyMove(e){
 const r=$("joystick").getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
 let dx=e.clientX-cx,dy=e.clientY-cy;const max=38,len=Math.hypot(dx,dy);
 if(len>max){dx=dx/len*max;dy=dy/len*max}
 $("stick").style.transform=`translate(${dx}px,${dy}px)`;
 input.x=dx/max;input.y=dy/max
}
$("joystick").addEventListener("pointerdown",e=>{wakeJoystick();joyId=e.pointerId;$("joystick").setPointerCapture?.(joyId);joyMove(e);e.preventDefault()},{passive:false});
$("joystick").addEventListener("pointermove",e=>{if(e.pointerId===joyId){joyMove(e);e.preventDefault()}},{passive:false});
function joyEnd(e){if(e.pointerId!==joyId)return;joyId=null;input.x=input.y=0;$("stick").style.transform="translate(0,0)";setJoystickIdleSoon()}
$("joystick").addEventListener("pointerup",joyEnd);$("joystick").addEventListener("pointercancel",joyEnd);

canvas.addEventListener("pointerdown",e=>{
 if(!state)return;
 // No legacy prop hitboxes in either public area. Portal taps require proximity.
 const r=canvas.getBoundingClientRect();
 const x=(e.clientX-r.left)*(WORLD_W/r.width)+(currentScene()==="mall"?mallCameraX:currentScene()==="media"?mediaCameraX:currentScene()==="artifact"?artifactCameraX:0);
 const y=(e.clientY-r.top)*(WORLD_H/r.height);
 const p=me();if(!p)return;
 if(isMallAtrium()&&currentScene()==="lobby"){
  const seat=PUBLIC_BENCH_SEATS.find(s=>s.scene==="lobby"&&Math.abs(x-s.x)<=36&&Math.abs(y-s.y)<35);
  if(seat){if(p.seat===seat.id)requestSeat(null);else if(Math.hypot(p.x-seat.x,p.y-seat.y)<=PUBLIC_BENCH_TAP_RANGE)requestSeat(seat.id);return;}
  if(x>=249&&x<=451&&y>=222&&y<=329&&inAtriumTapRange(p)){
   changeMallScene("mall",true);
  }
  return;
 }
 if(isMallAtrium()&&currentScene()==="mall"){
  if(x>=UNCLE_ALS_EMPLOYEE.x-10&&x<=UNCLE_ALS_EMPLOYEE.x+UNCLE_ALS_EMPLOYEE.w+10&&
     y>=UNCLE_ALS_EMPLOYEE.y-10&&y<=UNCLE_ALS_EMPLOYEE.y+UNCLE_ALS_EMPLOYEE.h+11){
   if(nearUncleAl(p))openUncleMenu();return;
  }
  if(x>=COMMUNITY_BOARD.x-5&&x<=COMMUNITY_BOARD.x+COMMUNITY_BOARD.w+5&&
     y>=COMMUNITY_BOARD.y-5&&y<=COMMUNITY_BOARD.y+COMMUNITY_BOARD.h+8){
    if(boardNearPlayer(p))openCommunityBoard();return;
  }
  const seat=PUBLIC_BENCH_SEATS.find(s=>s.scene==="mall"&&Math.abs(x-s.x)<=36&&Math.abs(y-s.y)<35);
  if(seat){if(p.seat===seat.id)requestSeat(null);else if(Math.hypot(p.x-seat.x,p.y-seat.y)<=PUBLIC_BENCH_TAP_RANGE)requestSeat(seat.id);return;}
  if(x>=ARTIFACT_STORE.doorX-12&&x<=ARTIFACT_STORE.doorX+ARTIFACT_STORE.doorW+12&&
     y>=ARTIFACT_STORE.doorY-12&&y<=ARTIFACT_STORE.doorY+ARTIFACT_STORE.doorH+13&&
     nearArtifactStore(p)){
   changeArtifactScene("artifact");return;
  }
  if(x>=380&&x<=530&&y>=210&&y<=365&&nearLooksStore(p)){
   changeLooksScene("looks");return;
  }
  if(x>=76&&x<=225&&y>=158&&y<=358&&inMallTapRange(p)){
   changeMallScene("lobby",true);
  }
  return;
 }
 if(isMallAtrium()&&currentScene()==="artifact"){
  const seat=ARTIFACT_SEATS.find(s=>Math.abs(x-s.x)<=38&&Math.abs(y-s.y)<=38);
  if(seat){
   if(p.seat===seat.id)requestSeat(null);
   else if(Math.hypot(p.x-seat.x,p.y-seat.y)<=ARTIFACT_SEAT_RANGE)requestSeat(seat.id);
   return;
  }
  if(x>=ARTIFACT_EXIT.x-4&&x<=ARTIFACT_EXIT.x+ARTIFACT_EXIT.w+4&&
     y>=ARTIFACT_EXIT.y-8&&y<=ARTIFACT_EXIT.y+ARTIFACT_EXIT.h+8&&nearArtifactExit(p)){
   changeArtifactScene("mall");return;
  }
  return;
 }
 if(isMallAtrium()&&currentScene()==="media"){
  if(x>=MEDIA_EXIT.x&&x<=MEDIA_EXIT.x+MEDIA_EXIT.w&&
     y>=MEDIA_EXIT.y&&y<=MEDIA_EXIT.y+MEDIA_EXIT.h&&nearMediaExit(p)){
   changeMediaScene("mall");return;
  }
  return;
 }
 if(isMallAtrium()&&currentScene()==="looks"){
  if(x>=LOOKS_EXIT.x&&x<=LOOKS_EXIT.x+LOOKS_EXIT.w&&
      y>=LOOKS_EXIT.y&&y<=LOOKS_EXIT.y+LOOKS_EXIT.h&&nearLooksExit(p)){
   changeLooksScene("mall");return;
  }
  for(const m of LOOKS_MIRRORS){
   if(x>=m.x-15&&x<=m.x+m.w+15&&y>=m.y-12&&y<=m.y+m.h+16&&nearProp(p,m,115)){
    openWardrobe();return;
   }
  }
  // Clothing racks use the same fixed-preview wardrobe as the mirrors.
  for(const rack of LOOKS_RACKS){
   if(x>=rack.x-7&&x<=rack.x+rack.w+7&&
      y>=rack.y-8&&y<=rack.y+rack.h+9&&nearProp(p,rack,110)){
    openWardrobe();return;
   }
  }
  return;
 }
 if(currentScene()==="theatre"){
  const seat=LOUNGE_SEATS.find(s=>s.scene==="theatre"&&Math.hypot(x-s.x,y-s.y)<34);
  if(seat){if(!p.seat&&Math.hypot(p.x-seat.x,p.y-seat.y)<125)requestSeat(seat.id);else if(p.seat===seat.id)requestSeat(null);return}
  const d=THEATRE_EXIT;
  if(x>=d.x-12&&x<=d.x+d.w+12&&y>=d.y-18&&y<=d.y+d.h+15){changeScene("lobby");return}
  const c=THEATRE_PANEL;
  if(x>=c.x-16&&x<=c.x+c.w+15&&y>=c.y-24&&y<=c.y+c.h+20){openTVPanel();return}
  // The big real HTML screen intercepts its own touches; fallback for edges.
  if(x>=18&&x<=682&&y>=60&&y<470){openTV();return}
  return;
 }
 const couchSeat=LOUNGE_SEATS.find(s=>s.scene==="lobby"&&Math.abs(x-s.x)<34&&Math.abs(y-s.y)<43);
 if(couchSeat){if(!p.seat&&Math.hypot(p.x-couchSeat.x,p.y-couchSeat.y)<125)requestSeat(couchSeat.id);else if(p.seat===couchSeat.id)requestSeat(null);return}
 const d=THEATRE_DOOR;
 if(nearProp(p,d,95)&&x>=d.x-15&&x<=d.x+d.w+16&&y>=d.y-20&&y<=d.y+d.h+20){changeScene("theatre");return}
 const tapFridge=x>=FRIDGE.x-12&&x<=FRIDGE.x+FRIDGE.w+12&&y>=FRIDGE.y-10&&y<=FRIDGE.y+FRIDGE.h+20;
 if(tapFridge&&nearProp(p,FRIDGE,100)){openFridge();return}
 const tapBong=x>=BONG.x-28&&x<=BONG.x+29&&y>=BONG.y-20&&y<=BONG.y+BONG.h+24;
 if(tapBong&&nearProp(p,{x:399,y:474,w:53,h:58},110)){
   broadcast("smoke",{});return;
 }
 const cx=WARDROBE.x+WARDROBE.w/2,cy=WARDROBE.y+WARDROBE.h/2;
 const near=Math.hypot(p.x-cx,p.y-cy)<115;
 const tapped=x>=WARDROBE.x-10&&x<=WARDROBE.x+WARDROBE.w+10&&y>=WARDROBE.y-10&&y<=WARDROBE.y+WARDROBE.h+30;
 if(near&&tapped){openWardrobe();return}
 const acx=ACTIVITY.x+ACTIVITY.w/2,acy=ACTIVITY.y+ACTIVITY.h/2;
 const nearActivity=Math.hypot(p.x-acx,p.y-acy)<155;
 const tappedActivity=x>=ACTIVITY.x-10&&x<=ACTIVITY.x+ACTIVITY.w+10&&y>=ACTIVITY.y-10&&y<=ACTIVITY.y+ACTIVITY.h+20;
 if(nearActivity&&tappedActivity){openActivity();return}
});

function setDrink(id){
 const p=me();if(!p||!joined)return;
 if(id!=="none"&&!DRINKS.some(d=>d.id===id))return;
 p.drink=id;
 broadcast("player-update",{patch:{drink:id}});
 renderFridgeChoices();
}
function renderFridgeChoices(){
 const p=me();if(!p)return;
 for(const [group,targetId] of [["soft","softDrinkOptions"],["alcohol","alcoholDrinkOptions"]]){
  const target=$(targetId);target.innerHTML="";
  for(const item of DRINKS.filter(d=>d.group===group)){
   const btn=document.createElement("button");btn.type="button";
   btn.className="drinkOption"+(p.drink===item.id?" selected":"");
   btn.setAttribute("aria-label","Hold "+item.name);
   const mini=document.createElement("span");mini.className="drinkMini"+(item.kind==="bottle"?" bottle":"");
   mini.style.setProperty("--drink-color",item.color);mini.dataset.short=item.short;
   const label=document.createElement("span");label.textContent=item.name;
   btn.append(mini,label);btn.addEventListener("click",()=>setDrink(item.id));target.appendChild(btn);
  }
 }
 $("fridgeSelection").textContent="Holding: "+(DRINKS.find(d=>d.id===p.drink)?.name||"nothing");
}
function openFridge(){
 if(currentScene()!=="lobby"||!nearProp(me(),FRIDGE,100))return;
 fridgeOpen=true;input.x=input.y=0;
 $("stick").style.transform="translate(0,0)";
 $("emoteTray").classList.add("hidden");
 renderFridgeChoices();$("fridgeModal").classList.remove("hidden");
}
function closeFridge(){fridgeOpen=false;$("fridgeModal").classList.add("hidden")}

function renderWardrobePreview(){
 const p=me();if(!p)return;
 const c=$("wardrobePreview"),pc=c.getContext("2d");
 pc.clearRect(0,0,c.width,c.height);
 pc.save();pc.translate(c.width/2,c.height/2+10);pc.scale(1.48,1.48);

 const s=bodyStyleFor(p);
 pc.fillStyle=s.color;pc.strokeStyle="#eaf7ff";pc.lineWidth=3;
 pc.beginPath();pc.roundRect(-s.w/2,-s.h/2,s.w,s.h,s.r);pc.fill();pc.stroke();
 drawOutfitTo(pc,p.outfit,s.w,s.h,s.r);

 pc.fillStyle="#10151b";
 pc.beginPath();pc.arc(-7,-5,2.3,0,Math.PI*2);pc.arc(7,-5,2.3,0,Math.PI*2);pc.fill();

 const hat=cosmetics.hats.find(h=>h.id===p.hat)?.draw||null;
 const mask=cosmetics.masks.find(m=>m.id===p.mask)?.draw||null;

 // Wardrobe preview now uses the exact same renderer as the live character.
 drawHatTo(pc,hat,s.w,s.h);
 drawMaskTo(pc,mask,s.w,s.h);
 pc.restore();
}


function openActivity(){
 $("emoteTray").classList.add("hidden");activityOpen=true;input.x=input.y=0;$("stick").style.transform="translate(0,0)";
 $("activityModal").classList.remove("hidden");renderActivityUI()
}
function closeActivity(){
 activityOpen=false;$("activityModal").classList.add("hidden")
}
function activityStatusText(){
 const a=state?.activity;if(!a||!a.game)return "Choose a game";
 if(a.status==="waiting")return "Waiting for another player";
 if(a.status==="playing"){
   const p=playerById(a.seats[a.turn]);
   return p?`${p.name}'s turn`:"Waiting";
 }
 if(a.status==="won"){
   const p=playerById(a.seats[a.winner]);
   return p?`${p.name} wins!`:"Game over";
 }
 if(a.status==="draw")return "Draw";
 return "";
}
function renderActivityUI(){
 if(!activityOpen||!state)return;
 const a=state.activity||freshActivity();
 $("activitySubtitle").textContent=a.game?activityName(): "Choose a game";
 $("activityMenu").classList.toggle("hidden",!!a.game);
 $("activityGame").classList.toggle("hidden",!a.game);
 if(!a.game)return;

 const seats=$("activitySeats");seats.innerHTML="";
 for(let i=0;i<2;i++){
   const id=a.seats[i],p=id?playerById(id):null;
   const chip=document.createElement("div");
   chip.className="seatChip"+(id===clientId?" you":"");
   const mark=a.game==="ttt"?(i===0?"X":"O"):
     a.game==="dots"?`P${i+1} · ${a.scores?.[i]||0} boxes`:
     a.game==="reversi"?`${i===0?"BLACK":"WHITE"} · ${a.board?.filter(v=>v===i+1).length||0}`:
     a.game==="gomoku"?`${i===0?"BLUE":"PINK"}`:(i===0?"RED":"YELLOW");
   chip.textContent=`${mark}: ${p?p.name:"OPEN SEAT"}`;
   seats.appendChild(chip)
 }

 $("activityMessage").textContent=activityStatusText();
 const board=$("activityBoard");board.innerHTML="";
 const mySeat=seatedIndex(clientId);
 const myTurn=activityCanPlay(clientId);

 if(a.game==="ttt"){
   const grid=document.createElement("div");grid.className="tttBoard";
   for(let i=0;i<9;i++){
     const b=document.createElement("button");b.className="tttCell";
     b.textContent=a.board?.[i]===1?"X":a.board?.[i]===2?"O":"";
     b.disabled=!myTurn||!!a.board?.[i];
     b.addEventListener("click",()=>submitActivityAction("move",{cell:i}));
     grid.appendChild(b)
   }
   board.appendChild(grid)
 }else if(a.game==="c4"){
   const grid=document.createElement("div");grid.className="c4Board";
   for(let i=0;i<42;i++){
     const b=document.createElement("button");
     const v=a.board?.[i];
     b.className="c4Cell"+(v===1?" p1":v===2?" p2":"");
     const col=i%7;
     b.disabled=!myTurn;
     b.setAttribute("aria-label",`Column ${col+1}`);
     b.addEventListener("click",()=>submitActivityAction("move",{col}));
     grid.appendChild(b)
   }
   board.appendChild(grid)
 }else if(a.game==="gomoku" || a.game==="reversi"){
   const gomoku=a.game==="gomoku",len=gomoku?81:64;
   const grid=document.createElement("div");grid.className=gomoku?"gomokuBoard":"reversiBoard";
   const seat=seatedIndex(clientId),mark=seat+1;
   for(let i=0;i<len;i++){
     const v=a.board?.[i],b=document.createElement("button");
     b.className=(gomoku?"gomokuCell":"reversiCell")+(v?` p${v}`:"");
     const legal=myTurn&&!v&&(gomoku || reversiFlips(a.board,i,mark).length>0);
     if(legal)b.classList.add("legal");
     b.disabled=!legal;
     b.setAttribute("aria-label",`Row ${Math.floor(i/(gomoku?9:8))+1}, column ${i%(gomoku?9:8)+1}`);
     b.addEventListener("click",()=>submitActivityAction("move",{cell:i}));
     grid.appendChild(b);
   }
   board.appendChild(grid);
 }else if(a.game==="dots"){
   const grid=document.createElement("div");grid.className="dotsBoard";
   for(let i=0;i<16;i++){
     const tile=document.createElement("div");tile.className="dotsClaim"+(a.claims?.[i]?` p${a.claims[i]}`:"");
     tile.style.left=`${20+(i%4)*20}%`;tile.style.top=`${20+Math.floor(i/4)*20}%`;
     grid.appendChild(tile);
   }
   for(let i=0;i<40;i++){
     const horizontal=i<20,r=horizontal?Math.floor(i/4):Math.floor((i-20)/5),c=horizontal?i%4:(i-20)%5;
     const b=document.createElement("button"),v=a.board?.[i];
     b.className="dotsEdge "+(horizontal?"horizontal":"vertical")+(v?` p${v}`:"");
     b.style.left=`${horizontal?20+c*20:10+c*20}%`;
     b.style.top=`${horizontal?10+r*20:20+r*20}%`;
     b.disabled=!myTurn||!!v;
     b.setAttribute("aria-label",`${horizontal?"Horizontal":"Vertical"} edge ${r+1}-${c+1}`);
     b.addEventListener("click",()=>submitActivityAction("move",{edge:i}));
     grid.appendChild(b);
   }
   for(let r=0;r<5;r++)for(let c=0;c<5;c++){
     const dot=document.createElement("div");dot.className="dotsPoint";
     dot.style.left=`${10+c*20}%`;dot.style.top=`${10+r*20}%`;grid.appendChild(dot);
   }
   board.appendChild(grid);
 }

 const actions=$("activityActions");actions.innerHTML="";
 if(mySeat<0&&a.seats.includes(null)){
   const join=document.createElement("button");join.className="btn primary";join.textContent="Join Game";
   join.addEventListener("click",()=>submitActivityAction("join"));actions.appendChild(join)
 }else if(mySeat>=0){
   const leave=document.createElement("button");leave.className="btn";leave.textContent="Leave Seat";
   leave.addEventListener("click",()=>submitActivityAction("leave"));actions.appendChild(leave)
 }
 if((a.status==="won"||a.status==="draw")&&mySeat>=0){
   const again=document.createElement("button");again.className="btn primary";again.textContent="New Round";
   again.addEventListener("click",()=>submitActivityAction("reset"));actions.appendChild(again)
 }
 if(mySeat>=0||isHost()){
   const end=document.createElement("button");end.className="btn bad";end.textContent="Close Game";
   end.addEventListener("click",()=>submitActivityAction("end"));actions.appendChild(end)
 }
}

function renderWardrobeChoices(){
 const p=me();if(!p)return;
 const colorBox=$("colorChoices"),shapeBox=$("shapeChoices"),hatBox=$("hatChoices"),maskBox=$("maskChoices"),outfitBox=$("outfitChoices");
 colorBox.innerHTML="";shapeBox.innerHTML="";hatBox.innerHTML="";maskBox.innerHTML="";outfitBox.innerHTML="";

 for(const item of bodyColors){
   const b=document.createElement("button");b.className="choice"+(p.color===item.id?" selected":"");
   b.textContent=item.name;b.style.borderColor=item.color;b.style.boxShadow=`inset 0 -7px 0 ${item.color}`;
   b.addEventListener("click",()=>{p.color=item.id;saveState();broadcast("player-update",{id:clientId,patch:{color:p.color}});renderWardrobeChoices()});
   colorBox.appendChild(b)
 }

 for(const item of bodyShapes){
   const b=document.createElement("button");b.className="choice"+(p.shape===item.id?" selected":"");
   b.textContent=item.name;
   b.addEventListener("click",()=>{p.shape=item.id;saveState();broadcast("player-update",{id:clientId,patch:{shape:p.shape}});renderWardrobeChoices()});
   shapeBox.appendChild(b)
 }

 for(const item of cosmetics.hats){
   const b=document.createElement("button");b.className="choice"+(p.hat===item.id?" selected":"");
   const mini=document.createElement("canvas");mini.width=70;mini.height=42;mini.style.width="70px";mini.style.height="42px";mini.style.display="block";mini.style.margin="0 auto 4px";
   const mc=mini.getContext("2d");mc.translate(35,34);drawHatTo(mc,item.draw,42,54);
   const label=document.createElement("div");label.textContent=item.name;
   b.append(mini,label);
   b.addEventListener("click",()=>{p.hat=item.id;saveState();broadcast("player-update",{id:clientId,patch:{hat:p.hat}});renderWardrobeChoices()});
   hatBox.appendChild(b)
 }

 for(const item of cosmetics.masks){
   const b=document.createElement("button");b.className="choice"+(p.mask===item.id?" selected":"");
   const mini=document.createElement("canvas");mini.width=70;mini.height=42;mini.style.width="70px";mini.style.height="42px";mini.style.display="block";mini.style.margin="0 auto 4px";
   const mc=mini.getContext("2d");mc.translate(35,22);drawMaskTo(mc,item.draw,42,54);
   const label=document.createElement("div");label.textContent=item.name;
   b.append(mini,label);
   b.addEventListener("click",()=>{p.mask=item.id;saveState();broadcast("player-update",{id:clientId,patch:{mask:p.mask}});renderWardrobeChoices()});
   maskBox.appendChild(b)
 }

 for(const item of cosmetics.outfits){
   const b=document.createElement("button");b.className="choice"+(p.outfit===item.id?" selected":"");
   const mini=document.createElement("canvas");mini.width=70;mini.height=50;mini.style.cssText="display:block;width:70px;height:50px;margin:0 auto 4px";
   const mc=mini.getContext("2d");mc.translate(35,25);
   mc.fillStyle=bodyColors.find(x=>x.id===p.color)?.color||"#7fd4ff";
   mc.beginPath();mc.roundRect(-20,-24,40,48,19);mc.fill();drawOutfitTo(mc,item.draw,40,48,19);
   const label=document.createElement("div");label.textContent=item.name;b.append(mini,label);
   b.addEventListener("click",()=>{p.outfit=item.id;saveState();broadcast("player-update",{id:clientId,patch:{outfit:p.outfit}});renderWardrobeChoices()});
   outfitBox.appendChild(b);
 }
 renderWardrobePreview();
}

function renderJoinPreview(){
 const canvas=$("joinPreview");if(!canvas)return;
 const jc=canvas.getContext("2d");
 jc.clearRect(0,0,canvas.width,canvas.height);
 jc.save();
 jc.translate(canvas.width/2,canvas.height/2+8);
 const shape=bodyShapes.find(x=>x.id===homeShapeChoice)?.id||bodyShapes[0]?.id||"pill";
 const color=bodyColors.find(x=>x.id===homeColorChoice)?.id||bodyColors[0]?.id||"sky";
 const s=bodyStyleFor({shape,color});
 jc.fillStyle=s.color;jc.strokeStyle="#eef7ff";jc.lineWidth=4;
 jc.beginPath();jc.roundRect(-s.w/2,-s.h/2,s.w,s.h,s.r);jc.fill();jc.stroke();
 jc.fillStyle="#10151b";
 jc.beginPath();jc.arc(-7,-6,2.6,0,Math.PI*2);jc.arc(7,-6,2.6,0,Math.PI*2);jc.fill();
 jc.restore();
}

function renderJoinCustomizer(){
 const colorBox=$("homeColorChoices"),shapeBox=$("homeShapeChoices");
 if(!colorBox||!shapeBox)return;
 colorBox.innerHTML="";shapeBox.innerHTML="";
 for(const item of bodyColors){
  const b=document.createElement("button");
  b.type="button";
  b.className="joinSwatch"+(homeColorChoice===item.id?" selected":"");
  b.setAttribute("aria-label",item.name);
  b.title=item.name;
  const sw=document.createElement("span");sw.className="joinSwatchInner";sw.style.background=item.color;
  b.appendChild(sw);
  b.addEventListener("click",()=>{homeColorChoice=item.id;renderJoinCustomizer()});
  colorBox.appendChild(b);
 }
 for(const item of bodyShapes){
  const b=document.createElement("button");
  b.type="button";
  b.className="joinShapeChoice"+(homeShapeChoice===item.id?" selected":"");
  b.setAttribute("aria-label",item.name);
  const mini=document.createElement("span");mini.className="joinShapeMini";
  const s=bodyStyleFor({shape:item.id,color:homeColorChoice});
  mini.style.background=bodyColors.find(x=>x.id===homeColorChoice)?.color||"#7fd4ff";
  mini.style.width=`${Math.max(16,Math.round(s.w*.38))}px`;
  mini.style.height=`${Math.max(18,Math.round(s.h*.38))}px`;
  mini.style.borderRadius=`${Math.max(6,Math.round(s.r*.38))}px`;
  const label=document.createElement("span");label.textContent=item.name;
  b.append(mini,label);
  b.addEventListener("click",()=>{homeShapeChoice=item.id;renderJoinCustomizer()});
  shapeBox.appendChild(b);
 }
 renderJoinPreview();
}

function openWardrobe(){$("emoteTray").classList.add("hidden");wardrobeOpen=true;input.x=input.y=0;$("stick").style.transform="translate(0,0)";renderWardrobeChoices();$("wardrobeModal").classList.remove("hidden")}
function closeWardrobe(){wardrobeOpen=false;$("wardrobeModal").classList.add("hidden")}
$("closeWardrobe").addEventListener("click",closeWardrobe);
$("wardrobeModal").addEventListener("pointerdown",e=>{if(e.target===$("wardrobeModal"))closeWardrobe()});

$("chooseTTT").addEventListener("click",()=>submitActivityAction("create",{game:"ttt"}));
$("chooseC4").addEventListener("click",()=>submitActivityAction("create",{game:"c4"}));
$("chooseGomoku").addEventListener("click",()=>submitActivityAction("create",{game:"gomoku"}));
$("chooseReversi").addEventListener("click",()=>submitActivityAction("create",{game:"reversi"}));
$("chooseDots").addEventListener("click",()=>submitActivityAction("create",{game:"dots"}));
$("closeActivity").addEventListener("click",closeActivity);
$("closeTV").addEventListener("click",closeTVPanel);
$("tvModal").addEventListener("pointerdown",e=>{if(e.target===$("tvModal"))closeTVPanel()});
$("theatreScreenWake").addEventListener("click",()=>{if(tvState()?.videoId)openTV();else openTVPanel()});
$("theatreWatchBtn").addEventListener("click",openTV);
$("theatreSyncBtn").addEventListener("click",tvJoinPlayback);
$("theatreOffBtn").addEventListener("click",closeTV);
$("theatrePanelBtn").addEventListener("click",openTVPanel);
$("theatreExitBtn").addEventListener("click",()=>changeScene("lobby"));
$("theatreThumb").addEventListener("error",()=>$("theatreThumb").classList.add("hidden"));
$("tvLoadBtn").addEventListener("click",()=>{
 const result=parseYouTubeLink($("tvLinkInput").value);
 if(!result){$("tvHelp").textContent="Enter a YouTube video link (watch, youtu.be, shorts, live, embed). Playlists alone are not supported.";return}
 tvCommand("load",result);
});
$("tvLinkInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("tvLoadBtn").click()});
$("tvJoinBtn").addEventListener("click",tvJoinPlayback);
$("tvPlayBtn").addEventListener("click",()=>{
 if(!isHost())return;
 tvCommand("play");
 if(tvPlayerReady){
  // Use the host's actual button gesture to start video with audio on iPhone.
  tvActivated=true;tvSyncingUntil=performance.now()+1400;
  tvPlayer.seekTo(tvExpectedPosition(),true);
  tvPlayer.playVideo();
 }
});
$("tvPauseBtn").addEventListener("click",()=>{if(isHost())tvCommand("pause")});
$("tvSeekBtn").addEventListener("click",()=>{
 const v=Number($("tvSeekInput").value);
 if(isHost()&&$("tvSeekInput").value.trim()!==""&&Number.isFinite(v)&&v>=0&&v<=86400)tvCommand("seek",{position:v});
});
$("tvClearBtn").addEventListener("click",()=>{if(isHost())tvCommand("clear")});
$("activityModal").addEventListener("pointerdown",e=>{if(e.target===$("activityModal"))closeActivity()});

$("homeJoinForm").addEventListener("submit",e=>{e.preventDefault();joinTheVibe()});
$("nameInput").addEventListener("input",()=>{$("homeError").textContent=""});
renderJoinCustomizer();
$("closeFridgeBtn").addEventListener("click",closeFridge);
$("putDrinkDownBtn").addEventListener("click",()=>setDrink("none"));
$("fridgeModal").addEventListener("pointerdown",e=>{if(e.target===$("fridgeModal"))closeFridge()});
$("leaveBtn").addEventListener("click",()=>leaveRoom(true));
$("lockBtn").addEventListener("click",()=>{if(!isHost())return;broadcast("lock-toggle",{})});
$("sendBtn").addEventListener("click",sendChat);
$("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendChat()});
$("chatInput").addEventListener("input",noteTyping);
$("emoteBtn").addEventListener("click",toggleEmotes);
for(const btn of document.querySelectorAll(".emoteChoice"))btn.addEventListener("click",()=>sendEmote(btn.dataset.emote));
window.addEventListener("beforeunload",()=>{if(socket&&joined){try{socket.send(JSON.stringify({type:"leave",payload:{}}))}catch{}}});
})();

