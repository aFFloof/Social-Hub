SOCIAL HUB v0.19.6 — THE ARTIFACT ARCADE & LOUNGE
================================================

Deploy by replacing the GitHub repository worker.js with this build.
No Durable Object migration or new bindings required.

- Mall spaces 03 and 04 combined into one 640-unit THE ARTIFACT storefront.
- Sign: THE ARTIFACT, with ARCADE AND LOUNGE underneath in smaller type.
- Two large frosted windows show silhouetted, glowing arcade cabinets.
- Central automatic sliding pocket doors open as any connected mall player approaches.
- Tap the entrance doors while nearby to enter the shared Artifact scene.
- 1700-wide scrollable arcade; two rows of cabinets lining the outer walls.
- Middle room has tinted partitions, rug, 3 couches (6 public seats), coffee table.
- Tap couch cushions from within 200 world units to sit; seating synchronized.
- Exit at bottom-middle returns to the mall on tap OR by walking through it.
- Server validates both scene transitions, canonical spawn positions, and seating.
- Latest Update board shows v0.19.6.
- No playable arcade cabinet games yet; machines are scenic until future updates.

Preserves food inventory, smartphone apps, private messages, chat, existing
stores, mall return doors, whiteboard, and previous public multiplayer features.
