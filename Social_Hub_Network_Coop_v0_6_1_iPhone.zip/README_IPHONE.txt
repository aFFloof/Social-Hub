SOCIAL HUB NETWORK CO-OP v0.6.1 — iPHONE DEPLOY BUILD

This build is functionally the same multiplayer prototype as v0.6, but the
entire frontend is embedded inside worker.js. That means the Git repository
only needs TWO deployment files:

- worker.js
- wrangler.jsonc

IPHONE-ONLY DEPLOYMENT

1. Create a new GitHub repository from Safari on your iPhone.
2. Upload worker.js and wrangler.jsonc from this folder to the ROOT of the repo.
3. Open dash.cloudflare.com in Safari.
4. Go to Workers & Pages > Create application.
5. Choose GitHub / Import a repository.
6. Authorize GitHub if asked.
7. Choose the repository you just created.
8. Leave the build command blank/default.
9. Use the deploy command:
       npx wrangler deploy
10. Save and Deploy.
11. When it finishes, open the provided workers.dev URL.

Your coworkers open that same URL on their own devices and join using the
six-character lobby code.

Do not upload this build to Pages Direct Upload. It needs Workers Builds so the
Durable Object multiplayer backend is provisioned.
